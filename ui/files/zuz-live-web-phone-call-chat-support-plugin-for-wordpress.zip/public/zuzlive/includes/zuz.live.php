<?php
class ZuzLive{
	
	public function myip(){
		if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
		{    $ip=$_SERVER['HTTP_CLIENT_IP'];    }
		elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
		{    $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];    }
		else
		{    $ip=$_SERVER['REMOTE_ADDR'];    }
		return $ip;
	}

	public function _CURL($url, $header = true, $timeout = 3600){
		$ch = curl_init($url);		
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		if($header==true) curl_setopt($ch, CURLOPT_HEADER, TRUE); // We'll parse redirect url from header.
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE); // We want to just get redirect url but not to follow it.
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
		curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
		return curl_exec($ch);
	}
	
}
?>