<div class="zuz-rel zuz-head">
	<img src="<?php echo ZUZBASE; ?>ui/zuzlive-logo.png" class="logo bl">
	<ol class="zuz-abs zuz-nav zuz-ibl zuz-fontn">
		<li><a href="javascript:;" data-section="dashboard" class="zuz-noshadow zuz-bl zuz-noul zuz-anim on"><div class="zuz-ibl zuzico icon-th-large"></div>Dashboard</a></li>
		<li><a href="javascript:;" data-section="settings" class="zuz-noshadow zuz-bl zuz-noul zuz-anim"><div class="zuz-ibl zuzico icon-cog"></div>Settings</a></li>		
	</ol>
	<div class="zuz-abs onoff zuz-fontn">	
		<div class="zuz-ibl zuz-checkbox"><input type="checkbox" value="yes" class="is-zuz-on checkbox"<?php echo get_option('zuz_live_enabled') == 'yes' ? ' checked' : ''; ?>></div>
		<h2 class="zuz-ibl lbl zuz-fontb"><?php echo get_option('zuz_live_enabled') == 'yes' ? 'Enabled' : 'Disabled' ; ?></h2>
	</div>	
</div>
