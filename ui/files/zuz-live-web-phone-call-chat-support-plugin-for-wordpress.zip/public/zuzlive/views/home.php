<div class="zuz-lod zuz-rel"></div>


<div class="zuzcontent zuz-content-dashboard zuz-content-hide">
	
	<div class="zuzdashboard zuz-rel">
		<div class="zuz-ibl zuz-block zuz-anim zuzblock zuz-rel" data-mod="users">
			<h2 class="zuz-fontb tt zuz-rel">Users</h2>
			<div class="zuz-ibl zuz-con icon-user"></div>
			<div class="zuz-spt zuz-ibl"></div>
			<h2 class="zuz-fontn zuz-ibl tl zuz-rel">total users</h2>
			<h2 class="zuz-count zuz-abs zuz-user-count zuz-fontb">--</h2>
		</div>
		<div class="zuz-ibl zuz-block zuz-rel"></div>
		<div class="zuz-ibl zuz-block zuz-anim zuzblock zuz-rel" data-mod="chats">
			<h2 class="zuz-fontb tt zuz-rel">Chats</h2>
			<div class="zuz-ibl zuz-con icon-mode_comment"></div>
			<div class="zuz-spt zuz-ibl"></div>
			<h2 class="zuz-fontn tl zuz-ibl zuz-rel">total chats</h2>
			<h2 class="zuz-count zuz-abs zuz-chat-count zuz-fontb">--</h2>
		</div>
		<div class="zuz-ibl zuz-block zuz-rel"></div>
		<div class="zuz-ibl zuz-block zuz-anim zuzblock zuz-rel" data-mod="calls">
			<h2 class="zuz-fontb tt zuz-rel">Calls</h2>
			<div class="zuz-ibl zuz-con icon-phone"></div>
			<div class="zuz-spt zuz-ibl"></div>
			<h2 class="zuz-fontn zuz-ibl tl zuz-rel">total calls</h2>
			<h2 class="zuz-count zuz-abs zuz-call-count zuz-fontb">--</h2>
		</div>
	</div>

	<div class="zuz-history-box zuz-bl zuz-rel">
		<h1 class="zuz-fontn zh-title"></h1>
		<div class="zuzhistory zuz-rel">
			<h2 class="zuzhistory-empty zuz-fontl">Welcome to Zuz Live Dashboard</h2>
		</div>
	</div>
	
</div>
<div class="zuzcontent zuz-content-settings zuz-content-hide">
	
	<div class="zuz-form zuz-rel zuz-ibl">
		
		<div class="zuz-cog-cover zuz-abs"></div>
		
		<div class="zuz-sect zuz-rel">
			<h2 class="lbl zuz-fontb">Widget Title</h2>
			<input type="text" value="<?php echo get_option('zuz_live_widget_title'); ?>" placeholder="e.g: Zuz Live Support" class="zuz-iput zuz-fontn zuz-cog-title">
		</div>
		
		<div class="zuz-sect zuz-rel">
			<h2 class="lbl zuz-fontb">Widget Welcome Message</h2>
			<input type="text" value="<?php echo get_option('zuz_live_widget_message'); ?>" placeholder="e.g: We are here to help :)" class="zuz-iput zuz-fontn zuz-cog-msg">
		</div>
		
		<div class="zuz-sect zuz-rel">
			<h2 class="lbl zuz-fontb">Widget Type</h2>
			<?php $wtyp = get_option('zuz_live_widget_type'); ?>
			<label class="label"><input type="radio" value="auto" class="zuzcogtype" name="zuz-cog-type"<?php if($wtyp=='auto'){ echo ' checked'; } ?>> Call & Chat</label>
			<label class="label"><input type="radio" value="chat" class="zuzcogtype" name="zuz-cog-type"<?php if($wtyp=='chat'){ echo ' checked'; } ?>> Chat Only</label>
			<label class="label"><input type="radio" value="call" class="zuzcogtype" name="zuz-cog-type"<?php if($wtyp=='call'){ echo ' checked'; } ?>> Call Only</label>
			<ol class="zuz-widget-info zuz-fontn">
				<li class="zwi-sect zwi-auto"<?php if($wtyp=='auto'){ echo ' style="display:block;"'; } ?>>Call will work only on WebRTC Enabled Browsers. Min requirement:
					<div><span class="zuz-fontb">Desktop PC</span>: Microsoft Edge 12, Google Chrome 28, Mozilla Firefox 22, Safari 11, Opera 18, Vivaldi 1.9</div>
					<div><span class="zuz-fontb">Android</span>: Google Chrome 28 (enabled by default since 29), Mozilla Firefox 24, Opera Mobile 12</div>
					<div><span class="zuz-fontb">Chrome OS, Firefox OS, Blackberry 10, iOS 11, MobileSafari/WebKit</span></div>
				</li>
			</ol>
		</div>
		
		<div class="zuz-sect zuz-rel">
			<h2 class="lbl zuz-fontb">Widget Position</h2>
			<?php $wpos = get_option('zuz_live_widget_position'); ?>
			<label class="label"><input type="radio" value="left" class="zuzcogpos" name="zuz-cog-pos"<?php if($wpos=='left'){ echo ' checked'; } ?>> Left</label>
			<label class="label"><input type="radio" value="right" class="zuzcogpos" name="zuz-cog-pos"<?php if($wpos=='right'){ echo ' checked'; } ?>> Right</label>						
		</div>
		
		<div class="zuz-sect zuz-rel" style="margin-bottom:15px;"><h2 class="lbl zuz-fontb">Messenger Color Scheme</h2></div>
		<div class="zuz-sect zuz-rel">
			<ul class="zuz-ibl zwidgts">
				<li>
					<h2 class="lbl zuz-fontb">Background Color</h2>
					<input class="zuz-colorput zuz-cog-widget-color" data-color="<?php echo get_option('zuz_live_widget_color'); ?>">
				</li>
				<li>
					<h2 class="lbl zuz-fontb">Counter Color</h2>
					<input class="zuz-colorput zuz-cog-counter-color" data-color="<?php echo get_option('zuz_live_widget_counter_color'); ?>">
				</li>
				<li>
					<h2 class="lbl zuz-fontb">Message Color</h2>
					<input class="zuz-colorput zuz-cog-message-color" data-color="<?php echo get_option('zuz_live_widget_message_color'); ?>">
				</li>
				<li>
					<h2 class="lbl zuz-fontb">Message Text Color</h2>
					<input class="zuz-colorput zuz-cog-message-text-color" data-color="<?php echo get_option('zuz_live_widget_message_text_color'); ?>">
				</li>
			</ul>
		</div>
		
		<?php 
			$fire = get_option('zuz_live_firebase'); 
			$apiKey = $authDomain = $databaseURL = $projectId = $storageBucket = $messagingSenderId = '';
			if($fire!='none'){
				$fire = @json_decode($fire);
				$apiKey = $fire->apiKey; $authDomain = $fire->authDomain; $databaseURL = $fire->databaseURL;
				$projectId = $fire->projectId; $storageBucket = $fire->storageBucket; $messagingSenderId = $fire->messagingSenderId;
			}
		?>
		<div class="zuz-sect zuz-rel" style="margin-bottom:15px;">
			<h2 class="lbl zuz-fontb">Firebase Datbase Information</h2>
			<a href="https://console.firebase.google.com/" class="_blank">Goto Firebase Console</a>
		</div>
		<div class="zuz-sect zuz-rel">
			<h2 class="lbl zuz-fontb">apiKey</h2>
			<input type="text" value="<?php echo $apiKey; ?>" placeholder="apiKey" class="zuz-iput zuz-fontn zuz-cog-fire-apikey">
		</div>
		<div class="zuz-sect zuz-rel">
			<h2 class="lbl zuz-fontb">authDomain</h2>
			<input type="text" value="<?php echo $authDomain; ?>" placeholder="authDomain" class="zuz-iput zuz-fontn zuz-cog-fire-authdomain">
		</div>
		<div class="zuz-sect zuz-rel">
			<h2 class="lbl zuz-fontb">databaseURL</h2>
			<input type="text" value="<?php echo $databaseURL; ?>" placeholder="databaseURL" class="zuz-iput zuz-fontn zuz-cog-fire-databaseurl">
		</div>
		<div class="zuz-sect zuz-rel">
			<h2 class="lbl zuz-fontb">projectId</h2>
			<input type="text" value="<?php echo $projectId; ?>" placeholder="projectId" class="zuz-iput zuz-fontn zuz-cog-fire-projectid">
		</div>
		<div class="zuz-sect zuz-rel">
			<h2 class="lbl zuz-fontb">storageBucket</h2>
			<input type="text" value="<?php echo $storageBucket; ?>" placeholder="storageBucket" class="zuz-iput zuz-fontn zuz-cog-fire-storagebucket">
		</div>
		<div class="zuz-sect zuz-rel">
			<h2 class="lbl zuz-fontb">messagingSenderId</h2>
			<input type="text" value="<?php echo $messagingSenderId; ?>" placeholder="messagingSenderId" class="zuz-iput zuz-fontn zuz-cog-fire-messagingsenderid">
		</div>
		
		<input type="button" class="button button-primary zuz-save-cog zuz-fontn" value="Save Changes">
		
	</div>
	
	<div class="zuz-ibl zuz-preview zuz-rel">
		
		<h2 class="previewlbl zuz-fontb">Client Preview</h2>
		
		<div class="zuz_messenger zuz-anim zuz-rel">
			<div class="zuz_head zuz-rel">
				<button class="zuz-call-now zuz-anim zuz-abs icon-phone"></button>
				<h2 class="zuz-agent-name zuz-wordwrap zuz-fontb"><?php echo get_option('zuz_live_widget_title'); ?></h2>
				<h2 class="zuz-agent-status zuz-wordwrap zuz-fontn">Connected</h2>
				<button class="zuz-close zuz-anim zuz-abs">×</button>
			</div>
			<div class="zuz-rel zuz-conversation">
				<div class="zuz-scrolls zuz-chat-list zuz-fontn">
					<div class="zuz-item zuz-item-block zuz-me zuz-rel">
						<div class="zuz-rel zuztxt">
							<span class="zuz-content zuz-ibl zuz-anim zuz-rel">
								Hello, would you like to talk about our products?
								<span class="zuz-bl zuz-stamp">
									<span class="zuz-ibl zuz-status icon-done_all" title="Seen"></span>
									<span class="zuz-ibl zuz-rel zuz-time">32m</span>
								</span>
							</span>
						</div>
					</div>
					<div class="zuz-item zuz-item-block zuz-you zuz-rel">
						<div class="zuz-rel zuztxt">
							<span class="zuz-content zuz-ibl zuz-anim zuz-rel">
								I'm looking for summer shoes. I liked the ones I bought recently, but I'm looking for black ones this time.
								<span class="zuz-bl zuz-stamp">
									<span class="zuz-ibl zuz-status icon-done_all" title="Seen"></span>
									<span class="zuz-ibl zuz-rel zuz-time">23m</span>
								</span>
							</span>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="zuzlivewidget zuz-anim zuz-abs zuz-ibl<?php if($wpos=='left'){ echo ' zuzlivewidget-left'; } ?>">
			<div class="zuzcounter zuz-abs" style="background: <?php echo get_option('zuz_live_widget_counter_color'); ?>">7</div>
			<div class="zuz-abs zuz-msg" style="background: <?php echo get_option('zuz_live_widget_message_color'); ?>">
				<button class="zuz-hide-msg zuz-anim zuz-abs">×</button>
				<h2 class="zuz-fontn txt" style="color: <?php echo get_option('zuz_live_widget_message_text_color'); ?>"><?php echo get_option('zuz_live_widget_message'); ?></h2>
			</div>
			<button class="zuz-init-chat zuzinitcall zuz-anim<?php if($wtyp == 'auto'){ echo ' zuz-l'; } if($wtyp === 'call'){ echo ' zuz-ro'; } ?>" style="<?php if($wtyp === 'chat'){ echo 'display:none;'; } ?>background: <?php echo get_option('zuz_live_widget_color'); ?>"><img src="<?php echo ZUZBASE; ?>ui/mobile.png" class="zuz-bl"></button><?php
			?><button class="zuz-init-chat zuzinitchat zuz-anim<?php if($wtyp == 'auto'){ echo ' zuz-r'; } if($wtyp === 'chat'){ echo ' zuz-ro'; }  ?>" style="<?php if($wtyp === 'call'){ echo 'display:none;'; } ?>background: <?php echo get_option('zuz_live_widget_color'); ?>"><img src="<?php echo ZUZBASE; ?>ui/chat.png" class="zuz-bl"></button>
		</div>
		
	</div>
	
</div>

<div class="zuztoast zuz-fix"><div class="zuz-abs _msg zuz-fontn">Please wait...</div></div>