<?php
/*
Plugin Name: Zuz Live
Plugin URI: https://demos.zuz.host/live/
Description: Zuz Live Web Phone Call & Chat Support Plugin for wordpress lets you monitor and connect with visitors on your website via Web Phone Call & Live Chat.
Author: Kamran Wajdani
Version: 0.4
Author URI: https://zuz.host
*/
if(!defined('WPINC')) die;
$plugin_url	= str_replace('index.php','',plugins_url( 'index.php', __FILE__ ));
if(strpos($plugin_url, 'http') === false){
	$site_url = get_site_url();
	$plugin_url = (substr($site_url, -1) === '/') ? substr($site_url, 0, -1). $plugin_url : $site_url. $plugin_url;
}
$plugin_url = str_replace(array(chr(10), chr(13)), '', $plugin_url);

define('ZUZBASE', plugins_url() . '/zuzlive/');

require_once(__DIR__ . "/includes/zuz.live.php");
$z = new ZuzLive();

function enable_zuzlive(){
	add_option('zuz_live_enabled', 'yes');
	add_option('zuz_live_widget_title', 'Zuz Live Support');
	add_option('zuz_live_widget_message', 'Hey, we are live 24/7. Let us know if you have any questions');
	add_option('zuz_live_widget_type', 'auto');
	add_option('zuz_live_widget_position', 'right');
	add_option('zuz_live_widget_color', '#be0000');	
	add_option('zuz_live_widget_counter_color', '#0066ff');	
	add_option('zuz_live_widget_message_color', '#2d2d2d');	
	add_option('zuz_live_widget_message_text_color', '#ffffff');	
	add_option('zuz_live_firebase', 'none');
	/*if(false===get_option('zuz_live_firebase')){
		add_option('zuz_live_firebase', 'none');
	}*/
	/*else{
		update_option('zuz_live_firebase', json_encode(array(
			'apiKey' => "AIzaSyCQf6ekeipaopcy7apEL8fdD28JIrz92BU",
			'authDomain' => "zuzhostapp.firebaseapp.com",
			'databaseURL' => "https://zuzhostapp.firebaseio.com",
			'projectId' => "zuzhostapp",
			'storageBucket' => "zuzhostapp.appspot.com",
			'messagingSenderId' => "340189075327"
		)));
	}*/
	

}

function addZuzLiveCore(){
	global $z;
	$cuser = wp_get_current_user();	
	$uaname = empty($cuser->data->display_name) ? $cuser->data->user_login : $cuser->data->display_name;
	$uamail = $cuser->data->user_email;
	//echo "<link rel=\"stylesheet\" href=\"https://i.icomoon.io/public/temp/1d36c8dd3f/ZuzLive/style.css\">\n";
	//echo "<link rel=\"stylesheet\" href=\"".ZUZBASE."css/zuz.props.css?".time()."\">\n";
	//echo "<link rel=\"stylesheet\" href=\"".ZUZBASE."css/zuz."; echo is_admin() ? 'live.admin' : 'live'; echo ".css?".time()."\">\n";
	echo '<script>window.zuzFirebaseConfig=';
	$firebase = get_option('zuz_live_firebase');
	if($firebase=='none'){ echo 'false'; }else{
		$firebase = @json_decode($firebase);
		echo '{apiKey:"'.$firebase->apiKey.'",authDomain:"'.$firebase->authDomain.'",databaseURL:"'.$firebase->databaseURL.'",'
		. 'projectId:"'.$firebase->projectId.'",storageBucket:"'.$firebase->storageBucket.'",messagingSenderId:"'.$firebase->messagingSenderId.'"}';
	}
	echo ';window.zuzlive={ base: "'.ZUZBASE.'", mail: "'; 
	if(is_admin()){ echo get_option('admin_email'); }else{ echo $cuser->ID == 1 ? $cuser->data->user_email : ''; }
	echo '"';
	echo is_admin() ? ',upass:"'.md5('zuzlive@@##').'"' : '';
	echo is_admin() ? ',uaname:"'.$uaname.'"' : '';
	echo is_admin() ? ',uamail:"'.$uamail.'"' : '';
	echo is_admin() ? ',zuzon: "'.get_option('zuz_live_enabled').'"' : '';
	
	if(!is_admin()){
		$welcomeMsg = str_replace(PHP_EOL, "<br>", get_option("zuz_live_widget_message"));
		echo ', color: { widget: "'.get_option("zuz_live_widget_color").'", counter: "'.get_option("zuz_live_widget_counter_color").'", message: "'.get_option("zuz_live_widget_message_color").'", messageTxt: "'.get_option("zuz_live_widget_message_text_color").'"}, dir:"'.get_option("zuz_live_widget_position").'", type: "'.get_option("zuz_live_widget_type").'",'
		. 'title: "'.get_option("zuz_live_widget_title").'", welcomeMsg: "'.$welcomeMsg.'", me: { ip: "'.$z->myip().'" }';
	}
	echo '};</script>';
	$js = is_admin() ? 'admin' : 'live';
	$css = ZUZBASE."css/zuz."; $css .= is_admin() ? 'live.admin' : 'live'; $css .= ".css?".time();	
	wp_enqueue_style('zuzicon', ZUZBASE."css/zuz.icomoon.css");
	wp_enqueue_style('zuzprops', ZUZBASE."css/zuz.props.css?".time());
	wp_enqueue_style('zuzlive', $css);
	wp_enqueue_script('zuzplugs', ZUZBASE . 'js/zuz.plugs.js?'.time(), array('jquery'));
	wp_enqueue_script('zuzcore', ZUZBASE . 'js/zuz.core.js?'.time(), array('jquery'));
	wp_enqueue_script('zuzlive', ZUZBASE . 'js/zuz.'.$js.'.js?'.time(), array('jquery'));
	
}

function addZuzLiveFooter(){
	
}

function adminAddMenu(){
	add_menu_page('ZuzLive', 'Zuz Live', 'manage_options', 'zuzlivesupport', 'adminPage');
}

function adminPage(){
	echo '<div class="zuz-wrap zuz-rel">';
	include_once(__DIR__ . "/views/header.php");
	include_once(__DIR__ . "/views/home.php");
	echo '</div>';
	/*$zuzArea = isset($_GET['zuz']) ? $_GET['zuz'] : 'dashboard';	
	echo '<div class="zuz-wrap zuz-rel"><div class="clear_both"></div>';	
	include_once(__DIR__ . "/views/header.php");
	include_once(__DIR__ . "/views/".$zuzArea.".php");			
	echo '</div>';		
	echo '<script src="'.ZUZBASE.'js/base.js"></script>';
	echo '<script src="'.ZUZBASE.'js/core.js?'.time().'"></script>';*/
}

function zuz_ajax(){ 	
	switch($_POST['request']):
		case "zuz_enable":
			update_option('zuz_live_enabled', $_POST['enabled']);
			$stat = $_POST['enabled'] == 'yes' ? 'Enabled' : 'Disabled';			
			echo @json_encode(array('result' => 'ok', 'message' => 'ZuzLive '.$stat.' Successfully...')); die();
		break;
		case "zuzsavecog":		
			$title = $_POST['title'];	
			$msg = $_POST['msg'];
			$type = $_POST['type'];
			$pos = $_POST['pos'];
			$color_widget = $_POST['color_widget'];
			$color_counter = $_POST['color_counter'];
			$color_msg = $_POST['color_msg'];
			$color_txt = $_POST['color_txt'];
			$fire_key = $_POST['fire_key'];
			$fire_auth = $_POST['fire_auth'];
			$fire_db = $_POST['fire_db'];
			$fire_id = $_POST['fire_id'];
			$fire_storage = $_POST['fire_storage'];
			$fire_msgid = $_POST['fire_msgid'];
			
			update_option('zuz_live_widget_title', $title);
			update_option('zuz_live_widget_message', $msg);
			update_option('zuz_live_widget_type', $type);
			update_option('zuz_live_widget_position', $pos);
			update_option('zuz_live_widget_color', $color_widget);	
			update_option('zuz_live_widget_counter_color', $color_counter);	
			update_option('zuz_live_widget_message_color', $color_msg);	
			update_option('zuz_live_widget_message_text_color', $color_txt);	
			update_option('zuz_live_firebase', json_encode(array(
				'apiKey' => $fire_key,
				'authDomain' => $fire_auth,
				'databaseURL' => $fire_db,
				'projectId' => $fire_id,
				'storageBucket' => $fire_storage,
				'messagingSenderId' => $fire_msgid
			)));
			
			echo @json_encode(array('result' => 'ok', 'message' => 'Settings updated successfully...')); die();
			
		break;
	endswitch;
}

if(is_admin()){ 
	add_action('admin_enqueue_scripts', 'addZuzLiveCore'); 
	add_action('admin_menu', 'adminAddMenu');
	add_action('wp_ajax_zuz_ajax','zuz_ajax');
}else{
	if(get_option('zuz_live_enabled')=='yes'){ add_action('wp_enqueue_scripts', 'addZuzLiveCore'); }
}	
	
add_action('wp_footer', 'addZuzLiveFooter');	
register_activation_hook(__FILE__, 'enable_zuzlive');