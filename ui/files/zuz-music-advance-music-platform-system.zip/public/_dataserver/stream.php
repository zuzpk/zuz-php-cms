<?php ob_start(); 
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization');
require(__DIR__ . '/core.php');
@list($fileid, $format, $title) = explode("@@", decode($_GET['token'], $_GET['ekey']));
$filename = $format.'.'.$fileid;
$files = [$filename, '128.' . $fileid, '192.' . $fileid, '256.' . $fileid, '320.' . $fileid, $fileid];
$available = false;
foreach($files as $file):
	$local = __DIR__ . '/assets/tracks/'.$file;
	if(file_exists($local)){
		$available = true;
		break;
	}
endforeach;
if($available === false || !file_exists($local)){ header("HTTP/1.0 404 Not Found"); exit; }
stream($local, $title, 'audio/mpeg');
ob_flush(); ?>