<?php ob_start(); 
if(isset($_GET['connect'])){
	include(__DIR__ . '/core.php');
	header("Content-type: application/json");
	if(function_exists('CheckInstallation')){ CheckInstallation(); exit; }
	echo JSON(array(
		'exec' => false,
		'ffmpeg' => false,
		'ytdl' => false
	)); exit;	
}
header("location: https://zuz.host/?f=oyecdn_zuzmusic"); exit; 
ob_flush(); ?>