<?php ob_start(); 
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization');
header("Content-Type: application/json");
if($_SERVER['REQUEST_METHOD'] === 'OPTIONS'){ echo @json_encode(array('result' => 'skipped')); exit; }
require(__DIR__ . '/core.php');
$POST = @json_decode(@file_get_contents("php://input"));
$verifyToken = @json_decode(___CURL($POST->token, false));
if(isset($verifyToken->error)){ echo JSON(array('error' => true, 'type' => 'auth')); exit; }
$tmpDir = __DIR__ . "/assets/temp/";
$dataDir = __DIR__ . "/assets/tracks/";
checkFolders($tmpDir, $dataDir);
set_time_limit(0);
switch($_GET['mod']):
	case "youtube":	
		$filesize = 0;
		$videofile = $tmpDir . $POST->ID . '.mp4';
		$cmd = getYTDL() . " -f mp4 -o " . $videofile . " --no-warnings https://www.youtube.com/watch?v=".$POST->ID;
		@exec($cmd, $output, $exit); 
		$quality = explode(",", $POST->quality);
		$filename = $POST->ID . '.' . $POST->format;
		foreach($quality as $Q):
			$audio = $dataDir . $Q . '.' . $filename;
			if(@file_exists($audio)){ $filesize += @filesize($audio); continue; }
			$cmd = getFFMPEG() . " -i '" . $videofile . "' -f " . $POST->format . " -b:a " . $Q . "K -vn '" . $audio . "'"; 
			if($POST->meta->add=='yes'){
				$cmd .= " -metadata";	
				foreach($POST->meta->data as $key => $val):
					$cmd .= " " . $key . "='" . escapeshellarg($val) . "'";
				endforeach;				
			}
			@exec($cmd, $xutput, $exit);			
		endforeach;		
		@unlink($videofile);
		//CheckSpace		
		
		$cmd = getYTDL() . " --no-warnings --skip-download --print-json https://www.youtube.com/watch?v=" . $POST->ID . " 2>&1";
		@exec($cmd, $output, $return_var);
		$txt = "";
		for($n = 0; $n < count($output); $n++):
			if(strpos($output[$n], "upload_date")!==false && strpos($output[$n], "like_count")!==false){
				$txt = $output[$n];
				break;
			}
		endfor;
		$info = @json_decode($txt);		
		echo JSON(array(
			'kind' => 'zuz#uploadResponse',
			'source' => 'youtube',
			'id' => $POST->ID,
			'format' => $POST->format,
			'quality' => $POST->quality,
			'disk' => $filesize,
			'fileid' => $filename,
			'title' => $info->title,
			'tags' => @implode(",", $info->tags),
			'duration' => array(
				'raw' => $info->duration,
				'format' => toHMS($info->duration)
			),
			'artist' => $info->uploader
		)); exit;		
	break;
	case "local":
		$POST = @json_decode(@json_encode($_POST));
		$ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
		$fileid  = $POST->ID . '.' . time() . '.' . rand(123456789,1234567890);
		$tmpFile = $_FILES['file']['tmp_name'];
		$audiofile = $tmpDir . $fileid . '.audio';
		$filesize = 0;
		$filename = $POST->ID . '.' . rand(123456789,1234567890) . '.' . $POST->format;
		if(!empty($tmpFile)){
			if(@move_uploaded_file($tmpFile, $audiofile)){
				$quality = explode(",", $POST->quality);
				foreach($quality as $Q):
					$audio = $dataDir . $Q . '.' . $filename;
					if(@file_exists($audio)){ $filesize += @filesize($audio); continue; }
					$cmd = getFFMPEG() . " -i '" . $audiofile . "' -f " . $POST->format . " -b:a " . $Q . "K -vn '" . $audio . "'"; 
					if($POST->meta->add=='yes'){
						$cmd .= " -metadata";	
						foreach($POST->meta->data as $key => $val):
							$cmd .= " " . $key . "='" . escapeshellarg($val) . "'";
						endforeach;				
					}
					@exec($cmd, $xutput, $exit);			
					$filesize += @filesize($audio);
				endforeach;						
				//CheckSpace		
				
				//Get Duration
				$cmd = getFFMPEG() . " -i '".$audiofile."' 2>&1 | grep \"Duration\""; 
				@exec($cmd, $output, $exit); 
				@list($duration, $start, $bitrate) = explode(",", preg_replace('/^Duration:|start:|bitrate:|kb\/s/', '', preg_replace('/\s+/', '', $output[0])));
				@list($hours, $mints, $secs) = explode(":", $duration);
				$duration = $hours * 3600 + $mints * 60 + $secs;
				@unlink($audiofile);
				$title = pathinfo($_FILES['file']['name'], PATHINFO_FILENAME);
				echo JSON(array(
					'kind' => 'zuz#uploadResponse',
					'source' => 'local',
					'id' => $POST->ID,
					'format' => $POST->format,
					'quality' => $POST->quality,
					'disk' => $filesize,
					'fileid' => $filename,
					'title' => $title,
					'tags' => $title,
					'duration' => array(
						'raw' => $duration,
						'format' => toHMS($duration)
					),
					'artist' => null
				)); exit;		
		
			}
		}
	break;
endswitch;
ob_flush(); ?>