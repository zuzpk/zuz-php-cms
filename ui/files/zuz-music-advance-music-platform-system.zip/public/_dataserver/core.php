<?php
function isFuncEnabled($func){
    return is_callable($func) && false === stripos(ini_get('disable_functions'), $func);
}
function getFFMPEG(){
	return trim(@exec('type -P ffmpeg'));
}
function getYTDL(){
	return trim(@exec('type -P youtube-dl'));
}
function JSON($array, $decode = false){
	if($decode==true){
		return json_decode(json_encode($array));
	}else{
		return json_encode($array, 128);
	}
}
function CheckInstallation(){
	$EXEC = isFuncEnabled('exec');
	$FFMPEG = empty(getFFMPEG()) ? false : true;
	$YTDL = empty(getYTDL()) ? false : true;
	echo JSON(array(
		'exec' => $EXEC,
		'ffmpeg' => $FFMPEG,
		'ytdl' => $YTDL
	)); exit;	
}

function isCurlAvailable(){ return function_exists('curl_version'); }

function ___CURL($url, $header = true, $timeout = 3600){
	if(isCurlAvailable()===true){
		$ch = curl_init($url);		
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		if($header==true) curl_setopt($ch, CURLOPT_HEADER, TRUE);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
		curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
		return curl_exec($ch);
	}else{
		return @file_get_contents($url);
	}
}

function toHMS($seconds) {
	$t = round($seconds);
	if(($t/3600) >= 1){
		return sprintf('%02d:%02d:%02d', ($t/3600),($t/60%60), $t%60);
	}else{
		return sprintf('%02d:%02d', ($t/60%60), $t%60);
	}
}

function checkFolders($tmpDir, $dataDir){
	if(!file_exists($tmpDir)){ 
		try{ 
			@mkdir($tmpDir, 0755, true); 
		}catch(Exception $e){
			echo JSON(array('error' => true, 'type' => 'mkdir', 'dir' => '/assets/temp/')); exit; 
		} 
	}
	if(!file_exists($dataDir)){ 
		try{ 
			@mkdir($dataDir, 0755, true); 
		}catch(Exception $e){
			echo JSON(array('error' => true, 'type' => 'mkdir', 'dir' => '/assets/tracks/')); exit; 
		} 
	}
	if(!is_writable($tmpDir)){ 
		if(!@chmod($tmpDir, 0777)){
			echo JSON(array('error' => true, 'type' => 'chmod', 'dir' => '/assets/temp/')); exit; 
		}
	}
	if(!is_writable($tmpDir)){ 
		if(!@chmod($tmpDir, 0777)){
			echo JSON(array('error' => true, 'type' => 'chmod', 'dir' => '/assets/tracks/')); exit; 
		}
	}
}

function safe_b64encode($string) {
    $data = base64_encode($string);
    $data = str_replace(array('+','/','='),array('-','_',''),$data);
	return $data;
}
	
function safe_b64decode($string){
	$data = str_replace(array('-','_'),array('+','/'),$string);
	$mod4 = strlen($data) % 4;
	if ($mod4) {
		$data .= substr('====', $mod4);
	}
	return base64_decode($data);
}

function encode($value, $ENCRYPT_KEY){ 
	if(!$value){return false;}
	$text = $value;
	if(function_exists('mcrypt_encrypt')){
		$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
		$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
		$crypttext = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($ENCRYPT_KEY), $text, MCRYPT_MODE_ECB, $iv);
		return trim(safe_b64encode($crypttext)); 
	}else if(function_exists('openssl_encrypt')){
		$iv = substr(md5($ENCRYPTION_KEY), 0, 16);
		$output = openssl_encrypt($value, "AES-256-CBC", $ENCRYPTION_KEY, 0, $iv);
        return trim(safe_b64encode($output));
	}else{
		return trim(safe_b64encode($value));
	}
}
	 
function decode($value, $ENCRYPT_KEY){
	if(!$value){return false;}
	if(function_exists('mcrypt_encrypt')){
		$crypttext = safe_b64decode($value); 
		$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
		$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
		$decrypttext = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, md5($ENCRYPT_KEY), $crypttext, MCRYPT_MODE_ECB, $iv);
		return trim($decrypttext);
	}else if(function_exists('openssl_encrypt')){
		$iv = substr(md5($ENCRYPTION_KEY), 0, 16);
		return openssl_decrypt(safe_b64decode($value), "AES-256-CBC", $ENCRYPTION_KEY, 0, $iv);
	}else{
		return safe_b64decode($value);
	}
}

function stream($location, $filename, $mimeType = 'application/octet-stream'){
	if(!file_exists($location)){ header ("HTTP/1.1 404 Not Found"); return; }		
	$size	= filesize($location);
	$time	= date('r', filemtime($location));		
	$fm		= @fopen($location, 'rb');
	if(!$fm){ header ("HTTP/1.1 505 Internal server error"); return; }		
	$begin	= 0;
	$end	= $size - 1;		
	if(isset($_SERVER['HTTP_RANGE'])){
		if (preg_match('/bytes=\h*(\d+)-(\d*)[\D.*]?/i', $_SERVER['HTTP_RANGE'], $matches)){
			$begin	= intval($matches[1]);
			if (!empty($matches[2])){
				$end	= intval($matches[2]);
			}
		}
	}
	if (isset($_SERVER['HTTP_RANGE'])){
		header('HTTP/1.1 206 Partial Content');
	}else{
		header('HTTP/1.1 200 OK');
	}	
	header("Content-Type: $mimeType"); 
	header('Cache-Control: public, must-revalidate, max-age=0');
	header('Pragma: no-cache');  
	header('Accept-Ranges: bytes');
	header('Content-Length:' . (($end - $begin) + 1));
	if (isset($_SERVER['HTTP_RANGE'])){
		header("Content-Range: bytes $begin-$end/$size");
	}
	header("Content-Disposition: inline; filename=$filename");
	header("Content-Transfer-Encoding: binary");
	header("Last-Modified: $time");		
	$cur	= $begin;
	fseek($fm, $begin, 0);		
	while(!feof($fm) && $cur <= $end && (connection_status() == 0))
	{
		print fread($fm, min(1024 * 16, ($end - $cur) + 1));
		$cur += 1024 * 16;
	}	
}
	

?>