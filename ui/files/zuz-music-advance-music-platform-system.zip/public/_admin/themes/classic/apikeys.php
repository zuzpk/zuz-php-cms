<div class="content scrolls blurify fixed">
	<tabs id="hometabs"></tabs>
	<homecontent id="zuzroot"></homecontent>
</div>