<div class="content blurify scrolls rel">
	<tabs id="hometabs"></tabs>
	<homecontent id="zuzroot"></homecontent>
</div>