<?php
if(!defined('BASEPATH')){ define( 'BASEPATH', dirname( __FILE__ ) . '/' ); }
function get_server_protocol(){
	$http = isset($_SERVER['HTTPS']) && (strtolower($_SERVER['HTTPS']) == 'on' || strtolower($_SERVER['HTTPS']) == '1') ? 'https' : 'http';
	$protocol = $_SERVER['SERVER_PROTOCOL'];
	if(!in_array($protocol, array( 'HTTP/1.1', 'HTTP/2', 'HTTP/2.0'))){ $protocol = 'HTTP/1.0'; }
	return @json_decode(@json_encode(array('http' => $http, 'protocol' => $protocol)));
}
if(file_exists(BASEPATH . 'config.php')){
	
	/* ZMusic is Installed */	
	require_once(BASEPATH . 'config.php');
	require_once(BASEPATH . 'loader.php');	
	
}else{
	/* Installation is Pending */	
	if(!extension_loaded('mysql') && !extension_loaded('mysqli') && !extension_loaded('mysqlnd')){
		$protocol = get_server_protocol();
		header(sprintf('%s 500 Internal Server Error', $protocol), true, 500);
		header('Content-Type: text/html; charset=utf-8');
		die(('Your PHP installation appears to be missing the MySQL extension which is required by Zuz Music.' ) );
	}
	if(file_exists(BASEPATH . '__installer.php')){
		include(BASEPATH . '__installer.php');
	}else{
		echo '<!DOCTYPE html><html xmlns="http://www.w3.org/1999/xhtml">'
			. '<head>'
				. '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />'
				. '<meta name="viewport" content="width=device-width">'
				. '<title>ZMusic Broken</title>'
				. '<style type="text/css">'
					. '@font-face{font-family: "font_n";src: url("./ui/fonts/normal.woff") format("woff");}'
					. '@font-face{font-family: "font_b";src: url("./ui/fonts/bold.woff") format("woff");}'
					. '.fontb{font-family:font_b;}'
					. 'p{margin: 5px 0px;padding:0px;}'
					. '.s16{font-size:16px;}'
					. 'body{margin: 0px;padding: 0px;background: #f1f1f1;font-family: font_n, segoe ui, arial;}'
					. '.error{background: #fff;padding:40px;width: 25vw;margin: 0 auto;margin-top: 50px;text-align: center;font-size: 18px;border-radius: 3px;box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.16);}'
					. '.logo{display: block;margin: 0 auto;margin-bottom: 30px;height: 80px;}'
					. 'h2{margin: 0px;padding:0px;font-size: 18px;}'
					. '.btn{text-decoration: none;color: #fff;background: rgb(77, 175, 36);line-height: 1;padding: 8px 15px;display: table;margin-top: 20px;border: 1px #3e901c solid;border-radius: 2px;box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.31);cursor:pointer;}'
					. '.btn:hover{background:rgb(90, 187, 49);border: 1px #489e24 solid;box-shadow:0px 1px 1px rgba(0, 0, 0, 0.18);}'
				. '</style>'
			. '</head>'
			. '<body id="error-page">'
				. '<div class="error"><img src="./ui/zuz-logo.png" class="logo">ZMusic <span class="fontb">`__installer.php`</span> not found.<br>Re-upload and try again!</div>'
			. '</body>'
		. '</html>';
	}
}
?>