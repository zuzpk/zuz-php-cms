<?php 
date_default_timezone_set("UTC");
ini_set("display_errors", "1");
error_reporting(E_ALL | E_STRICT);
set_time_limit(0);

if($_SERVER['REQUEST_METHOD']==='POST' || isset($_GET['update'])){
	if(!defined('BASEPATH'))
		define( 'BASEPATH', dirname( __FILE__ ) . '/' );
}
define("ZUZINC", BASEPATH . "includes/");
define("TITLE", "ZMusic v2.1 Setup");

if(file_exists(BASEPATH . 'config.php')){
	require(BASEPATH . 'config.php');
}

require(ZUZINC ."thirdparty/hashids.php");
require(ZUZINC ."thirdparty/browser.php");
require(ZUZINC ."database.php");
require(ZUZINC ."core.php");
require(ZUZINC ."functions.php");
$browser = new Browser();

function Box($message){
	return '<div class="box"><img src="./ui/zuz-logo.png" class="logo">'.$message.'</div>';
}

$NOW = time();
$ERROR = false;

//UPDATE START
if(isset($_GET['update'])){	
	if(!file_exists(BASEPATH . 'config.php')){
		$ERROR = true;
		$ERROR_MSG = Box('I think you haven\'t installed ZMusic yet :(<br />`<b>config.php</b>` not found.');
	}	
	mysqli_report(MYSQLI_REPORT_STRICT);
	$DB = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	if($DB->connect_error){
		echo JSON(array('error' => true, 'message' => 'Wrong Database Information. Try with correct credentials...')); exit;	
	}
	$DB->set_charset("utf8");
	$DB->autocommit(FALSE);
	$DB->query("CREATE TABLE IF NOT EXISTS `accesstokens` (`ID` int(11) NOT NULL, `type` varchar(50) NOT NULL, `token` varchar(455) NOT NULL, `status` enum('used','pending') NOT NULL DEFAULT 'pending') ENGINE=InnoDB DEFAULT CHARSET=utf8");
	$DB->query("CREATE TABLE IF NOT EXISTS `artists` (`ID` int(11) NOT NULL, `title` varchar(255) NOT NULL, `slug` varchar(255) NOT NULL, `dp` varchar(100) NOT NULL DEFAULT 'no-dp.png', `status` enum('yes','no') NOT NULL DEFAULT 'yes') ENGINE=InnoDB DEFAULT CHARSET=utf8");	
	$DB->query("ALTER TABLE `accesstokens` ADD PRIMARY KEY (`ID`), MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT");
	$DB->query("ALTER TABLE `artists` ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `slug` (`slug`), MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT");
	$DB->query("ALTER TABLE `albums` ADD `artistid` BIGINT(100) NOT NULL DEFAULT '0' AFTER `userid`, ADD `genreid` BIGINT(255) NOT NULL DEFAULT '0' AFTER `artistid`, ADD `year` VARCHAR(10) NOT NULL DEFAULT 'none' AFTER `genreid`");
	$DB->query("ALTER TABLE `playlists` ADD `type` enum('admin','user') NOT NULL DEFAULT 'user' AFTER `ID`, CHANGE `tracks` `tracks` MEDIUMTEXT NOT NULL, ADD `privacy` enum('private','public') NOT NULL DEFAULT 'public' AFTER `tracks`");
	$DB->query("UPDATE playlists SET privacy='private' WHERE label='Favorites'");
	$DB->query("ALTER TABLE `tracks` CHANGE `type` `type` enum('youtube','local','soundcloud') NOT NULL DEFAULT 'youtube', CHANGE `title` `title` MEDIUMTEXT NOT NULL, CHANGE `slug` `slug` MEDIUMTEXT NOT NULL");	
	$DB->query("UPDATE tracks SET formats='mp3@@@128'");
	$plists = DB::SELECT("SELECT * FROM playlists WHERE status=? ORDER BY ID ASC", array('yes'), 's');
	$pouch = array();
	if($plists->count>0){
		for($i = 0; $i < count($plists->fetch); $i++):
			$ID = $plists->fetch[$i]->ID;
			$tracks = DB::SELECT("SELECT tid FROM playlists_tracks WHERE pid=? AND status=?", array($ID,'yes'), 'is');
			if($tracks->count > 0){
				$ids = [];
				for($o = 0; $o < count($tracks->fetch); $o++):
					if(!in_array($tracks->fetch[$o]->tid, $ids)){
						array_push($ids, $tracks->fetch[$o]->tid);
					}
				endfor;
				$ids = implode(",",$ids);
				$pouch[$ID] = $ids;
			}
		endfor;
	}
	foreach($pouch as $ID => $ids):
		DB::UPDATE("UPDATE playlists SET tracks=? WHERE ID=? LIMIT 1", array($ids,$ID), "si");
	endforeach;
	//$DB->query("DROP TABLE `playlists_tracks`");
	$DB->commit();
	
	setSetting('formats','ogg');
	setSetting('allow_download','yes');
	setSetting('theme','classic');
	setSetting('home_tab_default','featured');	
	setSetting('url_rewrite','track/%slug%');
	setSetting('plugins','["signin_with_google\/signin_with_google.php"]');
	setSetting('theme_admin','classic');
	setSetting('admin_allow_moderator','dashboard,inbox.list,inbox.read,inbox.reply,inbox.compose,inbox.remove,users.list,users.add,users.edit,users.remove,artists.list,artists.edit,artists.remove,albums.list,albums.edit,albums.remove,tracks.list,tracks.add,tracks.edit,tracks.remove,tracks.search,playlist.list,playlist.add,playlist.edit,playlist.remove,genre.list,genre.edit,genre.remove,themes.list,themes.edit,plugins.list,plugins.edit,servers.list,servers.edit,servers.remove,settings.list,settings.edit,apikeys.list,apikeys.reset');
	setSetting('audio_meta_data','{"title":"gMusic"}');
	setSetting('add_audio_meta','yes');
	setSetting('quality','128');
	//setSetting('','');	
}
//UPDATE END
if($_SERVER['REQUEST_METHOD']==='POST'){
	header("Content-Type: application/json");
	$POST = @json_decode(@file_get_contents("php://input"));
	switch($POST->action):
		case "database":
			if(!function_exists('mysqli_connect')){
				echo JSON(array('error' => true, 'message' => 'MySqli extension is needed for Zuz Music to work!')); exit;
			}
			try{
				mysqli_report(MYSQLI_REPORT_STRICT);
				$DB = new mysqli($POST->host, $POST->user, $POST->pass, $POST->name);
				if($DB->connect_error){
					echo JSON(array('error' => true, 'message' => 'Wrong Database Information. Try with correct credentials...')); exit;	
				}
				$DB->set_charset("utf8");
				$DB->autocommit(FALSE);
				$__key = strtolower(randit(12));
				$apiKey = encode($__key.'@@'.time(), md5($POST->appkey));				
				$DB->query("SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\"");
				$DB->query("SET AUTOCOMMIT = 0");
				$DB->query("SET time_zone = \"+00:00\"");
				$DB->query("CREATE TABLE IF NOT EXISTS `accesstokens` (`ID` int(11) NOT NULL, `type` varchar(50) NOT NULL, `token` varchar(455) NOT NULL, `status` enum('used','pending') NOT NULL DEFAULT 'pending') ENGINE=InnoDB DEFAULT CHARSET=utf8");
				$DB->query("CREATE TABLE IF NOT EXISTS `ads` (`ID` int(11) NOT NULL, `type` enum('adsense','other') NOT NULL DEFAULT 'adsense', `device` enum('desktop','mobile') NOT NULL DEFAULT 'desktop', `code` mediumtext NOT NULL, `status` enum('yes','no') NOT NULL DEFAULT 'yes') ENGINE=InnoDB DEFAULT CHARSET=utf8");
				$DB->query("CREATE TABLE IF NOT EXISTS `albums` (`ID` int(11) NOT NULL, `locked` enum('yes','no') DEFAULT 'no', `userid` bigint(255) NOT NULL DEFAULT '0', `artistid` bigint(100) NOT NULL DEFAULT '0', `genreid` bigint(255) NOT NULL DEFAULT '0', `year` varchar(10) NOT NULL DEFAULT 'none', `title` varchar(355) NOT NULL, `slug` varchar(355) NOT NULL, `photo` varchar(155) NOT NULL DEFAULT 'no-cover.png', `tracks` int(11) NOT NULL DEFAULT '0', `status` enum('yes','no') NOT NULL DEFAULT 'yes') ENGINE=InnoDB DEFAULT CHARSET=utf8");
				$DB->query("CREATE TABLE IF NOT EXISTS `artists` (`ID` int(11) NOT NULL, `title` varchar(255) NOT NULL, `slug` varchar(255) NOT NULL, `dp` varchar(100) NOT NULL DEFAULT 'no-dp.png', `status` enum('yes','no') NOT NULL DEFAULT 'yes') ENGINE=InnoDB DEFAULT CHARSET=utf8");
				$DB->query("CREATE TABLE IF NOT EXISTS `genres` (`ID` int(11) NOT NULL, `icon` varchar(50) NOT NULL DEFAULT 'no.png', `title` varchar(155) NOT NULL, `slug` varchar(155) NOT NULL, `tracks` int(11) NOT NULL DEFAULT '0', `status` enum('yes','no') NOT NULL DEFAULT 'yes') ENGINE=InnoDB DEFAULT CHARSET=utf8");
				$DB->query("CREATE TABLE IF NOT EXISTS `history` (`ID` int(11) NOT NULL, `ipaddr` varchar(50) NOT NULL DEFAULT '0.0.0.0', `uid` int(11) NOT NULL DEFAULT '0', `tid` int(11) NOT NULL DEFAULT '0', `loops` int(11) NOT NULL DEFAULT '0', `added` bigint(30) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8");
				$DB->query("CREATE TABLE IF NOT EXISTS `inbox` (`ID` int(11) NOT NULL,`token` varchar(50) NOT NULL DEFAULT 'none',`type` varchar(50) NOT NULL DEFAULT 'general', `name` varchar(100) NOT NULL DEFAULT 'none', `email` varchar(100) NOT NULL DEFAULT 'none', `subject` varchar(255) NOT NULL DEFAULT 'none', `message` mediumtext NOT NULL, `added` varchar(30) NOT NULL DEFAULT '0', `status` enum('unread','read','del') NOT NULL DEFAULT 'unread') ENGINE=InnoDB DEFAULT CHARSET=utf8");
				$DB->query("CREATE TABLE IF NOT EXISTS `ipdb` (`ID` int(11) NOT NULL, `ip_addr` varchar(30) NOT NULL, `detail` varchar(455) NOT NULL, `queries` int(11) NOT NULL DEFAULT '0', `status` enum('yes','no') NOT NULL DEFAULT 'yes') ENGINE=InnoDB DEFAULT CHARSET=utf8");
				$DB->query("CREATE TABLE IF NOT EXISTS `playlists` (`ID` int(11) NOT NULL, `type` enum('admin','user') NOT NULL DEFAULT 'user', `uid` bigint(255) NOT NULL DEFAULT '0', `label` varchar(255) NOT NULL DEFAULT 'Untitled', `tracks` mediumtext NOT NULL, `privacy` enum('private','public') NOT NULL DEFAULT 'public', `status` enum('yes','no') NOT NULL DEFAULT 'yes') ENGINE=InnoDB DEFAULT CHARSET=utf8");
				$DB->query("CREATE TABLE IF NOT EXISTS `servers` (`ID` int(11) NOT NULL, `locked` enum('yes','no') NOT NULL DEFAULT 'no', `title` varchar(255) NOT NULL DEFAULT 'none', `address` varchar(355) NOT NULL DEFAULT 'none', `tspace` bigint(50) NOT NULL DEFAULT '0', `bspace` bigint(50) NOT NULL DEFAULT '0', `added` varchar(50) NOT NULL DEFAULT '0', `status` enum('active','closed','no') NOT NULL DEFAULT 'active') ENGINE=InnoDB DEFAULT CHARSET=utf8");
				$DB->query("CREATE TABLE IF NOT EXISTS `settings` (`ID` int(11) NOT NULL, `optn` varchar(155) NOT NULL, `valu` mediumtext NOT NULL, `status` enum('yes','no') NOT NULL DEFAULT 'yes') ENGINE=InnoDB DEFAULT CHARSET=utf8");
				$DB->query("CREATE TABLE IF NOT EXISTS `tracks` (`ID` int(11) NOT NULL, `userid` int(11) NOT NULL DEFAULT '0', `type` enum('youtube','local','soundcloud') NOT NULL DEFAULT 'youtube', `ytid` varchar(100) NOT NULL, `albumid` bigint(255) NOT NULL DEFAULT '0', `genre` varchar(100) NOT NULL, `title` varchar(455) NOT NULL, `slug` varchar(455) NOT NULL, `tags` mediumtext NOT NULL, `poster` varchar(255) NOT NULL DEFAULT 'no-photo.png', `duration` varchar(20) NOT NULL, `artist` varchar(455) NOT NULL, `server` mediumtext NOT NULL, `filename` varchar(255) NOT NULL DEFAULT 'remote', `formats` varchar(100) NOT NULL DEFAULT '0', `views` int(11) NOT NULL DEFAULT '0', `added` varchar(50) NOT NULL DEFAULT '0', `status` enum('yes','no') NOT NULL DEFAULT 'yes') ENGINE=InnoDB DEFAULT CHARSET=utf8");
				$DB->query("CREATE TABLE IF NOT EXISTS `users` (`ID` int(11) NOT NULL, `token` varchar(255) NOT NULL, `ucode` varchar(20) NOT NULL DEFAULT '0', `utype` enum('admin','moderator','user') NOT NULL DEFAULT 'user', `locked` enum('yes','no') NOT NULL DEFAULT 'no', `googleid` varchar(355) NOT NULL DEFAULT '0', `googletoken` mediumtext NOT NULL, `fbid` varchar(355) NOT NULL DEFAULT '0', `email` varchar(255) NOT NULL, `password` varchar(255) NOT NULL, `fname` varchar(100) NOT NULL, `lname` varchar(100) NOT NULL, `dp` varchar(100) NOT NULL DEFAULT 'no-dp.png', `join_date` varchar(100) NOT NULL, `join_location` varchar(100) NOT NULL, `last_login` varchar(255) NOT NULL, `last_login_location` varchar(255) NOT NULL, `status` varchar(100) NOT NULL DEFAULT 'toactive') ENGINE=InnoDB DEFAULT CHARSET=utf8");
				$DB->query("CREATE TABLE IF NOT EXISTS `users_sess` (`ID` int(11) NOT NULL, `uid` bigint(255) NOT NULL DEFAULT '0', `token` varchar(455) NOT NULL, `expiry` varchar(50) NOT NULL DEFAULT '0', `uinfo` varchar(255) NOT NULL DEFAULT 'none', `status` enum('yes','no') NOT NULL DEFAULT 'yes') ENGINE=MyISAM DEFAULT CHARSET=utf8");
				$DB->query("ALTER TABLE `accesstokens` ADD PRIMARY KEY (`ID`), MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT");
				$DB->query("ALTER TABLE `ads` ADD PRIMARY KEY (`ID`), MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT");
				$DB->query("ALTER TABLE `albums` ADD PRIMARY KEY (`ID`), MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT");
				$DB->query("ALTER TABLE `artists` ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `slug` (`slug`), MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT");
				$DB->query("ALTER TABLE `genres` ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `slug` (`slug`), MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT");
				$DB->query("ALTER TABLE `history` ADD PRIMARY KEY (`ID`), MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT");
				$DB->query("ALTER TABLE `inbox` ADD PRIMARY KEY (`ID`), MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT");
				$DB->query("ALTER TABLE `ipdb` ADD PRIMARY KEY (`ID`), MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT");
				$DB->query("ALTER TABLE `playlists` ADD PRIMARY KEY (`ID`), MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT");
				$DB->query("ALTER TABLE `servers` ADD PRIMARY KEY (`ID`), MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT");
				$DB->query("ALTER TABLE `settings` ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `optn` (`optn`), MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT");
				$DB->query("ALTER TABLE `tracks` ADD PRIMARY KEY (`ID`), MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT");
				$DB->query("ALTER TABLE `users` ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `email` (`email`), MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT");
				$DB->query("ALTER TABLE `users_sess` ADD PRIMARY KEY (`ID`), MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT");
				$DB->query("INSERT INTO `genres` (`ID`, `icon`, `title`, `slug`, `tracks`, `status`) VALUES (1, 'icon.png', 'Misc', 'misc', 0, 'yes')");
				$DB->query("INSERT INTO `servers` (`ID`, `locked`, `title`, `address`, `tspace`, `bspace`, `added`, `status`) VALUES (1, 'yes', 'Zuz CDN', 'https://oyecdn.us/zuzmusic/', 10737418240, 0, UNIX_TIMESTAMP(), 'active')");
				$DB->query("INSERT INTO `settings` (`ID`, `optn`, `valu`, `status`) VALUES (1, 'site_title', '$POST->title', 'yes'), (2, 'site_slogan', '$POST->slogan', 'yes'), (3, 'site_status', 'live', 'yes'), (4, 'formats', 'ogg', 'yes'), (5, 'google_ga', 'ua-xxxxxxxx-x', 'yes'), (6, 'show_ads_per_row', '10', 'yes'), (7, 'allow_download', 'yes', 'yes'), (8, 'last_updated', UNIX_TIMESTAMP(), 'yes'), (9, 'must_signin', 'no', 'yes'), (10, 'apikey', '$__key', 'yes'), (11, 'api_key', '$apiKey', 'yes'), (12, 'site_lang', 'en', 'yes'), (13, 'show_blog', 'no', 'yes'), (14, 'theme', 'classic', 'yes'), (15, 'home_tab_default', 'featured', 'yes'), (16, 'url_rewrite', 'track/%slug%', 'yes'), (17, 'plugins', '[\"signin_with_google\\/signin_with_google.php\"]', 'yes'),
				(18, 'theme_admin', 'classic', 'yes'), (19, 'admin_allow_moderator', 'dashboard,inbox.list,inbox.read,inbox.reply,inbox.compose,inbox.remove,users.list,users.add,users.edit,users.remove,artists.list,artists.edit,artists.remove,albums.list,albums.edit,albums.remove,tracks.list,tracks.add,tracks.edit,tracks.remove,tracks.search,playlist.list,playlist.add,playlist.edit,playlist.remove,genre.list,genre.edit,genre.remove,themes.list,themes.edit,plugins.list,plugins.edit,servers.list,servers.edit,servers.remove,settings.list,settings.edit,apikeys.list,apikeys.reset', 'yes'), (20, 'audio_meta_data', '{\"title\":\"gMusic\"}', 'yes'), (21, 'add_audio_meta', 'yes', 'yes'), (22, 'quality', '128', 'yes')");
				$DB->query("COMMIT");
				$fname = $POST->title; $lname = 'User';
				if(!empty($POST->uname) && $POST->uname!="undefined"){
					if(strpos($POST->uname, "+") !== false){
						@list($fn, $ln) = explode("+", $POST->uname);
					}else{
						@list($fn, $ln) = explode(" ", $POST->uname);
					}
					$fname = $fn; $lname = $ln;
				}
				$offline = 'no';
				$nDP = "no-dp.png";				
				$geo = @json_decode(Geo()); $location = is_object($geo) ? $geo->IP.'@@'.$geo->city.'@@'.$geo->country->name : 'none@@none@@none';	
				$xdp = parse_url(getDP($POST->gid, 0)->dp);
				$dp = $xdp['scheme'].'://'.$xdp['host'];
				$dp .= str_replace("/s64-c/", "/s500-c/", $xdp['path']);
				$nDP = $POST->gid.'.jpg';
				@file_put_contents(BASEPATH . "assets/dps/".$nDP, @file_get_contents($dp));
				$utoken = randit(12); $ucode = randit(8);
				$Q = $DB->query("INSERT INTO users (token,ucode,utype,googleid,email,password,fname,lname,dp,join_date,join_location,last_login,last_login_location,status) 
				VALUES ('$utoken','$ucode','admin','$POST->gid','$POST->umail','$ucode','$fname','$lname','$nDP','$NOW','$location','$NOW','$location','active')");				
				$DB->commit();
				echo JSON(array('kind' => 'zuz#DatabaseResponse', 'message' => 'Database Connected & Tables Created Successfully...')); exit;											
			}catch(Exception $e){
				echo JSON(array('error' => true, 'message' => 'We are unable to connect to Database with provided credentials...')); exit;	
			}
		break;
		case "writeconfig":
			$https = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']=='on' ? 'https' : 'http';
			$curl = $https.'://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];						
			$uri = parse_url($curl);
			$basehost = $uri['host'];
			$baseuri = $https . '://' . $basehost . str_replace("__installer.php", "", $uri['path']);
			$data = $POST->data;
			$ytid = empty($data->yt_id) ? '__none__' : $data->yt_id;
			$_WRITE = false;
			$_WRITTEN = true;
			$config = "<?php\n"
				. "error_reporting( E_ALL | E_STRICT | E_CORE_ERROR | E_CORE_WARNING | E_COMPILE_ERROR | E_ERROR | E_WARNING | E_PARSE | E_USER_ERROR | E_USER_WARNING | E_RECOVERABLE_ERROR );\n"
				. "date_default_timezone_set(\"UTC\");\n"
				. "ini_set(\"display_errors\", \"0\");\n"				
				. "define(\"ZUZ_DEBUG\", FALSE);\n"
				. "define(\"ZUZ_VERSION\", \"2.1\");\n\n"
				. "//BASE\n"
				. "define(\"BASEURL\", \"" . $baseuri . "\");\n"
				. "define(\"COOKIE_URL\", \"/\");\n"
				. "define(\"COOKIE_URI\", \"" . $basehost . "\");\n"
				. "define(\"USER_COOKIE\", \"__udata\");\n\n"
				. "//MISC\n"
				. "define(\"ADMIN_EMAIL\", \"" . $data->umail . "\");\n"
				. "define(\"ZUZAPP_KEY\", \"" . $data->zuz_key . "\");\n"
				. "define(\"ZUZAPP_SLUG\", \"" . $data->zuz_slug . "\");\n"
				. "define(\"ENCRYPTION_KEY\", \"" . md5($data->zuz_key) . "\");\n\n"				
				. "//EMAIL SETTINGS\n"
				. "define(\"MAIL_HOST\", \"" . $data->mail->server . "\");\n"
				. "define(\"MAIL_PORT\", " . $data->mail->port . ");\n"
				. "define(\"MAIL_FROM\", \"" . $data->mail->user . "\");\n"
				. "define(\"MAIL_PASSWORD\", \"" . $data->mail->pass . "\");\n"
				. "define(\"MAIL_FOOTER\", \"&copy; " . date("Y") . " " . $data->site_title . ". All Rights Reserved.\");\n\n"
				. "//DATABASE CONFIG\n"
				. "define(\"DB_HOST\", \"" . $data->db->host . "\");\n"
				. "define(\"DB_NAME\", \"" . $data->db->name . "\");\n"
				. "define(\"DB_USER\", \"" . $data->db->user . "\");\n"
				. "define(\"DB_PASS\", \"" . $data->db->pass . "\");\n\n"
				. "//GOOGLE APP CONFIG\n"
				. "define(\"GOOGLE_APP_NAME\", \"" . $data->gapp_name . "\");\n"
				. "define(\"GOOGLE_CLIENT_ID\", \"" . $data->gclient . "\");\n"
				. "define(\"GOOGLE_SECRET_KEY\", \"" . $data->gapp_secret . "\");\n"
				. "define(\"GOOGLE_API_KEY\", \"" . $data->gapp_key . "\");\n"
				. "define(\"YOUTUBE_CHANNEL_ID\", \"" . $ytid . "\");\n"
				. "?>";
			$fp = @fopen(BASEPATH . "assets/posters/config.php","wb");	
			if($fp){				
				@fwrite($fp,$config);
				@fclose($fp);	
				if(@copy(BASEPATH . "assets/posters/config.php", BASEPATH . "config.php")){
					$_WRITE = true;	
					@unlink(BASEPATH . "assets/posters/config.php");
					echo JSON(array('kind' => 'zuz#configResponse', 'base' => $baseuri)); exit;
				}else{
					@unlink(BASEPATH . "assets/posters/config.php");
					echo JSON(array('error' => true, 'config' => $config, 'base' => $baseuri)); exit;	
				}					
			}else{
				echo JSON(array('error' => true, 'config' => $config, 'base' => $baseuri)); exit;
			}			
		break;
		case "verifyconfig":
			if(file_exists(BASEPATH . "config.php")){
				echo JSON(array('kind' => 'zuz#configResponse')); exit;
			}else{
				echo JSON(array('error' => true)); exit;
			}
		break;
	endswitch;	
	exit;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:og="http://ogp.me/ns#"  xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
<meta name="robots" content="noindex" />
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo TITLE; ?></title>	
<style>
@font-face{font-family: "font_n";src: url("./ui/fonts/normal.woff") format("woff");}
@font-face{font-family: "font_b";src: url("./ui/fonts/bold.woff") format("woff");}
.fontn{font-family:font_n;}
.fontb{font-family:font_b;}
.ibl{display: inline-block;}
.rel{position: relative;}
.abs{position: absolute;}
.fixed{position: fixed;}
.noul{text-decoration: none;}
.noulh:hover{text-decoration: underline;}
.color{color: #0072ff;}
.hide{display: none;}
.s15{font-size: 15px;}
.s13{font-size: 13px;}
.c666{color: #666;}
.iputb{margin-bottom: 8px;}
.iputc{margin-bottom: 25px;}
.spinner{
	-webkit-animation: rotate 2s linear infinite;
    animation: rotate 2s linear infinite;
    z-index: 2;
}
.spinner .path {
    stroke-dasharray: 1,150; /* 1%, 101% circumference */
    stroke-dashoffset: 0;
    stroke: rgb(86, 86, 86);
    stroke-linecap: round;
    animation: dash 1.5s ease-in-out infinite;
}
@keyframes rotate{100% { transform: rotate(360deg); }}
@-webkit-keyframes rotate{100% { -webkit-transform: rotate(360deg); }}
@keyframes dash{
    0% {stroke-dasharray: 1,150;stroke-dashoffset: 0;}
    50% {stroke-dasharray: 90,150;stroke-dashoffset: -35;}
    100% {stroke-dasharray: 90,150;stroke-dashoffset: -124;}
}
body{margin: 0px;padding: 0px;background: #f1f1f1;font-family: font_n, segoe ui, arial;}
.box{background: #fff;padding:40px;width: 25vw;margin: 0 auto;margin-top: 50px;text-align: center;font-size: 18px;border-radius: 3px;box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.16);}
.logo{display: block;margin: 0 auto;margin-bottom: 30px;height: 80px;}
.chmod{
	margin: 10px 0px;
    background: #f3f3f3;
    padding: 15px 50px 15px 60px;
    border-radius: 2px;
    position: relative;
    line-height: 1;
}
.chmod-ok{background:#daf5e3;}
.chmod-nok{background:#ffecec;}
.chmod .icn{
	background: #eee;
    line-height: 1;
    font-size: 18px;
    border-radius: 2px 0px 0px 2px;
    width: 45px;
    box-sizing: border-box;
    margin-right: 10px;
    position: absolute;
    vertical-align: bottom;
    top: 0px;
    left: 0px;
    right: 0px;
    bottom: 0px;
    color: #fff;
}
.chmod .icn .n{
	top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}
.chmod-ok .icn{background: #2ace5e;}
.chmod-nok .icn{background: #d63d3d;font-size:30px;}
.chmod .lbl{}
.form{
	background: #fff;
    margin: 0 auto;
    width: 650px;
    margin-top: 50px;
    margin-bottom: 30px;
    padding: 40px;
    box-sizing: border-box;
    border-radius: 3px;
    box-shadow: 0px 1px 1px #ddd;
}
.form ._msg{margin-top: 30px;}
.form .__msg{margin-top: 4px;}
.form .input{}
.form .imsg{margin-bottom: 20px;}
.form input[type=text]{
	width: 100%;
    border: 1px #ccc solid;
    padding: 10px 14px;
    box-sizing: border-box;
    border-radius: 3px;
    font-size: 14px;
    outline: none;
    box-shadow: 0px 1px 1px rgba(221, 221, 221, 0);
}
.form textarea{
	width: 100%;
    border: 1px #ccc solid;
    padding: 10px 14px;
    box-sizing: border-box;
    border-radius: 3px;
    outline: none;
    box-shadow: 0px 1px 1px rgba(221, 221, 221, 0);
    height: 850px;
    margin: 10px 0px 0px 0px;
    resize: none;
}
.form input[type=text]:focus{border:1px #a2a2a2 solid;}
.form .iput{}
.form .btn{
	border: 0px;
    background: #007eff;
    color: #fff;
    line-height: 1;
    padding: 7px 12px;
    border-radius: 3px;
    margin-top: 10px;
	cursor: pointer;
}
.form .btn:hover{background: #167be2;}
.form .cover{
	top: 0px;
    left: 0px;
    right: 0px;
    bottom: 0px;
    z-index: 2;
    background: rgba(255, 255, 255, 0.96);
}
.form .cover .abs{top: 50%;left: 50%; transform: translate(-50%, -50%);}
.form .ititle{margin: 20px 0px 8px 0px;}
.form .ititle-a{margin-top: 0px;}
.steps{
	border-bottom: 1px #ddd solid;
    height: 1px;
    margin: 60px 0px;
    text-align: center;
}
.steps .step{
	vertical-align: top;
    background: #fff;
    margin: 0px 6px;
    top: -25px;
    position: relative;
    border-radius: 3px;
    padding: 5px 20px;
    border: 1px #ddd solid;
}
.steps .step-on{
	background: #54a0ff;
    border: 1px #54a0ff solid;
}
.steps .step-on .lbl, .steps .step-on .ctr{color: #fff !important;}
.steps .step .ctr{
	font-size: 24px;
    line-height: 1;
	color: #555;
}
.steps .step .lbl{
	font-size: 11px;
    color: #555;
}
.toast{
	top: 20px;
    left: 0px;
    right: 0px;
	z-index: 9;
    transform: translateY(-200px);
}
.toast .msg{
	left: 50%;
    transform: translateX(-50%);
    background: #000;
    color: #fff;
    padding: 10px 20px;
    border-radius: 5px;
    z-index: 10;
	white-space: pre;
}
.checkmark {
  width: 56px;
  height: 56px;
  border-radius: 50%;
  display: block;
  stroke-width: 2;
  stroke: #fff;
  stroke-miterlimit: 10;
  margin: 25px auto;
  box-shadow: inset 0px 0px 0px #7ac142;
  animation: fill .4s ease-in-out .4s forwards, scale .3s ease-in-out .9s both;
}
.checkmark__check {
  transform-origin: 50% 50%;
  stroke-dasharray: 48;
  stroke-dashoffset: 48;
  animation: stroke 0.3s cubic-bezier(0.65, 0, 0.45, 1) 0.8s forwards;
}
@keyframes stroke {
  100% {
    stroke-dashoffset: 0;
  }
}
@keyframes scale {
  0%, 100% {
    transform: none;
  }
  50% {
    transform: scale3d(1.1, 1.1, 1);
  }
}
@keyframes fill {
  100% {
    box-shadow: inset 0px 0px 0px 200px #7ac142;
  }
}
.continue-link{margin-top: 20px;}
.install-done{text-align: center;}
</style>
</head>
<body class="<?php echo isset($_GET['update']) ? 'update' : 'install'; ?>">
<?php if($ERROR===TRUE){ echo $ERROR_MSG; exit; }
if(!isset($_GET['update'])){
	$_dirs = array(BASEPATH . '/assets/artists', BASEPATH . '/assets/covers', BASEPATH . '/assets/dps', BASEPATH . '/assets/posters');
	$DIRS = array();
	for($n = 0; $n < count($_dirs); $n++):
		$cls = '&times;'; $err = 'nok';
		if(file_exists($_dirs[$n]) && is_writeable($_dirs[$n])){ $cls = '&#10004;'; $err = 'ok'; }
		$dr = str_replace(BASEPATH, "", $_dirs[$n]);
		$DIRS[] = array(
			'icon' => $err,
			'cls' => $cls,
			'dir' => $dr
		);
	endfor;				
}
?>
<Zuz id="zuzroot"></Zuz>
<div class="toast fixed"><div class="msg abs fontn s15">Please wait...</div></div>
<script defer src="//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script defer src="//ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script defer async src="//apis.google.com/js/platform.js"></script>
<script defer src="./js/react.js"></script>
<script defer src="//unpkg.com/babel-standalone@6.26.0/babel.js" crossorigin></script>
<script defer src="./js/plugs.php?ids=axios,transit,scrollbar,cookie,cropper,md5"></script>
<?php if(!isset($_GET['update'])){ ?>
<script>
var __zuz = {
	dirs: <?php echo json_encode($DIRS); ?>
};
</script>
<?php } ?>
<script defer type="text/babel" src="./js/installer.js">