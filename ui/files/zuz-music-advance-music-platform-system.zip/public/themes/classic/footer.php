<div class="fixed toast"><div class="msg ibl s14 fontn toast-msg">please wait</div></div>
<Player id="zuzmusicplayer"></Player>
<script>
const __zuz = {
	base: "<?php echo BASEURL; ?>",
	theme: "<?php echo THEMEURL; ?>",
	nav: <?php echo getNavigation(); ?>,
	hometabs: { list: <?php echo getHomeTabs(); ?>, home: "<?php echo getSetting('home_tab_default'); ?>" },
	page: "<?php global $ZUZ_THEME_PAGE; echo $ZUZ_THEME_PAGE; ?>",
	download: <?php echo getSetting('allow_download') == 'yes' ? 'true' : 'false'; ?>,
	site_name: "<?php echo SITE_NAME; ?>",
	site_slogan: "<?php echo SITE_SLOGAN; ?>",
	googleGA: "<?php echo getSetting('google_ga'); ?>",
	me: <?php if(getUser()->is){
			echo '{
				ID: "'.$session->UID.'",
				name: {
					first: "'.$session->name->first.'",
					last: "'.$session->name->last.'",
					full: "'.$session->name->full.'"
				},
				email: "'.$session->email.'",
				dp: "'.$session->dp.'",
				library: ' . GetMyLibrary($session->ID) . '
			}';
		}else{ echo 'false'; }
	?>,
	rewrite: {
		track: (ID, slug) => {
			var pattern = "<?php echo getSetting('url_rewrite'); ?>",
			uri = pattern.replace('%slug%', slug).replace('%ID%', ID);
			return __zuz.base + uri;
		}
	},
	lang: {
		label_empty: "<?php echo lang('label_empty'); ?>",
		label_options: "<?php echo lang('options'); ?>",
		label_loadmore: "<?php echo lang('load_more'); ?>",
		label_loading: "<?php echo lang('loading'); ?>",
		label_featured: "<?php echo lang('label_featured'); ?>",
		label_newest_tracks: "<?php echo lang('label_newest_tracks'); ?>",
		label_top_tracks: "<?php echo lang('label_top_tracks'); ?>",
		label_top_albums: "<?php echo lang('label_top_albums'); ?>",
		label_title: "<?php echo lang('label_title'); ?>",
		label_artist: "<?php echo lang('label_artist'); ?>",
		label_artists: "<?php echo lang('label_artists'); ?>",
		label_album: "<?php echo lang('label_album'); ?>",
		label_duration: "<?php echo lang('label_duration'); ?>",
		label_newest_albums: "<?php echo lang('label_newest_albums'); ?>",
		label_newest_playlists: "<?php echo lang('label_newest_playlists'); ?>",
		label_playlists: "<?php echo lang('label_playlists'); ?>",
		label_genres: "<?php echo lang('genres'); ?>",
		label_signin: "<?php echo lang('signin'); ?>",
		label_tracks: "<?php echo lang('tracks'); ?>",
		label_explore: "<?php echo lang('explore'); ?>",
		label_albums: "<?php echo lang('albums'); ?>",
		label_play: "<?php echo lang('play'); ?>",
		label_shuffle: "<?php echo lang('shuffle'); ?>",
		label_add_to_play_que: "<?php echo lang('add_to_play_que'); ?>",
		label_add_to_library: "<?php echo lang('add_to_library'); ?>",
		label_library: "<?php echo lang('library'); ?>",
		label_library: "<?php echo lang('library'); ?>",
		label_play_queue: "<?php echo lang('play_queue'); ?>",
		label_save: "<?php echo lang('save'); ?>",
		label_hide: "<?php echo lang('hide'); ?>",
		label_clear: "<?php echo lang('clear'); ?>",
		label_playing_now: "<?php echo lang('playing_now'); ?>",
		label_next_up: "<?php echo lang('next_up'); ?>",
		label_empty_que: "<?php echo lang('error_empty_playque'); ?>",
		label_play_next: "<?php echo lang('play_next'); ?>",
		label_play_prev: "<?php echo lang('play_prev'); ?>",
		label_play_shuffle: "<?php echo lang('play_shuffle'); ?>",
		label_play_repeat: "<?php echo lang('play_repeat'); ?>",
		label_explore_playlists: "<?php echo lang('label_explore_playlists'); ?>",
		label_explore_albums: "<?php echo lang('label_explore_albums'); ?>",
		label_explore_tracks: "<?php echo lang('label_explore_tracks'); ?>",
		label_listen_by: "<?php echo lang('label_listen_by'); ?>",
		label_listen_album: "<?php echo lang('label_listen_album'); ?>",
		label_listen_artist: "<?php echo lang('label_listen_artist'); ?>",
		label_listen_genre: "<?php echo lang('label_listen_genre'); ?>",
		label_listen_related_tracks: "<?php echo lang('label_listen_related_tracks'); ?>",
		label_get_started: "<?php echo lang('label_get_started'); ?>",
		label_unauthorized: "<?php echo lang('label_unauthorized'); ?>",
		label_cancel: "<?php echo lang('cancel'); ?>",
		label_close: "<?php echo lang('label_close'); ?>",
		label_oops: "<?php echo lang('label_oops'); ?>",
		label_create: "<?php echo lang('label_create'); ?>",
		label_public: "<?php echo lang('label_public'); ?>",
		label_on: "<?php echo lang('label_on'); ?>",
		label_off: "<?php echo lang('label_off'); ?>",
		label_dark_theme: "<?php echo lang('label_dark_theme'); ?>",
		create_now: "<?php echo lang('create_now'); ?>",
		add_to_play_list: "<?php echo lang('add_to_play_list'); ?>",		
		new_playlist_label: "<?php echo lang('new_playlist_label'); ?>",
		new_playlist_label_placeholder: "<?php echo lang('new_playlist_label_placeholder'); ?>",
		new_playlist_title: "<?php echo lang('new_playlist_title'); ?>",
		error_playlist_label: "<?php echo lang('error_playlist_label'); ?>",
		error_playlist_duplicate: "<?php echo lang('error_playlist_duplicate'); ?>",
		titles: <?php echo json_encode(lang('titles_front')); ?>,
		search_placeholder: "<?php echo lang('search_placeholder', array(SITE_NAME)); ?>",
		enter_search_query: "<?php echo lang('enter_search_query'); ?>",
		search_results: "<?php echo lang('search_results'); ?>",
		contact_title: "<?php echo lang('contact_title', array(SITE_NAME)); ?>",
		contact_general_help: "<?php echo lang('contact_general_help'); ?>",
		contact_bug_report: "<?php echo lang('contact_bug_report'); ?>",
		contact_dmca_claim: "<?php echo lang('contact_dmca_claim'); ?>",
		contact_others: "<?php echo lang('contact_others'); ?>",
		contact_label_type: "<?php echo lang('contact_label_type'); ?>",
		contact_label_name: "<?php echo lang('contact_label_name'); ?>",
		contact_placeholder_name: "<?php echo lang('contact_placeholder_name'); ?>",
		contact_label_email: "<?php echo lang('contact_label_email'); ?>",
		contact_placeholder_email: "<?php echo lang('contact_placeholder_email'); ?>",
		contact_label_subject: "<?php echo lang('contact_label_subject'); ?>",
		contact_placeholder_subject: "<?php echo lang('contact_placeholder_subject'); ?>",
		contact_label_message: "<?php echo lang('contact_label_message'); ?>",
		contact_placeholder_message: "<?php echo lang('contact_placeholder_message'); ?>",
		contact_label_submit: "<?php echo lang('contact_label_submit'); ?>",
		view_all: "<?php echo lang('view_all'); ?>",
		signin_to_site: "<?php echo lang('signin_to_site', array(SITE_NAME)); ?>",
		click_to_try_again: "<?php echo lang('click_to_try_again'); ?>",
		error_empty_result: "<?php echo lang('error_empty_result'); ?>",
		error_unable_to_process: "<?php echo lang('error_unable_to_process'); ?>",
		error_unable_to_process_request: "<?php echo lang('error_unable_to_process_request'); ?>",
		error_playback: "<?php echo lang('error_playback'); ?>",
		error_already_in_que: "<?php echo lang('error_already_in_que'); ?>",
		error_empty_list: "<?php echo lang('error_empty_list'); ?>",
		error_empty_search_results: "<?php echo lang('error_empty_search_results'); ?>",
		error_contact_name: "<?php echo lang('error_contact_name'); ?>",
		error_contact_email: "<?php echo lang('error_contact_email'); ?>",
		error_contact_subject: "<?php echo lang('error_contact_subject'); ?>",
		error_contact_message: "<?php echo lang('error_contact_message'); ?>",
		error_empty_artists_media: "<?php echo lang('error_empty_artists_media'); ?>",
		error_unauthorized: "<?php echo lang('error_unauthorized'); ?>",
		error_signin_to_add_to_playlist: "<?php echo lang('error_signin_to_add_to_playlist'); ?>",
		error_you_have_no_playlist: "<?php echo lang('error_you_have_no_playlist'); ?>",
		msg_privacy_note: "<?php echo lang('msg_privacy_note'); ?>",
	},
	<?php
	if($session->is==false){ 
		echo 'GoogleClient: "'.GOOGLE_CLIENT_ID.'",
		signin_methods: '; getSigninMethods();
	}else{
		
	}
	?>
};
</script>
<?php getQueJavascript(); ?>
<script defer src="//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script defer src="//ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script defer src="<?php echo BASEURL . 'js/plugs.php?ids=axios,transit,scrollbar,cookie,cropper,md5'; ?>"></script>
<script defer src="<?php echo BASEURL . 'js/react.js'; ?>"></script>
<script defer src="<?php echo BASEURL . 'js/player.js'; ?>"></script>
<script defer src="<?php echo BASEURL . 'js/player.ui.js'; ?>"></script>
<script defer src="<?php echo THEMEURL . 'js/core.js'; ?>"></script>
<?php 
load_javascript_que();
CheckInstallerFile(false);
?>