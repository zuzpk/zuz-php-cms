<div class="content fixed scrolls blurify">
	<tabs id="hometabs"></tabs>
	<homecontent id="zuzroot"></homecontent>
</div>