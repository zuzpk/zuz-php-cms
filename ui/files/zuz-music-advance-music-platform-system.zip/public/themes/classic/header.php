<?php 
$session = getUser(); 
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:og="http://ogp.me/ns#"  itemscope itemtype="http://schema.org/Article" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
<meta name="robots" content="all" />
<meta name="revisit-after" content="1 days" />
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="<?php echo BASEURL; ?>ui/favicon.ico" rel="shortcut icon" />
<title><?php echo getTitle(); ?></title>
<?php getMeta(); ?>
<?php loadCSS(array(
	'remote' => array(BASEURL . 'js/player.ui.css', BASEURL . 'ui/icons.css'),
	'desktop' => array('props.css','style.css','dark.css','media.css'),
	'mobile' => array('props.css','style.css','mob.css','dark.css'),
	'tablet' => array('props.css','style.css','tab.css','dark.css')
)); 
$GoogleGaID = getSetting('google_ga');
if(!empty($GoogleGaID) && strtolower($GoogleGaID)!='ua-xxxxxxxx-x'){
echo '<!-- Global site tag (gtag.js) - Google Analytics -->'
. '<script async src="https://www.googletagmanager.com/gtag/js?id='.strtoupper($GoogleGaID).'"></script>'
. '<script>window.dataLayer = window.dataLayer || [];'
. 'function gtag(){dataLayer.push(arguments);}'
. 'gtag(\'js\', new Date());'
. '//gtag(\'config\', \''.strtoupper($GoogleGaID).'\');</script>';	
}
?>
</head>
<body class="fontn c333<?php echo isset($_COOKIE['__dark']) && $_COOKIE['__dark'] == '1' ? ' dark' : ''; echo isMobile() ? ' m' : ''; ?>">
<headbar id="headbar"></headbar>
<sidebar id="sidebar"></sidebar>