<div class="content fixed scrolls blurify">
	<tabs id="hometabs"></tabs>
	<artist id="artistbox"></artist>	
	<homecontent id="zuzroot"></homecontent>
</div>