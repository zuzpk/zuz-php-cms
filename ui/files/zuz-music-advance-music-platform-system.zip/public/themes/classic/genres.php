<div class="content fixed scrolls blurify">
	<?php $param = is_genre_page(); global $hash; ?>
	<tabs id="hometabs"></tabs>
	<homecontent id="zuzroot"<?php if($param->mod=='list'){ ?> data-slug="<?php echo $param->slug; ?>" data-start="<?php echo $hash->encode($param->page); ?>"<?php } ?>></homecontent>
</div>