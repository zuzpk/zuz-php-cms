Array.prototype.inArray = function(comparer) { 
    for(var i=0; i < this.length; i++) { 
        if(comparer(this[i])) return true; 
    }
    return false; 
}; 

Array.prototype._push = function(element, comparer) { 
    if (!this.inArray(comparer)){ this.push(element); }
};

class ZuzPlayer{
	
	constructor(config){
		this.config = config;
		this.audio = null;
		this.track = null;
		this.progress = {};
		this.que = {list: [], current: null};
		this.repeat = config.repeat || 1;		
		this.shuffle = config.shuffle || 0;		
		this.initZuz();		
	}
	
	initZuz(){
		this.audio = document.createElement("audio");	
		this.audio.setAttribute("id", "zuz-" + this.config.type + "-player");
		this.audio.setAttribute("crossorigin", "true");
		this.audio.setAttribute("preload", "metadata");
		this.audio.setAttribute("is-paused", "0");		
		document.body.appendChild(this.audio);				
	}
	
	toHMS(s){
		var h = Math.floor(s/3600); s -= h*3600;
		var m = Math.floor(s/60); s -= m*60;
		h = Math.round(h); m = Math.round(m); s = Math.round(s);
		if(h > 0){
			return (h < 10 ? '0'+h : h)+":"+(m < 10 ? '0'+m : m)+":"+(s < 10 ? '0'+s : s);
		}else{
			return (m < 10 ? '0'+m : m)+":"+(s < 10 ? '0'+s : s);
		}
	}
	
	shuffleQue(){
		var array = this.que.list;
		var currentIndex = array.length, temporaryValue, randomIndex;
		while (0 !== currentIndex){
			randomIndex = Math.floor(Math.random() * currentIndex);
			currentIndex -= 1;
			temporaryValue = array[currentIndex];
			array[currentIndex] = array[randomIndex];
			array[randomIndex] = temporaryValue;
		}		
	}

	toggleRepeat(){ 
		if(parseInt(this.repeat)===1){
			this.repeat = 0;
			this.config.on('repeatOff'); 
		}else{
			this.repeat = 1;
			this.config.on('repeatOn'); 
		}
	}
	
	toggleShuffle(){ 
		if(parseInt(this.shuffle)===1){
			this.shuffle = 0;
			this.config.on('shuffleOff'); 
		}else{
			this.shuffle = 1;
			this.config.on('shuffleOn'); 
		}
	}
		
	isPlaying(){
		return this.audio.currentTime > 0 && !this.audio.paused && !this.audio.ended && this.audio.readyState > 2;
	}
	
	setVolume(vol){
		this.audio.volume = vol;
		this.config.on("volume");
		if(this.audio.muted)
			this.audio.muted = false;
	}
	
	getVolume(){ return this.audio.volume * 100; }
	
	Mute(){
		this.audio.muted = !this.audio.muted;
		this.config.on(this.audio.muted===true?'mute':'unmute');
	}
	setCurrent(source){
		this.que.current = source;
	}
	getQue(){ return this.que; }
	addToQue(item){
		var shouldAdd = true;
		if(this.que.list.length > 0){			
			this.que.list.forEach(function(e){
				if(e.ID==item.ID){ shouldAdd = false; }
			});			
		}
		if(shouldAdd===true){
			this.que.list.push(item);
			this.config.on("playqueupdate");			
			return true;
		}		
		return false;
	}
	removeFromQue(ID){
		var self = this;
		if(this.que.list.length > 0){
			var index = 0;
			this.que.list.forEach(function(e){
				if(e.ID==ID){
					self.que.list.splice(index, 1);
				}
				index++;
			});
		}
		this.config.on("playqueupdate");
	}
	clearQue(trigger){
		var self = this;
		self.audio.pause();
		self.que.current = null;
		self.que.list = [];
		if(trigger && trigger===true)
			this.config.on("onplayqueclear");
	}
	getQueIndex(ID){
		var index = 0, n = 0;
		this.que.list.forEach(function(e){
			if(e.ID==ID){ index = n; }
			n++;
		});
		return index;
	}
	
	isNext(){
		var self = this;
		if(self.que.list.length > 1){
			var index = self.getQueIndex(self.que.current.ID) + 1;
			return typeof self.que.list[index] === 'undefined' ? false : true;
		}
		return false;		
	}
	
	isPrev(){
		var self = this;
		if(self.que.list.length > 1){
			var index = self.getQueIndex(self.que.current.ID) - 1;
			return typeof self.que.list[index] === 'undefined' ? false : true;
		}
		return false;		
	}
	
	playPrev(){
		var self = this;
		var index = self.getQueIndex(self.que.current.ID) - 1;
		if(typeof self.que.list[index] === 'undefined'){
			index = 0;
		}
		self.setTrack(self.que.list[index]);
	}
	
	playNext(){
		var self = this, index, source;
		if(self.que.list.length > 1){
			/*if(self.shuffle==1){
				var nxt = this.que.current.ID;
				while(nxt != source
				source = this.que.list
			}*/
			//self.audio.pause();
			//self.audio.currentTime = 0;
			
			var index = self.getQueIndex(self.que.current.ID) + 1;
			if(typeof self.que.list[index] === 'undefined'){
				index = 0;
			}
			if(index==0 && parseInt(self.repeat)===0) return;
			self.setTrack(self.que.list[index]);
		}else{
			if(self.repeat==1){
				self.audio.pause();
				self.audio.currentTime = 0;
				self.Play();
			}
		}			
	}
	
	setTrack(source){
		var self = this;		
		this.config.on('loading');		
		if(null === this.track){
			this.track = document.createElement("source");		
			this.track.setAttribute("id", "zuz"+this.config.type+"source" + (source.quality || 128));
			this.audio.appendChild(this.track);			
			this.audio.addEventListener('loadedmetadata', function(e){
				self.progress.duration = self.audio.duration;
				self.onReady()
			});
			this.audio.addEventListener('timeupdate', function(){
				self.progress.percent = this.currentTime * 100 / this.duration;
				self.progress.current = {
					raw: this.currentTime,
					hms: self.toHMS(this.currentTime)
				};
				self.config.on("progress");
			});
			this.audio.addEventListener('progress', function(){
				if(this.readyState === 4 && this.buffered.length){
					self.progress.buffered = this.buffered.end(0) * 100 / this.duration;
					self.config.on("buffer");
				}			
			});
			this.audio.addEventListener('error', function(e){
				self.config.on('error');
			});
			this.onEnded = function(e){
				//self.audio.removeEventListener('ended', self.onEnded);
				self.config.on('ended');
				self.playNext();			
			};
			this.audio.addEventListener('ended', this.onEnded);
			this.track.addEventListener('error', function(e){
				self.config.on('error');
			});		
		
		}		
		if(this.track.src==source.stream) return;
		this.audio.pause();
		this.track.src = source.stream;		
		this.audio.currentTime = 0;
		this.audio.preload = true;
		this.audio.load();
		
		//Add to QUE
		this.setCurrent(source);
		this.addToQue(source);
		this.config.on("playqueupdate");
		
		parseInt(this.shuffle)===1 ? this.config.on('shuffleOn') : this.config.on('shuffleOff');
		parseInt(this.repeat)===1 ? this.config.on('repeatOn') : this.config.on('repeatOff');
		
	}	
	
	Play(){
		var self = this;
		this.config.on('playing');
		this.audio.play()
		.catch((e) => {
			console.log(e);
			self.config.on('error');
		});
		this.audio.setAttribute("is-paused", "0");
	}
	
	Pause(){
		this.config.on('paused');
		this.audio.pause();
		this.audio.setAttribute("is-paused", "1");
	}
	
	getDuration(raw){
		var dur = this.progress.duration || this.audio.duration || 0;
		return raw === true ? parseFloat(dur) : this.toHMS(parseFloat(dur));
	}
	
	getProgress(){ return this.progress; }
	
	Seek(time){
		if(!this.audio) return;
		this.audio.currentTime = time;
	}
	
	onReady(){
		var self = this;		
		this.config.on('ready');
		this.config.on('buffering');
		this.audio.volume = parseFloat(zuz.getCookie('__volume')) || this.config.volume || 1;
		this.config.on("volume", true);		
		this.audio.muted = zuz.getCookie('__muted') === 'true';
		this.config.on(this.audio.muted===true?'mute':'unmute');
		setTimeout(function(){
			self.config.on('loaded');
			if(!self.isPlaying()){
				if(self.audio.getAttribute("is-paused")=="1")
					self.config.on("ready");
				else
					self.Play();
			}
		}, 500);
	}
		
};