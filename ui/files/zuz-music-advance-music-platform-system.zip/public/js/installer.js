var tost = null;
const Post = (uri, _data, onSuccess, onError, _timeout) => {
	var config = {
		method: 'post', url: uri, data: _data,
		timeout: undefined===_timeout || 'undefined' === typeof _timeout ? 60 * 4 * 1000 : 60 * _timeout * 1000
	};
	axios(config)		
	.then(function(response){ onSuccess(response); })
	.catch(function(error){ onError(error); });
} 
const toast = (msg, tout, ico) => {
	clearTimeout(tost)
	$(".toast .msg").html(msg);
	$("div.toast").show().transition({ y: '25px' }).transition({ y: '0px' });
	if(tout>0){ tost = setTimeout(function(){ $("div.toast").transition({ y: '-200px' }).fadeOut(400); }, tout * 1000); }
}
const OnGoogleLoad = (client, callback) => {
	if(typeof gapi != 'undefined'){
		gapi.load('auth2', function(){
			var auth2 = gapi.auth2.init({
				client_id: client, cookiepolicy: 'single_host_origin', fetch_basic_profile: true, scope: 'profile'				
			});
			auth2.then(function(){								
				$(".gappcon").hide();
				$(".gappconn").html('This account will be your admin account').show();				
				$(".connect-google-app").attr("id", "SenseWithGoogle").html("Sign in to Google").removeClass("connectGapp").show();
				auth2.attachClickHandler(document.getElementById('SenseWithGoogle'), {}, function(googleUser){						
					callback(googleUser.getBasicProfile());
				}, function(error) {  });
				$(".form .cover").hide();
			}, function(e){				
				$(".gappconn .lod").hide();
				$(".form .cover").hide();
				toast(e.details, 5);
			}).catch(function(e){
				$(".gappconn .lod").hide();
				$(".form .cover").hide();
				toast('We are unable to process your request.', 5);
			});				
		});
	}
}
const loading = (w, s) => {
	return (
		<svg className="spinner" style={{width:  w + "px", height: w + "px"}} viewBox={"0 0 44 44"} data-reactid={".0.1.0"}>
			<circle className="path" cx="22" cy="22" r="20" fill="none" strokeWidth={s} data-reactid=".0.1.0.0"></circle>
		</svg>
	);
}
const checkmark = (w) => {
	return (
		<svg className="checkmark" style={{width:  w + "px", height: w + "px"}} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
			<circle className="checkmark__circle" cx="26" cy="26" r="25" fill="none"/>
			<path className="checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
		</svg>
	)
}	
class Installer extends React.Component{
	constructor(props){
		super(props);
		this.data = {};
		this.configFile = null;
		this.base = null;
		this.state = {step: 0};
	}
	componentDidUpdate(){
		if(this.state.step==1 || this.state.step==3 || this.state.step==4 || this.state.step==5){
			$(".form .iput").val('');			
		}else if(this.state.step==2){
			$(".gapp-client").val(this.data.gclient);
			$(".zuz-admin-mail").val(this.data.umail);
		}
	}
	steps(c){
		return (
			<div className="steps rel">
				<div className={"ibl step rel" + (c==1?' step-on' : '')}>
					<div className="ctr fontl">1</div>
					<div className="lbl fontl">Permissions</div>
				</div>
				<div className={"ibl step rel" + (c==2?' step-on' : '')}>
					<div className="ctr fontl">2</div>
					<div className="lbl fontl">App Details</div>
				</div>
				<div className={"ibl step rel" + (c==3?' step-on' : '')}>
					<div className="ctr fontl">3</div>
					<div className="lbl fontl">Site Details</div>
				</div>
				<div className={"ibl step rel" + (c==4?' step-on' : '')}>
					<div className="ctr fontl">4</div>
					<div className="lbl fontl">Database</div>
				</div>
				<div className={"ibl step rel" + (c==5?' step-on' : '')}>
					<div className="ctr fontl">5</div>
					<div className="lbl fontl">Email Server</div>
				</div>
			</div>
		)
	}
	render(){
		var self = this;
		switch(this.state.step){
			case 0:
				var OK = true, form = [], msg = null;
				for(var n = 0; n < __zuz.dirs.length; n++){
					form.push(
						<div className={"chmod s15 chmod-"+__zuz.dirs[n].icon+" fontn rel"} key={'chmod-'+n}>
							<div className={"icn ibl rel"}>
								<div className="n abs" dangerouslySetInnerHTML={{__html:__zuz.dirs[n].cls}}></div>
							</div>
							<div className="lbl ibl">{__zuz.dirs[n].dir}</div>
						</div>
					);
					if(__zuz.dirs[n].icon!="ok"){ OK = false; }
				}				
				if(OK===true){
					msg = <span>All Required Directories are writeable :) <a href="javascript:;" className="noul noulh color fontb" onClick={(e)=>{this.setState({step:1});}}><b>Continue</b></a></span>;
				}else{
					msg = <span>These directories should have <b>0777</b> Permission.</span>;
				}
				return (
					<div className="form rel">
						<img src="./ui/zuz-logo.png" className="logo" />
						{this.steps(1)}
						{form}
						<div className="_msg fontn s15">{msg}</div>
					</div>
				);
			break;
			case 1:
				var form = <div className="rel input gapp-detail">					
					<input type="text" defaultValue={''} onChange={(e)=>{
						e.currentTarget.value==''?$(".connect-google-app").hide():$(".connect-google-app").show();
					}} placeholder="Google App OAuth Client ID" className="iput iputb gappclient fontb" />
					<a href="javascript:;" className="noul noulh s15 color fontb hide connect-google-app" onClick={(e)=>{
						var client = $(".gappclient").val();
						if(client==''){
							$(".gappclient").focus();
						}else{
							$(".form .cover").show();							
							OnGoogleLoad(client, function(gool){
								self.data = {
									gclient: client,
									gid: gool.getId(),
									umail: gool.getEmail(),						
									uname: gool.getName() || 'undefined'
								};				
								self.setState({step:2});
							});
						}
					}}>Connect Google App</a>
					<div className="s15 __msg gappcon fontn">
						If you haven't created Google App Yet;
						&nbsp;<a href="https://console.developers.google.com/apis/dashboard" target="_blank" className="noul noulh color fontb">Goto Google App Console</a>
					</div>
					<div className="__msg fontn s15 gappconn hide">Loading...</div>					
				</div>;
				return (
					<div className="form rel">
						<div className="abs cover hide"><div className="lod abs">{loading(50, 2)}</div></div>
						<img src="./ui/zuz-logo.png" className="logo" />
						{this.steps(2)}
						{form}						
					</div>
				);
			break;
			case 2:
				var form = <div className="rel app-details">					
					<div className="ititle ititle-b fontb s15">Google App Details</div>
					<input type="text" defaultValue={self.data.gclient} onChange={(e)=>{}} placeholder="GMail oAuth Client ID" className="iput iputb gapp-client fontb s15" />					
					<input type="text" defaultValue={self.data.mail} onChange={(e)=>{}} placeholder="Google Account Address" className="iput iputb zuz-admin-mail fontb s15" />
					<div className="imsg fontn c666 s13">This will be your admin account</div>										
					<input type="text" defaultValue={''} onChange={(e)=>{}} placeholder="Google App Name" className="iput iputb google-app-name fontb s15" />
					<input type="text" defaultValue={''} onChange={(e)=>{}} placeholder="Google App Secret" className="iput iputb google-app-secret fontb s15" />
					<input type="text" defaultValue={''} onChange={(e)=>{}} placeholder="Google Api Key" className="iput iputb iputc google-app-key fontb s15" />					
					<div className="ititle ititle-b fontb s15">Zuz App Details</div>
					<input type="text" defaultValue={''} onChange={(e)=>{}} placeholder="Zuz App Slug" className="iput iputb zuz-app-slug fontb s15" />
					<input type="text" defaultValue={''} onChange={(e)=>{}} placeholder="Zuz Api Key" className="iput iputb zuz-api-key fontb s15" />
					<div className="imsg fontn s13 c666">
						If you don't have Zuz Api Key;
						&nbsp;<a href="https://zuz.host/api" target="_blank" className="noul noulh fontb color s13">Goto Zuz Api Console</a>
					</div>										
					<button className="fontb s15 btn" onClick={(e)=>{
						var gname = $(".google-app-name").val(),
						gsecret = $(".google-app-secret").val(),
						gkey = $(".google-app-key").val(),
						zslug = $(".zuz-app-slug").val(),
						zkey = $(".zuz-api-key").val();
						if(gname==""){
							toast("Enter Google App Name...", 5);
							$(".google-app-name").focus();
						}else if(gsecret==""){
							toast("Enter Google App Secret...", 5);
							$(".google-app-secret").focus();
						}else if(gkey==""){
							toast("Enter Google Api Key...", 5);
							$(".google-app-key").focus();
						}else if(zslug==""){
							toast("Enter Zuz App Slug...", 5);
							$(".zuz-app-slug").focus();
						}else if(zkey==""){
							toast("Enter Zuz Api Key...", 5);
							$(".zuz-api-key").focus();
						}else{
							self.data.gapp_name = gname;
							self.data.gapp_secret = gsecret;
							self.data.gapp_key = gkey;
							self.data.zuz_slug = zslug;
							self.data.zuz_key = zkey;
							self.setState({step:3});
						}						
					}}>Continue</button>
					</div>;							
				return (					
					<div className="form rel">
						<div className="abs cover hide"><div className="lod abs">{loading(50, 2)}</div></div>
						<img src="./ui/zuz-logo.png" className="logo" />
						{this.steps(2)}
						{form}						
					</div>				
				)
			break;
			case 3:
				var form = <div className="rel app-detail">					
					<div className="ititle ititle-b fontb s15">Site Details</div>
					<input type="text" defaultValue={''} onChange={(e)=>{}} placeholder="Site Title" className="iput iputb site-title fontb s15" />
					<input type="text" defaultValue={''} onChange={(e)=>{}} placeholder="Site Slogan" className="iput iputb site-slogan fontb s15" />
					<div className="ititle fontb s15">Youtube Channel ID</div>
					<input type="text" defaultValue={''} onChange={(e)=>{}} placeholder="e.g: UCrjiOG5owkm8UNqxWhi0ZpQ" className="iput iputb yt-channel fontb s15" />
					<div className="imsg fontn s13 c666">Users will be auto subscribed to this channel! (Optional)</div>					
					<button className="fontb s15 btn" onClick={(e)=>{
						var title = $(".site-title").val(),
						slogan = $(".site-slogan").val(),
						ytid = $(".yt-channel").val();
						if(title==""){
							toast("Enter Site Title...", 5);
							$(".site-title").focus();
						}else if(slogan==""){
							toast("Enter Site Slogan...", 5);
							$(".site-slogan").focus();
						}else{
							self.data.site_title = title;
							self.data.site_slogan = slogan;
							self.data.yt_id = ytid;
							self.setState({step:4});
						}						
					}}>Continue</button>
					</div>;							
				return (					
					<div className="form rel">
						<div className="abs cover hide"><div className="lod abs">{loading(50, 2)}</div></div>
						<img src="./ui/zuz-logo.png" className="logo" />
						{this.steps(3)}
						{form}						
					</div>				
				)
			break;
			case 4:
				var form = <div className="rel db-detail">
					<input type="text" defaultValue={''} onChange={(e)=>{}} placeholder="Database Host" className="iput iputb db-host fontb s15" />
					<input type="text" defaultValue={''} onChange={(e)=>{}} placeholder="Database Name" className="iput iputb db-name fontb s15" />
					<input type="text" defaultValue={''} onChange={(e)=>{}} placeholder="Database Username" className="iput iputb db-user fontb s15" />
					<input type="text" defaultValue={''} onChange={(e)=>{}} placeholder="Database Password" className="iput iputb db-pass fontb s15" />
					<button className="fontb s15 btn" onClick={(e)=>{
						var host = $(".db-host").val(),
						name = $(".db-name").val(),
						user = $(".db-user").val(),
						pass = $(".db-pass").val();
						if(host==""){
							toast("Enter Database Host. Usually `localhost`", 5);
							$(".db-host").focus();
						}else if(name==""){
							toast("Enter Database Name...", 5);
							$(".db-name").focus();
						}else if(user==""){
							toast("Enter Database Username...", 5);
							$(".db-user").focus();
						}else if(pass==""){
							toast("Enter Database Password...", 5);
							$(".db-pass").focus();
						}else{
							$(".form .cover").show();
							self.data.db = {host: host, name: name, user: user, pass: pass};
							Post(location.href, {
								action: 'database',
								host: host,
								name: name,
								user: user,
								pass: pass,
								title: self.data.site_title,
								slogan: self.data.site_slogan,
								gid: self.data.gid,
								umail: self.data.umail,
								uname: self.data.uname,
								appkey: self.data.zuz_key
							}, function(resp){
								toast(resp.data.message, 6);
								if("kind" in resp.data){									
									self.setState({step:5}, function(){$(".form .cover").hide();});		
								}else{
									$(".form .cover").hide();									
								}
							}, function(){
								$(".form .cover").hide();
								toast('Unable to process request. Try again!', 6);
							});
							
						}						
					}}>Connect Database</button>
					</div>;							
				return (					
					<div className="form rel">
						<div className="abs cover hide"><div className="lod abs">{loading(50, 2)}</div></div>
						<img src="./ui/zuz-logo.png" className="logo" />
						{this.steps(4)}
						{form}						
					</div>				
				)
			break;
			case 5:
				var form = <div className="rel mail-detail">
					<input type="text" defaultValue={''} onChange={(e)=>{}} placeholder="Email Server e.g: mail.example.com" className="iput iputb mail-server fontb s15" />
					<input type="text" defaultValue={''} onChange={(e)=>{}} placeholder="Email Server Port e.g: 465" className="iput iputb mail-port fontb s15" />
					<input type="text" defaultValue={''} onChange={(e)=>{}} placeholder="Email Username e.g: no-reply@example.com" className="iput iputb mail-user fontb s15" />
					<input type="text" defaultValue={''} onChange={(e)=>{}} placeholder="Email Password" className="iput iputb mail-pass fontb s15" />
					<button className="fontb s15 btn" onClick={(e)=>{
						var server = $(".mail-server").val(),
						port = $(".mail-port").val(),
						user = $(".mail-user").val(),
						pass = $(".mail-pass").val();
						if(server==""){
							toast("Enter Mail Server", 5);
							$(".mail-server").focus();
						}else if(port=="" || isNaN(port)){
							toast("Enter Mail Server Port...", 5);
							$(".mail-port").focus();
						}else if(user==""){
							toast("Enter Mail Server Username...", 5);
							$(".mail-user").focus();
						}else if(pass==""){
							toast("Enter Mail Server Password...", 5);
							$(".mail-pass").focus();
						}else{
							$(".form .cover").show();
							self.data.mail = {server: server, port: port, user: user, pass: pass};
							Post(location.href, {
								action: 'writeconfig',
								data: self.data
							}, function(resp){			
								self.base = resp.data.base;							
								if("kind" in resp.data){									
									self.setState({step:7}, function(){ $(".form .cover").hide(); });
								}else{
									self.configFile = resp.data.config;									
									self.setState({step:6}, function(){ $(".form .cover").hide(); });
								}
							}, function(){
								$(".form .cover").hide();
								toast('Unable to process request. Try again!', 6);
							});
							
						}						
					}}>Continue</button>
					</div>;							
				return (					
					<div className="form rel">
						<div className="abs cover hide"><div className="lod abs">{loading(50, 2)}</div></div>
						<img src="./ui/zuz-logo.png" className="logo" />
						{this.steps(5)}
						{form}						
					</div>				
				)
			break;
			case 6:
				var form = <div className="rel s15 fontn">
					<div className="s15 fontn">Sorry, but I can't write the `<b>config.php</b>` file.</div>
					<div className="s15 fontn">Create `<b>config.php</b>` file in root folder and paste the following text and save.</div>
					<div className="s15 fontn">After you've done that, Click `<b>Verify</b>`.</div>
					<textarea className="configText fontn s13" onClick={(e)=>{e.target.select()}} readOnly={true} defaultValue={this.configFile} />
					<button className="fontb s15 btn" onClick={(e)=>{
						$(".form .cover").show();
						Post(location.href + '__installer.php', {action: 'verifyconfig'}, function(resp){
							if("kind" in resp.data){
								self.setState({step:7}, function(){ $(".form .cover").hide(); });
							}else{								
								$(".form .cover").hide();
								toast('Sorry, but I can\'t find the `<b>config.php</b>` file.', 6);
							}
						}, function(){
							$(".form .cover").hide();
							toast('Unable to process request. Try again!', 6);
						});					
					}}>Verify</button>
				</div>;
				return (					
					<div className="form rel">
						<div className="abs cover hide"><div className="lod abs">{loading(50, 2)}</div></div>
						<img src="./ui/zuz-logo.png" className="logo" />						
						{this.steps(5)}
						{form}						
					</div>				
				)
			break;
			case 7:
				var form = <div className="rel s15 fontn install-done">
					{checkmark(100)}
					<div className="s15 fontn">ZMusic Installed Successfully.</div>
					<div className="s15 fontn">Please remove `<b>__installer.php</b>` from ROOT Directory.</div>					
					<div className="continue-link"><a href={self.base} className="noul noulh color fontb s15">Click to Continue</a></div>
				</div>;
				return (					
					<div className="form rel">
						<div className="abs cover hide"><div className="lod abs">{loading(50, 2)}</div></div>
						<img src="./ui/zuz-logo.png" className="logo" />						
						{form}						
					</div>				
				)
			break;
		}
	}
}

class Updater extends React.Component{
	render(){
		var self = this;
		var form = <div className="rel s15 fontn install-done">
			{checkmark(100)}
			<div className="s15 fontn">ZMusic Updated Successfully.</div>				
			<div className="continue-link"><a href={location.origin + location.pathname.replace('__installer.php','')} className="noul noulh color fontb s15">Click to Continue</a></div>
		</div>;
		return (					
			<div className="form rel">
				<div className="abs cover hide"><div className="lod abs">{loading(50, 2)}</div></div>
				<img src="./ui/zuz-logo.png" className="logo" />						
				{form}						
			</div>				
		)		
	}
}

if(document.body.classList.contains("update")){
	ReactDOM.render(<Updater loaded={-1} />, document.getElementById("zuzroot"));	
}else{
	ReactDOM.render(<Installer loaded={-1} />, document.getElementById("zuzroot"));	
}