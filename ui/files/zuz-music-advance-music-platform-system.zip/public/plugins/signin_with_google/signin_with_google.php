<?php
/*
Plugin Name: Signin with Google
Plugin URI: https://zuz.host/marketplace/plugins/zuz-music/signin-with-google
Description: This plugin is used for signin / join user with Google oAuth
Author: the Zuz Music team
Author URI: https://zuz.host/
Version: 0.1
*/
if(!defined('ZUZ_VERSION')){ header("location: " . $_SERVER['REQUEST_SCHEME'] .'://' . $_SERVER['HTTP_HOST']); exit; }
function zuz_google(){
	$base = plugin_url(__FILE__);	
	zuz_que_javascript('googleauth', '//apis.google.com/js/platform.js', 'async defer');
	echo JSON(array(
		'id' => 'signin_with_google',
		'label' => 'Sign in with Google',
		'icon' => $base . 'google.svg',
		'async' => false,
		'callback' => 'initGoogleSignin'
	));
}

function zuz_google_callback(){
	if(getUser()->is==false){
		echo 'function _getUriParams(){
			var search = location.search.substring(1);
			if(search==\'\') return JSON.parse("{}");
			return JSON.parse(\'{"\' + search.replace(/&/g, \'","\').replace(/=/g,\'":"\') + \'"}\', function(key, value) { return key===""?value:decodeURIComponent(value) });
		} function initGoogleSignin(){
			if(typeof gapi != "undefined"){
				gapi.load("auth2", function(){
					auth2 = gapi.auth2.init({
						client_id: __zuz.GoogleClient, access_type: "offline",
						cookiepolicy: "single_host_origin", fetch_basic_profile: true, scope: "profile https://www.googleapis.com/auth/youtube",
						redirect_uri: __zuz.base + "signin/google"
					});
					var element = document.getElementById("signin_with_google");					
					auth2.attachClickHandler(element, {}, function(googleUser){
						$(".account-box .cover").fadeIn(200);
						var gool = googleUser.getBasicProfile();							
						zuz.post(zuz.app + "___ajax", 
							{
								action: "signin_with_google",
								//offline: $(".loginFireSP").attr("data-offline"),
								access_token: googleUser.getAuthResponse().access_token,
								token: googleUser.getAuthResponse().id_token,
								gid: zuz.urlencode(gool.getId()),
								em: zuz.urlencode(gool.getEmail()),
								nm: zuz.urlencode(gool.getName())
							},
							function(resp){
								zuz.toast(resp.data.message, 6);
								if("kind" in resp.data){
									var _nxt = _getUriParams(),
									_next = "next" in _nxt ? decodeURIComponent(_nxt.next) : resp.data.uri;
									window.location.href = _next;
								}else{
									$(".account-box .cover").fadeOut(200);
								}
							}, function(){ 
								$(".account-box .cover").fadeOut(200);
								zuz.toast(__zuz.lang.error_unable_to_process_request, 6); 
							});
					}, function(error) {  });
				});		
			}
		}';
	}
}

function zuz_google_signin(){
	global $POST;
	$oauth = @json_decode(___CURL('https://www.googleapis.com/oauth2/v3/tokeninfo?id_token='.$POST->token, false));
	if(is_object($oauth)){
		if(GOOGLE_CLIENT_ID!=$oauth->aud || $POST->gid!=$oauth->sub){
			echo JSON(array(
				'message' => lang('error_invalid_login_token')
			));	exit;
		}
		$offline = 'no';
		$gid = isset($oauth->sub) ? $oauth->sub : $_POST['gid'];
		$gmail = $oauth->email;
		$gstatus = $oauth->email_verified == "true" || $oauth->email_verified == true ? 'active' : 'toactivate';
		$gname = isset($oauth->name) ? $oauth->name : SITE_NAME.' User';
		$fname = SITE_NAME; $lname = 'User';
		if(!empty($gname) && $gname!="undefined"){
			if(strpos($gname, "+") !== false){
				@list($fn, $ln) = explode("+", $gname);
			}else{
				@list($fn, $ln) = explode(" ", $gname);
			}
			$fname = $fn; $lname = $ln;
		}
		if(empty($gmail) || isEmail($gmail)===false){
			echo JSON(array(
				'message' => lang('error_your_email_is_invalid_or_empty')
			));	exit;
		}
		
		//Auto Subscribe to Channel If Any
		$google_token = $POST->access_token;
		if(defined('YOUTUBE_CHANNEL_ID') && !empty(YOUTUBE_CHANNEL_ID)){			
			require(__DIR__ . "/google/vendor/autoload.php");	
			$google = new Google_Client();
			$google->setClientId(GOOGLE_CLIENT_ID);
			$google->setDeveloperKey(GOOGLE_SECRET_KEY);				
            $google->setAccessToken($google_token); 								
			$googleYT = new Google_Service_YouTube($google);
			try{
				$resourceId = new Google_Service_YouTube_ResourceId();
				$resourceId->setChannelId(YOUTUBE_CHANNEL_ID);
				$resourceId->setKind('youtube#channel');
				$subscriptionSnippet = new Google_Service_YouTube_SubscriptionSnippet();
				$subscriptionSnippet->setResourceId($resourceId);		
				$subscription = new Google_Service_YouTube_Subscription();
				$subscription->setSnippet($subscriptionSnippet);
				$subscriptionResponse = $googleYT->subscriptions->insert('id,snippet', $subscription, array());
			}catch(Google_ServiceException $e){}catch(Google_Exception $e){}
		}
		$fname = empty($fname) ? SITE_NAME : $fname;
		$lname = empty($lname) ? ' ' : $lname;
		echo signup($gid, $gmail, $fname, $lname, $offline);
		exit;
	}
	echo JSON(array(
		'message' => lang('error_security_token_expired')
	)); exit;
}

hook_action('signin_method', 'zuz_google');
hook_action('zuz_que_js', 'zuz_google_callback');
hook_action('zuz_console_signin_with_google', 'zuz_google_signin');
?>