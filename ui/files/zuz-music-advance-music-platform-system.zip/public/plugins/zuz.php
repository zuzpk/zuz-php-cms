<?php
/*
Plugin Name: Hello Zuz
Plugin URI: https://zuz.host/marketplace/plugins/zuz-music/hello
Description: This is just a test plugin, Nothing do any real thing!
Author: the Zuz Music team
Author URI: https://zuz.host/
Version: 0.1
*/
?>