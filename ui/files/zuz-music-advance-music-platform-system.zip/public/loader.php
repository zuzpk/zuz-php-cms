<?php if(!defined('ZUZ_VERSION')){ header("location: " . $_SERVER['REQUEST_SCHEME'] .'://' . $_SERVER['HTTP_HOST']); exit; }

//MISC
define("CURRENT_URI", get_server_protocol()->http .'://' . $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);

//PATHS
define("THEMES_DIR", BASEPATH . "themes/");
define("PLUGINS_DIR", BASEPATH . "plugins/");
define("LANG_DIR", BASEPATH . "langs/");
define("ZUZINC", BASEPATH . "includes/");
define("ASSETS", BASEPATH . "assets/");

define("ADMINBASE", BASEPATH . "_admin/");

//THIRD PARTY LIBRARIES
require(ZUZINC ."thirdparty/hashids.php");
require(ZUZINC ."thirdparty/mobiledetect.php");
require(ZUZINC ."thirdparty/browser.php");
$device = new Mobile_Detect();
$hash = new Hashids(ENCRYPTION_KEY, 10);
$browser = new Browser();

//CORE
require(ZUZINC ."database.php");
require(ZUZINC ."core.php");
require(LANG_DIR . getSetting("site_lang").".php");
require(ZUZINC ."global.php");
require(ZUZINC ."functions.php");

//OTHERS
define("SITE_NAME", getSetting('site_title'));
define("SITE_SLOGAN", getSetting('site_slogan'));

//REST
require(ZUZINC ."query.php");
require(ZUZINC . "plugin.php");

//REDIRECT TO APPROPRIATE URL SCHEME
ssl_redirect();

if(is_signout_page()){
	COOKIE(USER_COOKIE, '__', -24*7, true);
	header("location: " . BASEURL . "?utm=exit"); exit;
}

if(zuz_restapi_request()->is){
	require(ZUZINC . "rest.php");
}else if(zuz_sitemap_request()->is){
	Sitemap();
}else if(zuz_console_request()->is){
	require(ZUZINC . "console.php");
}else if(zuz_image_request()->is){
	require(ZUZINC . "photo.php");
}else{
	require(ZUZINC . "template.php");
}
?>