<?php header("Content-type: application/json");
$POST = @json_decode(@file_get_contents("php://input"));
$session = getUser(); global $hash;
switch(zuz_console_request()->action):
	case "___ajax":
		zuzHook('zuz_console_' . $POST->action, '');
	break;
	case "__stream":
		@list($ID, $server, $filename, $format, $title) = explode("@@", decode($_GET['token']));
		if($session->is===true){
			$UID = $session->ID;
			$go = DB::SELECT("SELECT ID FROM history WHERE uid=? AND tid=? LIMIT 1", array($UID, $ID), "ii");
			if($go->count > 0){
				DB::UPDATE("UPDATE history SET loops=loops+1, added=? WHERE uid=? AND tid=? LIMIT 1", array(time(),$UID,$ID), "iii");
			}else{
				DB::INSERT("INSERT INTO history (uid,tid,loops,added) VALUES(?,?,?,?)", array($UID,$ID,"1",time()), "iiii");
				DB::UPDATE("UPDATE tracks SET views=views+1 WHERE ID=? LIMIT 1", array($ID), "i");
			}
		}else{
			$ip = myip();
			$go = DB::SELECT("SELECT ID FROM history WHERE ipaddr=? AND tid=? LIMIT 1", array($ip, $ID), "si");
			if($go->count > 0){
				DB::UPDATE("UPDATE history SET loops=loops+1, added=? WHERE ipaddr=? AND tid=? LIMIT 1", array(time(),$ip,$ID), "isi");
			}else{
				DB::INSERT("INSERT INTO history (ipaddr,tid,loops,added) VALUES(?,?,?,?)", array($ip,$ID,"1",time()), "siii");
				DB::UPDATE("UPDATE tracks SET views=views+1 WHERE ID=? LIMIT 1", array($ID), "i");
			}
		}
		$UID = $session->is===true ? $session->ID : 0;
		$ip = myip();
		$eKey = randit(12);
		$uri = DB::SELECT("SELECT address FROM servers WHERE ID=? LIMIT 1", array($server), "i")->row->address;
		$uri .= 'stream/'.$eKey.'/'.encode($filename.'@@'.$format.'@@'.$title.'@@'.time(), $eKey);			
		if(isset($_GET['__get'])){ $uri .= '&__get=true'; }
		header("location: ".$uri); exit;
	break;
	
	//FRONT END
	case "___explore":
		//playlists
		$list = DB::SELECT("SELECT * FROM playlists WHERE tracks!=? AND privacy=? AND status=? ORDER BY RAND() LIMIT 12", array("0","public","yes"), "sss");
		if($list->count > 0){
			for($n = 0; $n < count($list->fetch); $n++):
				$data['playlists'][] = toPlaylistArray($list->fetch[$n]);
			endfor;					
		}
		//genres
		$list = DB::SELECT("SELECT * FROM genres WHERE status=? ORDER BY title ASC", array("yes"), "s");
		if($list->count > 0){
			for($n = 0; $n < count($list->fetch); $n++):
				$data['genres'][] = toGenreArray($list->fetch[$n]);
			endfor;					
		}
		//albums
		$list = DB::SELECT("SELECT * FROM albums WHERE status=? ORDER BY tracks DESC LIMIT 20", array("yes"), "s");
		if($list->count > 0){
			for($n = 0; $n < count($list->fetch); $n++):
				$data['albums'][] = toAlbumArray($list->fetch[$n]);
			endfor;					
		}
		//artists
		$list = DB::SELECT("SELECT * FROM artists WHERE status=? ORDER BY RAND() LIMIT 20", array("yes"), "s");
		if($list->count > 0){
			for($n = 0; $n < count($list->fetch); $n++):
				$data['artists'][] = toArtistArray($list->fetch[$n]);
			endfor;					
		}
		echo JSON(array(
			'kind' => 'zuz#exploreResponse',
			'etag' => encode(time()),
			'list' => $data
		)); exit;
	break;
	case "___contact":
		$type = $POST->type;
		$name = $POST->name;
		$mail = $POST->mail;
		$subject = $POST->subject;
		$message = $POST->message;
		if(empty($name) || empty($mail) || empty($type) || empty($subject) || empty($message)){
			echo JSON(array('error' => lang('error_fill_all_fields'))); exit;		
		}
		switch($type):
			case "general": $type = lang('contact_general_help'); break;
			case "bug": $type = lang('contact_bug_report'); break;
			case "dmca": $type = lang('contact_dmca_claim'); break;
			case "other": $type = lang('contact_others'); break;
		endswitch;
		$msg = str_replace(PHP_EOL, "<br>", $message);
		$_mail = getMail(
			lang('mail_contact_subject', array($type)),			
			lang('mail_contact_msg', array($type, $type, $name, $mail, $subject, $msg, SITE_NAME))
		);
		SendMail(
			array('user' => MAIL_FROM, 'pass' => MAIL_PASSWORD, 'name' => SITE_NAME),
			array('mail' => ADMIN_EMAIL, 'name' => SITE_NAME),
			lang('mail_contact_subject', array($type)),
			$_mail
		);
		DB::INSERT("INSERT INTO inbox (token,type,name,email,subject,message,added) VALUES (?,?,?,?,?,?,?)", array(md5($mail),$POST->type,$name,$mail,$subject,$msg,time()), "ssssssi");
		echo JSON(array(
			'kind' => 'zuz#contactMessageSent',
			'etag' => encode(time()),
			'message' => lang('contact_email_recieved')
		)); exit;		
	break;
	case "___genres":
		$list = DB::SELECT("SELECT * FROM genres WHERE status=? ORDER BY title ASC", array("yes"), "s");
		if($list->count > 0){
			$data = array();
			for($n = 0; $n < count($list->fetch); $n++):
				$data[] = toGenreArray($list->fetch[$n]);
			endfor;	
			echo JSON(array(
				'kind' => 'zuz#genreListResponse',
				'etag' => encode(time()),
				'list' => $data
			));			
		}else{
			echo JSON(array('empty' => true));
		}
	break;
	case "___albums":
		$pageToken = $POST->pageToken;
		$start = 0; $limit = 50; $ostart = 1; $nextToken = 'none';	
		$Type = isset($POST->type) ? $POST->type : 'all';
		if($POST->ID != '__0' && $Type=='all'){
			$slug = $POST->ID;
			$album = DB::SELECT("SELECT * FROM albums WHERE slug=? AND status=? LIMIT 1", array($slug, "yes"), "ss");
			if($album->count > 0){
				echo JSON(array(
					'kind' => 'zuz#albumDetailResponse',
					'etag' => encode(time()),
					'nextToken' => 'none',
					'view' => true,
					'album' => toAlbumArray($album->row, true)
				)); exit;
			}
			echo JSON(array('empty' => true));	exit;
		}else{
			if($pageToken!='none'){ 
				$ostart = (int) $hash->decode($pageToken)[0];			
				$start = $limit * $ostart - $limit;			
			}				
			if($Type=='all'){
				$total = DB::SELECT("SELECT COUNT(ID) as total FROM albums WHERE status=?", array("yes"), "s")->row->total;
				$list = DB::SELECT("SELECT * FROM albums WHERE status=? ORDER BY ID DESC LIMIT ?,?", array("yes",$start,$limit), "sii");
			}else if($Type=='artist'){
				$_id = $hash->decode($POST->ID)[0];
				$total = DB::SELECT("SELECT COUNT(ID) as total FROM albums WHERE artistid=? AND status=?", array($_id, "yes"), "is")->row->total;
				$list = DB::SELECT("SELECT * FROM albums WHERE artistid=? AND status=? ORDER BY ID DESC LIMIT ?,?", array($_id,"yes",$start,$limit), "isii");
			}else if($Type=='genre'){
				$_id = $hash->decode($POST->ID)[0];
				$total = DB::SELECT("SELECT COUNT(ID) as total FROM albums WHERE genreid=? AND status=?", array($_id, "yes"), "is")->row->total;
				$list = DB::SELECT("SELECT * FROM albums WHERE genreid=? AND status=? ORDER BY ID DESC LIMIT ?,?", array($_id,"yes",$start,$limit), "isii");
			}
			if($list->count > 0){
				$data = array();
				for($n = 0; $n < count($list->fetch); $n++):
					$data[] = toAlbumArray($list->fetch[$n]);
				endfor;
				if(($ostart + 1) <= ceil($total / $limit)){
					$nextToken = $hash->encode($ostart+1);	
				}	
				echo JSON(array(
					'kind' => 'zuz#albumListResponse',
					'etag' => encode(time()),
					'totalResults' => $total,
					'nextToken' => $nextToken,
					'list' => $data
				));			
			}else{
				echo JSON(array('empty' => true));			
			}
		}
	break;
	case "___getplaylists":		
		$pageToken = $POST->pageToken;
		$listID = is_numeric($POST->ID) ? $POST->ID : $hash->decode($POST->ID)[0];
		if($listID > 0){
			$list = DB::SELECT("SELECT * FROM playlists WHERE status=? LIMIT 1", array("yes"), "s");
			if($list->count > 0){
				$data = toPlaylistArray($list->row);
				echo JSON(array(
					'kind' => 'zuz#playlistsResponse',
					'etag' => encode(time()),
					'view' => true,					
					'list' => $data
				));
			}else{
				echo JSON(array('empty' => true));
			}
		}else{	
			$start = 0; $limit = 75; $ostart = 1; $nextToken = 'none';
			if($pageToken!='none'){ 
				$ostart = (int) $hash->decode($pageToken)[0];			
				$start = $limit * $ostart - $limit;			
			}						
			$data = array();
			$total = DB::SELECT("SELECT COUNT(ID) as total FROM playlists WHERE tracks!=? AND privacy=? AND status=?", array("0","public","yes"), "sss")->row->total;
			$list = DB::SELECT("SELECT * FROM playlists WHERE tracks!=? AND privacy=? AND status=? ORDER BY ID DESC LIMIT ?,?", array("0","public", "yes", $start, $limit), "sssii");
			if($list->count > 0){
				for($n = 0; $n < count($list->fetch); $n++):
					$data[] = toPlaylistArray($list->fetch[$n]);
				endfor;			
				if(($ostart + 1) <= ceil($total / $limit)){
					$nextToken = $hash->encode($ostart+1);	
				}
				echo JSON(array(
					'kind' => 'zuz#playlistsResponse',
					'etag' => encode(time()),
					'totalResults' => $total,
					'nextToken' => $nextToken,
					'list' => $data
				));
			}else{
				echo JSON(array('empty' => true));
			}
		}
		exit;				
	break;
	case "___getartists":
		$pageToken = $POST->pageToken;
		if($POST->slug != '_none_'){
			$list = DB::SELECT("SELECT * FROM artists WHERE slug=? AND status=? LIMIT 1", array($POST->slug, "yes"), "ss");
			if($list->count > 0){
				$data = toArtistArray($list->row, true, true);
				echo JSON(array(
					'kind' => 'zuz#playlistsResponse',
					'etag' => encode(time()),
					'nextToken' => 'none',
					'view' => true,					
					'list' => $data
				));
			}else{
				echo JSON(array('empty' => true));
			}
		}else{	
			$start = 0; $limit = 75; $ostart = 1; $nextToken = 'none';
			if($pageToken!='none'){ 
				$ostart = (int) $hash->decode($pageToken)[0];			
				$start = $limit * $ostart - $limit;			
			}						
			$data = array();
			$total = DB::SELECT("SELECT COUNT(ID) as total FROM artists WHERE status=?", array("yes"), "s")->row->total;
			$list = DB::SELECT("SELECT * FROM artists WHERE status=? ORDER BY title ASC LIMIT ?,?", array("yes", $start, $limit), "sii");
			if($list->count > 0){
				for($n = 0; $n < count($list->fetch); $n++):
					$data[] = toArtistArray($list->fetch[$n]);
				endfor;			
				if(($ostart + 1) <= ceil($total / $limit)){
					$nextToken = $hash->encode($ostart+1);	
				}
				echo JSON(array(
					'kind' => 'zuz#artistListResponse',
					'etag' => encode(time()),
					'totalResults' => $total,
					'nextToken' => $nextToken,
					'list' => $data
				));
			}else{
				echo JSON(array('empty' => true));
			}
		}
		exit;				
	break;
	case "___homefeed":		
		$start = 0; $limit = 75;
		$data = array();		
		//featured
		$list = DB::SELECT("SELECT * FROM tracks WHERE status=? ORDER BY views DESC LIMIT 12", array("yes"), "s");
		if($list->count > 0){
			for($n = 0; $n < count($list->fetch); $n++):
				$data['featured'][] = toTrackArray($list->fetch[$n]);
			endfor;					
		}		
		//newest
		$list = DB::SELECT("SELECT * FROM tracks WHERE status=? ORDER BY ID DESC LIMIT 6", array("yes"), "s");
		if($list->count > 0){
			for($n = 0; $n < count($list->fetch); $n++):
				$data['newest'][] = toTrackArray($list->fetch[$n]);
			endfor;					
		}
		//albums
		$list = DB::SELECT("SELECT * FROM albums WHERE status=? ORDER BY tracks DESC LIMIT 20", array("yes"), "s");
		if($list->count > 0){
			for($n = 0; $n < count($list->fetch); $n++):
				$data['albums'][] = toAlbumArray($list->fetch[$n]);
			endfor;					
		}
		if(count($data)<=0){ echo JSON(array('empty' => true)); exit; }
		echo JSON(array(
			'kind' => 'zuz#trackListResponse',
			'etag' => encode(time()),
			'list' => $data
		)); exit;
	break;
	case "___tracks":		
		$chart = $POST->chart;
		$pageToken = $POST->pageToken;
		$start = 0; $limit = 75; $ostart = 1; $nextToken = 'none';
		if($pageToken!='none'){ 
			$ostart = (int) $hash->decode($pageToken)[0];			
			$start = $limit * $ostart - $limit;			
		}						
		$data = array();		
		switch($chart):
			case "all":
				$total = DB::SELECT("SELECT COUNT(ID) as total FROM tracks WHERE status=?", array("yes"), "s")->row->total;
				$list = DB::SELECT("SELECT * FROM tracks WHERE status=? ORDER BY ID DESC LIMIT ?,?", array("yes",$start,$limit), "sii");
				if($list->count > 0){
					for($n = 0; $n < count($list->fetch); $n++):
						$data[] = toTrackArray($list->fetch[$n]);
					endfor;
					if(($ostart + 1) <= ceil($total / $limit)){
						$nextToken = $hash->encode($ostart+1);	
					}
					echo JSON(array(
						'kind' => 'zuz#trackListResponse',
						'etag' => encode(time()),						
						'totalResults' => $total,
						'nextToken' => $nextToken,
						'type' => 'all',						
						'list' => $data
					));
				}else{
					echo JSON(array('empty' => true));
				}
				exit;
			break;
			case "listen":				
				$list = DB::SELECT("SELECT * FROM tracks WHERE slug=? AND status=? LIMIT 1", array($POST->ID,"yes"), "is");
				if($list->count > 0){
					$_tracks = DB::SELECT("SELECT * FROM tracks WHERE ID!=? AND genre=? AND status=? ORDER BY RAND() LIMIT 15", array($list->row->ID,$list->row->genre,"yes"), "iis");
					$tracks = array();
					for($n = 0; $n < count($_tracks->fetch); $n++):
						$tracks[] = toTrackArray($_tracks->fetch[$n]);
					endfor;
					echo JSON(array(
						'kind' => 'zuz#trackViewResponse',
						'etag' => encode(time()),						
						'nextToken' => 'none',
						'type' => 'listen',
						'track' => toTrackArray($list->row),
						'related' => $tracks
					));
				}else{
					echo JSON(array('empty' => true));
				}
				exit;
			break;
			case "byartist":
				$_id = $hash->decode($POST->ID)[0];
				$total = DB::SELECT("SELECT COUNT(ID) as total FROM tracks WHERE artist=? AND status=?", array($_id, "yes"), "is")->row->total;
				$list = DB::SELECT("SELECT * FROM tracks WHERE artist=? AND status=? ORDER BY ID DESC LIMIT ?,?", array($_id,"yes",$start,$limit), "isii");
				if($list->count > 0){
					for($n = 0; $n < count($list->fetch); $n++):
						$data[] = toTrackArray($list->fetch[$n]);
					endfor;
					if(($ostart + 1) <= ceil($total / $limit)){
						$nextToken = $hash->encode($ostart+1);	
					}
					echo JSON(array(
						'kind' => 'zuz#trackListResponse',
						'etag' => encode(time()),						
						'totalResults' => $total,
						'nextToken' => $nextToken,						
						'type' => 'artist',
						'artist' => toArtistArray(DB::SELECT("SELECT * FROM artists WHERE ID=?",array($_id),"i")->row),
						'list' => $data
					));
				}else{
					echo JSON(array('empty' => true));
				}
				exit;
			break;
			case "bygenre":
				$genre = DB::SELECT("SELECT * FROM genres WHERE slug=? LIMIT 1", array($POST->genre), "s")->row;
				$total = DB::SELECT("SELECT COUNT(ID) as total FROM tracks WHERE genre=? AND status=?", array($genre->ID,"yes"), "is")->row->total;
				$list = DB::SELECT("SELECT * FROM tracks WHERE genre=? AND status=? ORDER BY ID DESC LIMIT ?,?",
				array($genre->ID,"yes",$start,$limit), "isii");
				if($list->count > 0){
					for($n = 0; $n < count($list->fetch); $n++):
						$data[] = toTrackArray($list->fetch[$n]);
					endfor;
					if(($ostart + 1) <= ceil($total / $limit)){
						$nextToken = $hash->encode($ostart+1);	
					}
					echo JSON(array(
						'kind' => 'zuz#trackListResponse',
						'etag' => encode(time()),						
						'totalResults' => $total,
						'nextToken' => $nextToken,						
						'genre' => array(
							'ID' => $hash->encode($genre->ID),
							'title' => $genre->title,
							'link' => BASEURL . 'genre/' . $genre->slug
						),
						'list' => $data
					));
				}else{
					echo JSON(array('empty' => true));
				}
				exit;
			break;
			case "search":
				$Query = $POST->query;
				$keyword = str_replace(" ", "+", urldecode($Query));
				$q = "SELECT * FROM tracks WHERE status=? AND (";						
				$okeyword = $keyword = safeStr(str_replace("+"," ", $Query));
				$x = array_reverse(explode(" ", $keyword));	
				$keywords_set = array();
				foreach($x as $word):
					array_push($keywords_set, $word);		
				endforeach;
				$combinations = getCombinations($keywords_set);
				$c = 0;
				foreach($combinations as $newWord):
					if(!empty($newWord)){	
						if(substr($newWord, -1)==' '){ $newWord = substr($newWord, 0, -1); }
						if($c>0){	$q .= " OR "; }
						$newWord = safeStr($newWord);
						$q .= " title LIKE '%$newWord%' ";
						$c++;
					}		
				endforeach;			
				$q .= " ) ";
				$total = DB::SELECT($q, array("yes"), "s")->count;	
				$q .= " ORDER BY ";
				foreach($combinations as $newWord):
					if(!empty($newWord)){	
						if(substr($newWord, -1)==' '){ $newWord = substr($newWord, 0, -1); }
						$newWord = safeStr($newWord);
						$q .= "CASE WHEN instr(title, '$newWord') = 0 THEN 1 ELSE 0 END,";
					}
				endforeach;			
				$q .= "instr(title, '$keyword') DESC";			
				$q .= " LIMIT ?, ?";	
				$list = DB::SELECT($q, array("yes",$start,$limit), "sii");
				if($list->count > 0){
					for($n = 0; $n < count($list->fetch); $n++):
						$data[] = toTrackArray($list->fetch[$n]);
					endfor;
					if(($ostart + 1) <= ceil($total / $limit)){
						$nextToken = $hash->encode($ostart+1);	
					}
					echo JSON(array(
						'kind' => 'zuz#searchListResponse',
						'etag' => encode(time()),						
						'query' => $Query,
						'totalResults' => $total,
						'nextToken' => $nextToken,
						'list' => $data
					));
				}else{
					echo JSON(array('empty' => true));
				}
				exit;
			break;
		endswitch;
	break;
	case "___createplaylist":
		if($session->is===false){ echo JSON(array('error' => lang('error_invalid_login_token'))); exit; }
		$test = DB::SELECT("SELECT * FROM playlists WHERE uid=? AND label=? LIMIT 1", array($session->ID,$POST->name), "is");
		if($test->count > 0){
			echo JSON(array('kind' => 'zuz#alreadResponse', 'message' => lang('error_playlist_duplicate', array($POST->name)))); exit;
		}
		$privacy = $POST->privacy=='open'?'public':'private';
		$create = DB::INSERT("INSERT INTO playlists (type,uid,label,tracks,privacy) VALUES(?,?,?,?,?)",array('user',$session->ID,$POST->name,'0',$privacy),"sisss");
		if($create->result=="ok"){
			$list = DB::SELECT("SELECT * FROM playlists WHERE ID=? LIMIT 1", array($create->ID), "i")->row;
			echo JSON(array('kind' => 'zuz#newPlaylistResponse', 'list' => toPlaylistArray($list))); exit;
		}
		echo JSON(array('error' => true)); exit;
	break;
	case "___addtracktoplaylist":
		if($session->is===false){ echo JSON(array('error' => lang('error_invalid_login_token'))); exit; }
		$pid = $hash->decode($POST->pid)[0];
		$track = $hash->decode($POST->track)[0];
		$get = DB::SELECT("SELECT * FROM playlists WHERE uid=? AND status=? LIMIT 1", array($session->ID,'yes'), "is");
		if($get->count>0){
			$tracks = $get->row->tracks;
			if($tracks==0||$tracks=='0'){
				$ntracks = $track;
			}else{
				$ids = explode(",",$tracks);
				if(in_array($track,$ids)){
					echo JSON(array('error'=>true,'message'=>lang('track_already_in_this_playlist'))); exit;	
				}
				array_push($ids, $track);
				$ntracks = implode(",",$ids);
			}
			if(DB::UPDATE("UPDATE playlists SET tracks=? WHERE ID=? AND uid=? LIMIT 1", array($ntracks,$pid,$session->ID), "sii")->result=="ok"){
				echo JSON(array('kind'=>'zuz#trackAddedToPlaylist','message'=>lang('track_added_to_playlist'))); exit;
			}
			echo JSON(array('error'=>true,'message'=>lang('error_unable_to_process'))); exit;
		}else{
			echo JSON(array('error'=>true,'message'=>lang('error_you_are_not_owner_of_this_playlist'))); exit;
		}
	break;
	case "___getlibrary":
		if($session->is===false){ echo JSON(array('error' => lang('error_invalid_login_token'))); exit; }
		$pageToken = $POST->pageToken;
		$start = 0; $limit = 75; $ostart = 1; $nextToken = 'none';
		if($pageToken!='none'){ 
			$ostart = (int) $hash->decode($pageToken)[0];			
			$start = $limit * $ostart - $limit;			
		}						
		$data = array();
		$total = DB::SELECT("SELECT COUNT(ID) as total FROM playlists WHERE uid=? AND status=?", array($session->ID, "yes"), "is")->row->total;
		$list = DB::SELECT("SELECT * FROM playlists WHERE uid=? AND status=? ORDER BY ID DESC LIMIT ?,?", array($session->ID, "yes", $start, $limit), "isii");
		if($list->count > 0){
			for($n = 0; $n < count($list->fetch); $n++):
				$data[] = toPlaylistArray($list->fetch[$n]);
			endfor;			
			if(($ostart + 1) <= ceil($total / $limit)){
				$nextToken = $hash->encode($ostart+1);	
			}
			echo JSON(array(
				'kind' => 'zuz#libraryResponse',
				'etag' => encode(time()),
				'totalResults' => $total,
				'nextToken' => $nextToken,
				'list' => $data
			));
		}else{
			echo JSON(array('empty' => true));
		}
		exit;				
	break;
	
	//ADMIN END
	case "___admin_dashboard":
		if(user_can($session, 'dashboard')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		//Stats
		$totalUsers = DB::SELECT("SELECT COUNT(ID) as total FROM users WHERE status!=? AND status!=?", array("banned", "deleted"), "ss")->row->total;
		$totalAlbums = DB::SELECT("SELECT COUNT(ID) as total FROM albums WHERE status=?", array("yes"), "s")->row->total;
		$totalTracks = DB::SELECT("SELECT COUNT(ID) as total FROM tracks WHERE status=?", array("yes"), "s")->row->total;
		$totalLoops = DB::SELECT("SELECT SUM(loops) as total FROM history WHERE tid!=?", array("0"), "i")->row->total;
		$totalPlaylists = DB::SELECT("SELECT COUNT(ID) as total FROM playlists WHERE privacy=? AND status=?", array("public","yes"), "ss")->row->total;
		//Tracks
		$_tracks = DB::SELECT("SELECT * FROM tracks WHERE status=? ORDER BY ID DESC LIMIT ?", array("yes", 20), "si");
		$tracks = array();
		if($_tracks->count > 0){
			for($n = 0; $n < count($_tracks->fetch); $n++):
				$tracks[] = toTrackArray($_tracks->fetch[$n]);
			endfor;
		}
		//Users
		$_users = DB::SELECT("SELECT * FROM users ORDER BY ID DESC LIMIT ?", array(20), "i");
		$users = array();
		if($_users->count > 0){
			for($n = 0; $n < count($_users->fetch); $n++):
				$users[] = toUserArray($_users->fetch[$n], true);
			endfor;
		}
		echo JSON(array(
			'kind' => 'zuz#dashboardStats',
			'etag' => encode(time()),			
			'stats' => array(
				'users' => array(
					'label' => lang('users'),
					'count' => number_format($totalUsers)
				),				
				'albums' => array(
					'label' => lang('albums'),
					'count' => number_format($totalAlbums)
				),
				'tracks' => array(
					'label' => lang('tracks'),
					'count' => number_format($totalTracks)
				),
				'loops' => array(
					'label' => lang('loops'),
					'count' => number_format($totalLoops)
				),
				'playlists' => array(
					'label' => lang('playlists'),
					'count' => number_format($totalPlaylists)
				)				
			),
			'tracks' => $tracks,
			'users' => $users
		));
	break;
	case "___admin_getserver":
		if(user_can($session, 'tracks.add')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }		
		if($POST->type=='youtube'){
			$check = DB::SELECT("SELECT ID FROM tracks WHERE ytid=? AND status='yes' LIMIT 1", array($POST->ID), "s");
			if($check->result=="ok" && $check->count > 0){
				echo JSON(array(
					'error' => true, 
					'type' => 'already',
					'message' => lang('requested_track_already_uploaded')
				)); exit;
			}
		}
		$get = DB::SELECT("SELECT ID,address FROM servers WHERE status=? ORDER BY ID ASC LIMIT 1", array("active"), "s");	
		if($get->result=="ok"){
			echo JSON(array(
				'kind' => 'zuz#serverResponse', 
				'ID' => $hash->encode($get->row->ID),
				'token' => BASEURL . 'zuzconsole/___verifytoken?token=' . getAccessToken('upload', time() + 60),
				'uri' => $get->row->address . 'upload/' . $POST->type,
				'formats' => getSetting('formats'),
				'quality' => getSetting('quality'),
				'meta' => array(
					'add' => getSetting('add_audio_meta'),
					'data' => getSetting('audio_meta_data', true, true)
				)
			)); exit;
		}else{
			echo JSON(array('error' => true, 'type' => 'noserver', 'message' => lang('no_upload_server_found'))); exit;
		}
	break;
	case "___admin_getytlist":
		if(user_can($session, 'tracks.add')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$next = $POST->next == 'none' ? '' : '&pageToken=' . $POST->next;		
		$data = @json_decode(___CURL('https://www.googleapis.com/youtube/v3/playlistItems?key=' . GOOGLE_API_KEY . '&part=snippet,contentDetails&maxResults=50&playlistId=' . $POST->ID . $next, false));
		if(isset($data->error)){ echo JSON(array('error' => true, 'message' => lang('invalid_playlist_id'))); exit; }
		$total = $data->pageInfo->totalResults;
		$ids = array(); $nxt = '';
		$nxt = isset($data->nextPageToken) ? $data->nextPageToken : 'none';
		for($n = 0; $n < count($data->items); $n++):
			$id = $data->items[$n]->snippet->resourceId->videoId;
			if(!in_array($id, $ids)) array_push($ids, $id);
		endfor;
		echo JSON(array('kind' => 'zuz#YTPlaylistResponse', 'total' => $total, 'next' => $nxt, 'ids' => $ids)); exit;		
	break;
	case "___admin_publish_track":
		if(user_can($session, 'tracks.add')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$POST = @json_decode(@json_encode($_POST));
		$slug = slug($POST->title);
		$checkSlug = DB::SELECT("SELECT ID FROM tracks WHERE slug=? LIMIT 1", array($slug), "s");
		if($checkSlug->result=="ok" && $checkSlug->count > 0){ $slug .= '-2'; }
		$poster = $POST->source=='local' ? $POST->ID . '.' . time() . '.' . rand(12345678,1234567890) . '.jpg' : $POST->ID.'.jpg';
		if(@move_uploaded_file($_FILES['thumb']['tmp_name'], ASSETS . 'posters/' . $poster)){
			$album = $hash->decode($POST->album)[0];
			$genre = $hash->decode($POST->genre)[0];
			$artist = $hash->decode($POST->artist)[0];
			$server = $hash->decode($POST->server)[0];
			$format = $POST->format . '@@@' . $POST->quality;
			$save = DB::INSERT("INSERT INTO tracks (userid,type,ytid,albumid,genre,title,slug,tags,poster,duration,artist,server,filename,formats,added) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
			array($session->ID,$POST->source,$POST->ID,$album,$genre,$POST->title,$slug,$POST->tags,$poster,$POST->duration,$artist,$server,$POST->fileid,$format,time()),
			"issiissssiiissi");	
			if($save->result=="ok"){
				DB::UPDATE("UPDATE servers SET bspace=bspace+".$POST->disk." WHERE ID=?", array($server), "i");
				DB::UPDATE("UPDATE albums SET tracks=tracks+1 WHERE ID=?", array($album), "i");
				DB::UPDATE("UPDATE genres SET tracks=tracks+1 WHERE ID=?", array($genre), "i");
				echo JSON(array('kind' => 'zuz#trackPublishedResponse')); exit;
			}else{
				echo JSON(array('error' => true, 'message' => lang('error_track_publish_failed'))); exit;
			}
		}else{
			echo JSON(array('error' => true, 'message' => lang('error_track_publish_failed'))); exit;
		}
	break;
	case "___admin_update_track":
		if(user_can($session, 'tracks.edit')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$POST = @json_decode(@json_encode($_POST));
		$ID = $hash->decode($POST->postid)[0];
		$otrack = DB::SELECT("SELECT * FROM tracks WHERE ID=? LIMIT 1", array($ID), "i")->row;
		$poster = $ID . '.' . time() . '.' . rand(12345678,1234567890) . '.png';		
		if(@move_uploaded_file($_FILES['poster']['tmp_name'], ASSETS . 'posters/' . $poster)){
			$album = $hash->decode($POST->album)[0];
			$genre = $hash->decode($POST->genre)[0];
			$artist = $hash->decode($POST->artist)[0];			
			$title = $POST->title;
			$tags = $POST->tags;
			$save = DB::UPDATE("UPDATE tracks SET albumid=?,genre=?,title=?,artist=?,tags=?,poster=? WHERE ID=? LIMIT 1", 
			array($album,$genre,$title,$artist,$tags,$poster,$ID), "iisissi");			
			if($save->result=="ok"){
				if($otrack->albumid!=$album){
					DB::UPDATE("UPDATE albums SET tracks=tracks+1 WHERE ID=?", array($album), "i");	
					DB::UPDATE("UPDATE albums SET tracks=tracks-1 WHERE ID=?", array($otrack->albumid), "i");	
				}
				if($otrack->genre!=$genre){
					DB::UPDATE("UPDATE genres SET tracks=tracks+1 WHERE ID=?", array($genre), "i");
					DB::UPDATE("UPDATE genres SET tracks=tracks-1 WHERE ID=?", array($otrack->genre), "i");
				}
				@unlink(ASSETS . 'posters/' . $otrack->poster);
				echo JSON(array('kind' => 'zuz#trackUpdatedResponse')); exit;
			}else{
				echo JSON(array('error' => true, 'message' => lang('error_track_publish_failed'))); exit;
			}
		}else{
			echo JSON(array('error' => true, 'message' => lang('error_track_publish_failed'))); exit;
		}
	break;
	case "___admin_search_tracks":
		if(user_can($session, 'tracks.search')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$Query = $POST->query;
		$pageToken = isset($POST->pageToken) ? $POST->pageToken : 'none';
		$start = 0; $limit = 75; $ostart = 1; $nextToken = 'none';
		if($pageToken!='none'){ 
			$ostart = (int) $hash->decode($pageToken)[0];			
			$start = $limit * $ostart - $limit;			
		}						
		$keyword = str_replace(" ", "+", urldecode($Query));
		$q = "SELECT * FROM tracks WHERE status=? AND (";						
		$okeyword = $keyword = safeStr(str_replace("+"," ", $Query));
		$x = array_reverse(explode(" ", $keyword));	
		$keywords_set = array();
		foreach($x as $word):
			array_push($keywords_set, $word);		
		endforeach;
		$combinations = getCombinations($keywords_set);
		$c = 0;
		foreach($combinations as $newWord):
			if(!empty($newWord)){	
				if(substr($newWord, -1)==' '){ $newWord = substr($newWord, 0, -1); }
				if($c>0){	$q .= " OR "; }
				$newWord = safeStr($newWord);
				$q .= " title LIKE '%$newWord%' ";
				$c++;
			}		
		endforeach;			
		$q .= " ) ";
		$total = DB::SELECT($q, array("yes"), "s")->count;	
		$q .= " ORDER BY ";
		foreach($combinations as $newWord):
			if(!empty($newWord)){	
				if(substr($newWord, -1)==' '){ $newWord = substr($newWord, 0, -1); }
				$newWord = safeStr($newWord);
				$q .= "CASE WHEN instr(title, '$newWord') = 0 THEN 1 ELSE 0 END,";
			}
		endforeach;			
		$q .= "instr(title, '$keyword') DESC";			
		$q .= " LIMIT ?, ?";	
		$list = DB::SELECT($q, array("yes",$start,$limit), "sii");
		if($list->count > 0){
			for($n = 0; $n < count($list->fetch); $n++):
				$data[] = toTrackArray($list->fetch[$n]);
			endfor;
			if(($ostart + 1) <= ceil($total / $limit)){
				$nextToken = $hash->encode($ostart+1);	
			}
			echo JSON(array(
				'kind' => 'zuz#searchListResponse',
				'etag' => encode(time()),						
				'query' => $Query,
				'totalResults' => $total,
				'nextToken' => $nextToken,
				'list' => $data
			));
		}else{
			echo JSON(array('empty' => true));
		}
	break;
	case "___verifytoken":
		if(!isset($_GET['token'])){ echo JSON(array('error' => true, 'type' => 'directAccessRestricted')); exit; }
		if(verifyAccessToken($_GET['token']) === true){
			echo JSON(array('kind' => 'zuz#verifiedToken')); exit;
		}
		echo JSON(array('error' => true)); exit;
	break;
	case "___admin_inbox":
		if(user_can($session, 'inbox.list')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$pageToken = $POST->pageToken;
		$start = 0; $limit = 75; $ostart = 1; $nextToken = 'none';
		if($pageToken!='none'){ 
			$ostart = (int) $hash->decode($pageToken)[0];			
			$start = $limit * $ostart - $limit;			
		}
		$total = DB::SELECT("SELECT COUNT(ID) as total FROM inbox WHERE status!=?", array("deleted"), "s")->row->total;
		$unreadTotal = DB::SELECT("SELECT COUNT(ID) as total FROM inbox WHERE status=?", array("unread"), "s")->row->total;
		$list = DB::SELECT("SELECT * FROM inbox ORDER BY ID DESC LIMIT ?,?", array($start,$limit), "ii");
		if($list->count > 0){
			$data = array();
			for($n = 0; $n < count($list->fetch); $n++):				
				$data[] = array(
					'ID' => $hash->encode($list->fetch[$n]->ID),
					'type' => $list->fetch[$n]->type,
					'name' => cleanStr($list->fetch[$n]->name),
					'email' => cleanStr($list->fetch[$n]->email),
					'subject' => cleanStr($list->fetch[$n]->subject),
					'message' => cleanStr(strip_tags($list->fetch[$n]->message)),
					'stamp' => date('d M Y H:ma', $list->fetch[$n]->added),
					'status' => $list->fetch[$n]->status				
				);
			endfor;
			if(($ostart + 1) <= ceil($total / $limit)){
				$nextToken = $hash->encode($ostart+1);	
			}	
			echo JSON(array(
				'kind' => 'zuz#inboxList',
				'etag' => encode(time()),
				'resultsPerPage' => $limit,
				'totalResults' => $total,
				'unreadTotal' => $unreadTotal,
				'nextToken' => $nextToken,
				'list' => $data
			));
			exit;
		}
		echo JSON(array('empty' => true)); exit;
	break;
	case "___admin_get_inbox_msg":
		if(user_can($session, 'inbox.read')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$ID = (int) $hash->decode($POST->ID)[0];
		if($ID <= 0){ echo JSON(array('error' => true)); exit; }
		$msg = DB::SELECT("SELECT * FROM inbox WHERE ID=? LIMIT 1", array($ID), "i");
		if($msg->result=="ok" && $msg->count > 0){
			$msg = $msg->row;
			if($msg->status=='unread'){ DB::UPDATE("UPDATE inbox SET status=? WHERE ID=? LIMIT 1", array('read',$ID), "si"); }
			echo JSON(array(
				'kind' => 'zuz#inboxMessageResponse',
				'etag' => encode(time()),
				'message' => array(
					'ID' => $hash->encode($msg->ID),
					'type' => $msg->type,
					'name' => cleanStr($msg->name),
					'email' => cleanStr($msg->email),
					'subject' => cleanStr($msg->subject),
					'message' => cleanStr($msg->message),
					'time' => array(
						'format' => date('d M Y H:ma', $msg->added),
						'ago' => timeAgo($msg->added)
					),
					'status' => $msg->status
				)
			)); exit;
		}
		echo JSON(array('empty' => true)); exit;
	break;
	case "___admin_users":		
		if(user_can($session, 'users.list')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$pageToken = $POST->pageToken;
		$start = 0; $limit = 75; $ostart = 1; $nextToken = 'none';
		if($pageToken!='none'){ 
			$ostart = (int) $hash->decode($pageToken)[0];			
			$start = $limit * $ostart - $limit;			
		}
		$total = DB::SELECT("SELECT COUNT(ID) as total FROM users WHERE status=?", array("active"), "s")->row->total;
		$list = DB::SELECT("SELECT * FROM users WHERE status=? ORDER BY ID DESC LIMIT ?,?", array('active',$start,$limit), "sii");
		if($list->count > 0){
			$data = array();
			for($n = 0; $n < count($list->fetch); $n++):				
				$data[] = toUserArray($list->fetch[$n], true);				
			endfor;			
			echo JSON(array(
				'kind' => 'zuz#usersList',
				'etag' => encode(time()),
				'resultsPerPage' => $limit,
				'totalResults' => $total,
				'action' => $session->type == 'admin' ? 1 : 0,				
				'list' => $data
			)); exit;		
			exit;
		}
		echo JSON(array('empty' => true)); exit;
	break;	
	case "___admin_users_update":		
		if(user_can($session, 'users.edit')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$ID = $hash->decode($POST->ID)[0];
		$mod = $POST->mod;
		$value = $POST->val;
		switch($mod):
			case "ban":
				DB::UPDATE("UPDATE users SET status=? WHERE ID=? LIMIT 1", array($value,$ID), "si");
			break;
			case "utype":
				$value = (int) $value;
				if($value==0){ $value = "user"; }
				else if($value==1){ $value = "moderator"; }
				else if($value==2){ $value = "admin"; }
				DB::UPDATE("UPDATE users SET utype=? WHERE ID=? LIMIT 1", array($value,$ID), "si");
			break;
		endswitch;
		echo JSON(array('kind' => 'zuz#userUpdated', 'etag' => encode(time()), 'message' => 'User updated successfully...')); exit;
	break;
	case "___admin_albums":
		if(user_can($session, 'albums.list')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$pageToken = $POST->pageToken;
		$start = 0; $limit = 75; $ostart = 1; $nextToken = 'none';		
		if($POST->ID != '__0'){
			$slug = $POST->ID;
			$album = DB::SELECT("SELECT * FROM albums WHERE slug=? AND status=? LIMIT 1", array($slug, "yes"), "ss");
			if($album->count > 0){
				echo JSON(array(
					'kind' => 'zuz#albumDetailResponse',
					'etag' => encode(time()),
					'nextToken' => 'none',					
					'view' => true,
					'album' => toAlbumArray($album->row, true)
				)); exit;
			}
			echo JSON(array('empty' => true));	exit;
		}else{
			if($pageToken!='none'){ 
				$ostart = (int) $hash->decode($pageToken)[0];			
				$start = $limit * $ostart - $limit;			
			}				
			$total = DB::SELECT("SELECT COUNT(ID) as total FROM albums WHERE status=?", array("yes"), "s")->row->total;
			$list = DB::SELECT("SELECT * FROM albums WHERE status=? ORDER BY ID DESC LIMIT ?,?", array("yes",$start,$limit), "sii");
			if($list->count > 0){
				$data = array();
				for($n = 0; $n < count($list->fetch); $n++):
					$data[] = toAlbumArray($list->fetch[$n]);
				endfor;
				if(($ostart + 1) <= ceil($total / $limit)){
					$nextToken = $hash->encode($ostart+1);	
				}	
				echo JSON(array(
					'kind' => 'zuz#albumListResponse',
					'etag' => encode(time()),
					'totalResults' => $total,
					'resultsPerPage' => $limit,
					'nextToken' => $nextToken,
					'list' => $data
				));			
			}else{
				echo JSON(array('empty' => true));			
			}
		}
	break;
	case "___admin_albums_save":
		$POST = @json_decode(@json_encode($_POST));
		if(user_can($session, 'artists.edit')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }		
		$user = (int) $hash->decode($POST->uid)[0];
		$postid = (int) is_numeric($POST->postid) ? $POST->postid : $hash->decode($POST->postid)[0];
		$cover = $user.'.'.rand(111111,999999999).'.'.time().'.png';
		$ndp = BASEPATH . '/assets/covers/'.$cover;
		$genre = (int) $hash->decode($POST->genre)[0];
		$artist = (int) $hash->decode($POST->artist)[0];
		$name = $POST->name;
		$year = $POST->year;
		if($postid > 0){
			if(@move_uploaded_file($_FILES['cover']['tmp_name'], $ndp)){
				$update = DB::UPDATE("UPDATE albums SET artistid=?, genreid=?, year=?, title=?, photo=? WHERE ID=? LIMIT 1", array($artist, $genre, $year, $name, $cover, $postid), "iisssi");
				if($update->result=="ok"){
					$_album = DB::SELECT("SELECT * FROM albums WHERE ID=? LIMIT 1", array($postid), "i")->row;
					echo JSON(array(
						'kind' => 'zuz#artistUpdateResponse',
						'etag' => encode(time()),
						'album' => toAlbumArray($_album)
					));	exit;
				}
			}			
		}else{
			$slug = slug($name);
			$slugChk = DB::SELECT("SELECT ID FROM albums WHERE slug=? LIMIT 1", array($slug), "s");
			if($slugChk->result=="ok" && $slugChk->count > 0){ $slug .= "-2"; }
			if(@move_uploaded_file($_FILES['cover']['tmp_name'], $ndp)){
				$create = DB::INSERT("INSERT INTO albums (userid,artistid,genreid,year,title,slug,photo,status) VALUES (?,?,?,?,?,?,?,?)", array($user, $artist, $genre, $year, $name,$slug,$cover,'yes'), "iiisssss");
				if($create->result=="ok"){
					$_album = DB::SELECT("SELECT * FROM albums WHERE ID=? LIMIT 1", array($create->ID), "i")->row;
					echo JSON(array(
						'kind' => 'zuz#artistSaveResponse',
						'etag' => encode(time()),
						'album' => toAlbumArray($_album)
					));	exit;
				}
			}
		}
		echo JSON(array('error' => true));
	break;
	case "___admin_albums_del":
		if(user_can($session, 'albums.remove')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }		
		$postid = (int) $hash->decode($POST->ID)[0];
		$update = DB::UPDATE("UPDATE albums SET status=? WHERE ID=? LIMIT 1", array('no', $postid), "si");
		if($update->result=="ok"){
			echo JSON(array(
				'kind' => 'zuz#albumDeleteResponse',
				'etag' => encode(time())
			));	exit;
		}
		echo JSON(array('error' => true));
	break;
	case "___admin_artists":
		if(user_can($session, 'artists.list')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$pageToken = $POST->pageToken;
		$start = 0; $limit = 75; $ostart = 1; $nextToken = 'none';		
		if($POST->ID != '__0'){
			$ID = $POST->ID;
			$artist = DB::SELECT("SELECT * FROM artists WHERE ID=? AND status=? LIMIT 1", array($ID, "yes"), "is");
			if($artist->count > 0){
				echo JSON(array(
					'kind' => 'zuz#artistDetailResponse',
					'etag' => encode(time()),
					'nextToken' => 'none',					
					'view' => true,
					'artist' => toArtistArray($artist->row, true)
				)); exit;
			}
			echo JSON(array('empty' => true));	exit;
		}else{
			if($pageToken!='none'){ 
				$ostart = (int) $hash->decode($pageToken)[0];			
				$start = $limit * $ostart - $limit;			
			}				
			$total = DB::SELECT("SELECT COUNT(ID) as total FROM artists WHERE status=?", array("yes"), "s")->row->total;
			$list = DB::SELECT("SELECT * FROM artists WHERE status=? ORDER BY ID DESC LIMIT ?,?", array("yes",$start,$limit), "sii");
			if($list->count > 0){
				$data = array();
				for($n = 0; $n < count($list->fetch); $n++):
					$data[] = toArtistArray($list->fetch[$n]);
				endfor;
				if(($ostart + 1) <= ceil($total / $limit)){
					$nextToken = $hash->encode($ostart+1);	
				}	
				echo JSON(array(
					'kind' => 'zuz#artistListResponse',
					'etag' => encode(time()),
					'totalResults' => $total,
					'resultsPerPage' => $limit,
					'nextToken' => $nextToken,
					'list' => $data
				));			
			}else{
				echo JSON(array('empty' => true));			
			}
		}
	break;
	case "___admin_artists_save":
		$POST = @json_decode(@json_encode($_POST));
		if(user_can($session, 'artists.edit')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }		
		$user = (int) $hash->decode($POST->uid)[0];
		$postid = (int) is_numeric($POST->postid) ? $POST->postid : $hash->decode($POST->postid)[0];
		$cover = $user.'.'.rand(111111,999999999).'.'.time().'.png';
		$ndp = BASEPATH . '/assets/artists/'.$cover;
		$name = $POST->name;			
		if($postid > 0){
			if(@move_uploaded_file($_FILES['cover']['tmp_name'], $ndp)){
				$update = DB::UPDATE("UPDATE artists SET title=?, dp=? WHERE ID=? LIMIT 1", array($name,$cover,$postid), "ssi");
				if($update->result=="ok"){
					$_artist = DB::SELECT("SELECT * FROM artists WHERE ID=? LIMIT 1", array($postid), "i")->row;
					echo JSON(array(
						'kind' => 'zuz#artistUpdateResponse',
						'etag' => encode(time()),
						'artist' => toArtistArray($_artist)
					));	exit;
				}
			}			
		}else{
			$slug = slug($name);
			$slugChk = DB::SELECT("SELECT ID FROM artists WHERE slug=? LIMIT 1", array($slug), "s");
			if($slugChk->result=="ok" && $slugChk->count > 0){ $slug .= "-2"; }
			if(@move_uploaded_file($_FILES['cover']['tmp_name'], $ndp)){
				$create = DB::INSERT("INSERT INTO artists (title,slug,dp,status) VALUES (?,?,?,?)", array($name,$slug,$cover,'yes'), "ssss");
				if($create->result=="ok"){
					$_artist = DB::SELECT("SELECT * FROM artists WHERE ID=? LIMIT 1", array($create->ID), "i")->row;
					echo JSON(array(
						'kind' => 'zuz#artistSaveResponse',
						'etag' => encode(time()),
						'artist' => toArtistArray($_artist)
					));	exit;
				}
			}
		}
		echo JSON(array('error' => true));			
	break;
	case "___admin_artists_del":
		if(user_can($session, 'artists.remove')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }		
		$postid = (int) $hash->decode($POST->ID)[0];
		$update = DB::UPDATE("UPDATE artists SET status=? WHERE ID=? LIMIT 1", array('no', $postid), "si");
		if($update->result=="ok"){
			echo JSON(array(
				'kind' => 'zuz#artistDeleteResponse',
				'etag' => encode(time())
			));	exit;
		}
		echo JSON(array('error' => true));
	break;
	case "___admin_tracks_del":
		if(user_can($session, 'tracks.remove')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }		
		$postid = (int) $hash->decode($POST->ID)[0];
		$update = DB::UPDATE("UPDATE tracks SET status=? WHERE ID=? LIMIT 1", array('no', $postid), "si");
		if($update->result=="ok"){
			echo JSON(array(
				'kind' => 'zuz#trackDeleteResponse',
				'etag' => encode(time())
			));	exit;
		}
		echo JSON(array('error' => true));
	break;
	case "___admin_tracks":
		if(user_can($session, 'tracks.list')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$pageToken = $POST->pageToken;
		$start = 0; $limit = 75; $ostart = 1; $nextToken = 'none';		
		if($POST->ID != '__0'){
			$ID = $hash->decode($POST->ID)[0];
			$track = DB::SELECT("SELECT * FROM tracks WHERE ID=? AND status=? LIMIT 1", array($ID, "yes"), "is");
			if($track->count > 0){
				echo JSON(array(
					'kind' => 'zuz#trackDetailResponse',
					'etag' => encode(time()),
					'nextToken' => 'none',					
					'view' => true,
					'track' => toTrackArray($track->row, true)
				)); exit;
			}
			echo JSON(array('empty' => true));	exit;
		}else{
			if($pageToken!='none'){ 
				$ostart = (int) $hash->decode($pageToken)[0];			
				$start = $limit * $ostart - $limit;			
			}				
			$total = DB::SELECT("SELECT COUNT(ID) as total FROM tracks WHERE status=?", array("yes"), "s")->row->total;
			$list = DB::SELECT("SELECT * FROM tracks WHERE status=? ORDER BY ID DESC LIMIT ?,?", array("yes",$start,$limit), "sii");
			if($list->count > 0){
				$data = array();
				for($n = 0; $n < count($list->fetch); $n++):
					$data[] = toTrackArray($list->fetch[$n]);
				endfor;
				if(($ostart + 1) <= ceil($total / $limit)){
					$nextToken = $hash->encode($ostart+1);	
				}	
				echo JSON(array(
					'kind' => 'zuz#trackListResponse',
					'etag' => encode(time()),
					'totalResults' => $total,
					'resultsPerPage' => $limit,
					'nextToken' => $nextToken,
					'list' => $data
				));			
			}else{
				echo JSON(array('empty' => true));			
			}
		}
	break;
	case "___admin_playlists":	
		if(user_can($session, 'playlist.list')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$pageToken = $POST->pageToken;
		$listID = $POST->ID == '__0' ? $POST->ID : $hash->decode($POST->ID)[0];
		if($listID > 0){
			$list = DB::SELECT("SELECT * FROM playlists WHERE ID=? AND status=? LIMIT 1", array($listID, "yes"), "is");
			if($list->count > 0){
				$data = toPlaylistArray($list->row, true);
				echo JSON(array(
					'kind' => 'zuz#playlistsResponse',
					'etag' => encode(time()),
					'view' => true,					
					'list' => $data
				));
			}else{
				echo JSON(array('empty' => true));
			}
		}else{	
			$start = 0; $limit = 75; $ostart = 1; $nextToken = 'none';
			if($pageToken!='none'){ 
				$ostart = (int) $hash->decode($pageToken)[0];			
				$start = $limit * $ostart - $limit;			
			}						
			$data = array();
			$ptype = $POST->type;
			if($ptype=='all'){
				$total = DB::SELECT("SELECT COUNT(ID) as total FROM playlists WHERE status=?", array("yes"), "s")->row->total;
				$list = DB::SELECT("SELECT * FROM playlists WHERE status=? ORDER BY ID DESC LIMIT ?,?", array("yes",$start,$limit), "sii");
			}else{
				$total = DB::SELECT("SELECT COUNT(ID) as total FROM playlists WHERE type=? AND status=?", array($ptype,"yes"), "ss")->row->total;
				$list = DB::SELECT("SELECT * FROM playlists WHERE type=? AND status=? ORDER BY ID DESC LIMIT ?,?", array($ptype,"yes",$start,$limit), "ssii");
			}
			if($list->count > 0){
				for($n = 0; $n < count($list->fetch); $n++):
					$data[] = toPlaylistArray($list->fetch[$n], true);
				endfor;			
				if(($ostart + 1) <= ceil($total / $limit)){
					$nextToken = $hash->encode($ostart+1);	
				}
				echo JSON(array(
					'kind' => 'zuz#playlistsResponse',
					'etag' => encode(time()),
					'totalResults' => $total,
					'resultsPerPage' => $limit,
					'nextToken' => $nextToken,
					'list' => $data
				));
			}else{
				echo JSON(array('empty' => true));
			}
		}
		exit;				
	break;
	case "___admin_playlists_create":
		if(user_can($session, 'playlist.add')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$test = DB::SELECT("SELECT * FROM playlists WHERE uid=? AND label=? LIMIT 1", array($session->ID,$POST->name), "is");
		if($test->count > 0){
			echo JSON(array('kind' => 'zuz#alreadResponse', 'message' => lang('error_playlist_duplicate', array($POST->name)))); exit;
		}
		$create = DB::INSERT("INSERT INTO playlists (type,uid,label,tracks) VALUES(?,?,?,?)",array('admin',$session->ID,$POST->name,'0'),"siss");
		if($create->result=="ok"){
			echo JSON(array('kind' => 'zuz#newPlaylistResponse', 'uri' => BASEURL . 'admin/playlists?id=' . $hash->encode($create->ID))); exit;
		}
		echo JSON(array('error' => true)); exit;
	break;
	case "___admin_playlists_save":
		if(user_can($session, 'playlist.edit')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$ID = $hash->decode($POST->ID)[0];
		$name = $POST->name;
		$idz = explode(",", $POST->ids);
		$ids = array();
		foreach($idz as $id): array_push($ids, $hash->decode($id)[0]); endforeach;
		$privacy = $POST->privacy=='open'?'public':'private';
		if(DB::UPDATE("UPDATE playlists SET label=?, tracks=?, privacy=? WHERE ID=? LIMIT 1", array($name,implode(",", $ids),$privacy,$ID), "sssi")->result=="ok"){
			echo JSON(array('kind' => 'zuz#playlistUpdated', 'message' => lang('playlist_updated'), 'uri' => BASEURL . 'admin/playlists')); exit;	
		}
		echo JSON(array('error' => true, 'message' => lang('error_unable_to_process'))); exit;
	break;
	case "___admin_genres":
		if(user_can($session, 'genre.list')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$list = DB::SELECT("SELECT * FROM genres WHERE status=? ORDER BY title ASC", array("yes"), "s");
		if($list->count > 0){
			$data = array();
			for($n = 0; $n < count($list->fetch); $n++):
				$data[] = toGenreArray($list->fetch[$n]);
			endfor;	
			echo JSON(array(
				'kind' => 'zuz#genreListResponse',
				'etag' => encode(time()),
				'totalResults' => $list->count,
				'list' => $data
			));			
		}else{
			echo JSON(array('empty' => true));
		}
	break;
	case "___admin_genres_save":
		if(user_can($session, 'genre.edit')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$postid = (int) is_numeric($POST->postid) ? $POST->postid : $hash->decode($POST->postid)[0];
		$genre = $POST->name;
		$slug = slug($genre);
		$slugChk = DB::SELECT("SELECT ID FROM genres WHERE slug=? LIMIT 1", array($slug), "s");
		if($slugChk->result=="ok" && $slugChk->count > 0){ $slug .= "-2"; }
		if($postid > 0){
			$save = DB::UPDATE("UPDATE genres SET title=? WHERE ID=? LIMIT 1", array($genre, $postid), "si");
			if($save->result == "ok"){
				$_GENRE = DB::SELECT("SELECT * FROM genres WHERE ID=? LIMIT 1", array($postid), "i")->row;
				echo JSON(array(
					'kind' => 'zuz#genreUpdateResponse',
					'etag' => encode(time()),
					'genre' => toGenreArray($_GENRE)
				));	exit;		
			}
		}else{
			$_IS = DB::SELECT("SELECT * FROM genres WHERE title=? AND status=? LIMIT 1", array($genre, 'yes'), "ss");
			if($_IS->result=="ok" && $_IS->count > 0){
				echo JSON(array(
					'kind' => 'zuz#alreadResponse',
					'etag' => encode(time()),
					'message' => lang('error_genre_duplicate', array($genre))
				));	exit;
			}
			$save = DB::INSERT("INSERT INTO genres (title,slug) VALUES (?,?)", array($genre, $slug), "ss");
			if($save->result == "ok"){
				$_GENRE = DB::SELECT("SELECT * FROM genres WHERE ID=? LIMIT 1", array($save->ID), "i")->row;
				echo JSON(array(
					'kind' => 'zuz#genreUpdateResponse',
					'etag' => encode(time()),
					'genre' => toGenreArray($_GENRE)
				));	exit;		
			}
		}
		echo JSON(array('error' => true));
	break;
	case "___admin_genres_del":
		if(user_can($session, 'genre.remove')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }		
		$postid = (int) $hash->decode($POST->ID)[0];
		$update = DB::UPDATE("UPDATE genres SET status=? WHERE ID=? LIMIT 1", array('no', $postid), "si");
		if($update->result=="ok"){
			echo JSON(array(
				'kind' => 'zuz#genreDeleteResponse',
				'etag' => encode(time())
			));	exit;
		}
		echo JSON(array('error' => true));
	break;
	case "___admin_servers":
		if(user_can($session,'servers.list')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$pageToken = $POST->pageToken;
		$serverID = $POST->ID == '__0' ? $POST->ID : $hash->decode($POST->ID)[0];
		if($serverID > 0){
			$ID = $hash->decode($POST->ID)[0];
			$server = DB::SELECT("SELECT * FROM servers WHERE ID=? AND status!=? LIMIT 1", array($ID, "no"), "is");
			if($server->count > 0){
				echo JSON(array(
					'kind' => 'zuz#serverDetailResponse',
					'etag' => encode(time()),
					'nextToken' => 'none',					
					'view' => true,
					'server' => toServerArray($server->row)
				)); exit;
			}
			echo JSON(array('empty' => true));	exit;
		}else{
			$start = 0; $limit = 75; $ostart = 1; $nextToken = 'none';
			if($pageToken!='none'){ 
				$ostart = (int) $hash->decode($pageToken)[0];			
				$start = $limit * $ostart - $limit;			
			}
			$total = DB::SELECT("SELECT COUNT(ID) as total FROM servers WHERE status!=?", array("no"), "s")->row->total;
			$list = DB::SELECT("SELECT * FROM servers WHERE status!=? ORDER BY ID DESC LIMIT ?,?", array("no",$start,$limit), "sii");
			if($list->count > 0){
				$data = array();
				for($n = 0; $n < count($list->fetch); $n++):
					$data[] = toServerArray($list->fetch[$n]);
				endfor;	
				echo JSON(array(
					'kind' => 'zuz#genreListResponse',
					'etag' => encode(time()),
					'totalResults' => $list->count,
					'list' => $data
				));			
			}else{
				echo JSON(array('empty' => true));
			}
		}
	break;
	case "___admin_servers_save":
		if(user_can($session,'servers.edit')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$ffmpeg = trim(@exec('which ffmpeg')); // or better yet:
		$postid = (int) is_numeric($POST->postid) ? $POST->postid : $hash->decode($POST->postid)[0];
		$name = $POST->name;
		$uri = $POST->uri;
		$disk = (int) $POST->disk;
		$status = $POST->status == 'closed' ? 'closed' : 'active';
		$TEST = null;
		if(filter_var($uri, FILTER_VALIDATE_URL) === FALSE) {
			echo JSON(array('error' => true, 'message' => lang('error_server_url'))); exit;
		}else{
			$url_headers = @get_headers($uri);
			if(!$url_headers || $url_headers[0] == 'HTTP/1.1 404 Not Found'){
				echo JSON(array('error' => true, 'message' => lang('error_server_url_down', array($uri)))); exit;
			}
			$uri = addEndingSlash($uri);
			try{
				$TEST = @json_decode(___CURL($uri . 'index.php?connect=true', false));
				if($TEST->exec===false || $TEST->ffmpeg===false || $TEST->ytdl===false){					
					$exts = array();
					foreach($TEST as $key => $val):
						if($val===false) array_push($exts, $key);
					endforeach;
					echo JSON(array('error' => true, 'message' => lang('error_server_missing_extension', array(implode(",", $exts))))); exit;
				}
			}catch(Exception $e){
				echo JSON(array('error' => true, 'message' => lang('error_server_url_down', array($uri)))); exit;
			}	
		}		
		if($disk<=0){ echo JSON(array('error' => true, 'message' => lang('error_server_disk_zero'))); exit; }
		$GB = $disk * (1024 * 1024 * 1024);
		if($postid > 0){
			$save = DB::UPDATE("UPDATE servers SET title=?, address=?, tspace=?, added=?, status=? WHERE ID=? LIMIT 1", array($name,$uri,$GB,time(),$status,$postid), "ssiisi");
			if($save->result=="ok"){
				echo JSON(array(
					'kind' => 'zuz#serverUpdateResponse'
				)); exit;
			}
		}else{
			$save = DB::INSERT("INSERT INTO servers (title,address,tspace,added,status) VALUES(?,?,?,?,?)", array($name,$uri,$GB,time(),$status), "ssiis");
			if($save->result=="ok"){
				echo JSON(array(
					'kind' => 'zuz#serverSavedResponse'
				)); exit;
			}
		}
		echo JSON(array('error' => true)); exit;
	break;
	case "___admin_servers_del":
		if(user_can($session, 'servers.remove')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }		
		$postid = (int) $hash->decode($POST->ID)[0];
		$update = DB::UPDATE("UPDATE servers SET status=? WHERE ID=? LIMIT 1", array('no', $postid), "si");
		if($update->result=="ok"){
			echo JSON(array(
				'kind' => 'zuz#serverDeleteResponse',
				'etag' => encode(time())
			));	exit;
		}
		echo JSON(array('error' => true));
	break;
	case "___admin_servers_setdisk":
		$sid = $hash->decode($_GET['sid'])[0]; $disk = $_GET['disk'];
		DB::UPDATE("UPDATE servers SET tspace=? WHERE ID=? LIMIT 1", array($disk,$sid), "ii");
		echo JSON(array('kind' => 'zuz#diskupdateResponse')); exit;
	break;
	case "___admin_plugins":
		if(user_can($session,'plugins.list')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$pageToken = $POST->pageToken;
		$start = 0; $limit = 75; $ostart = 1; $nextToken = 'none';
		if($pageToken!='none'){ 
			$ostart = (int) $hash->decode($pageToken)[0];			
			$start = $limit * $ostart - $limit;			
		}	
		$ignore_list = array('.','..','index.php');
		$list = scandir(PLUGINS_DIR);
		$plugins = array();
		$activePlugins = @json_decode(getSetting('plugins'));		
		$totalPlugins = 0;
		foreach($list as $__plugin):
			if(!in_array($__plugin, $ignore_list)){
				$TM = PLUGINS_DIR . $__plugin;
				$TMF = $TM;
				$TMT = $__plugin;
				$isActive = in_array($__plugin, $activePlugins) ? 'yes' : 'no';
				if(is_dir($TM)){
					$TMT = $__plugin . '/' . $__plugin . '.php';
					$TMF = PLUGINS_DIR . $__plugin . '/' . $__plugin . '.php'; 
					$isActive = in_array($__plugin . '/' . $__plugin . '.php', $activePlugins) ? 'yes' : 'no';
				}
				if(file_exists($TMF)){
					$meta = getMetaFromFile($TMF, 'plugin');
					if(count($meta) > 0){
						array_push($plugins, array(
							'token' => encode($TMT),
							'info' => $meta,
							'active' => $isActive
						));
						$totalPlugins++;
					}
				}
			}			
		endforeach;

		if(count($plugins) > 0){
			echo JSON(array(
				'kind' => 'zuz#pluginsListResponse',
				'totalResults' => $totalPlugins,
				'nextToken' => 'none',
				'list' => $plugins
			)); exit;
		}
		echo JSON(array('empty' => true)); exit;
	break;
	case "___admin_plugins_change":
		if(user_can($session, 'plugins.change')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$plugin = decode($POST->pluginToken);
		$activePlugins = @json_decode(getSetting('plugins'));
		if(in_array($plugin, $activePlugins)){
			$activePlugins = array_diff($activePlugins, array($plugin));
		}else{
			array_push($activePlugins, $plugin);
		}		
		setSetting('plugins', $activePlugins, true);
		echo JSON(array(
			'kind' => 'zuz#pluginUpdateResponse',
			'message' => lang('redirecting')
		)); exit;
	break;
	case "___admin_themes":		
		if(user_can($session, 'themes.list')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$pageToken = $POST->pageToken;
		$start = 0; $limit = 75; $ostart = 1; $nextToken = 'none';
		if($pageToken!='none'){ 
			$ostart = (int) $hash->decode($pageToken)[0];			
			$start = $limit * $ostart - $limit;			
		}	
		$ignore_list = array('.','..','index.php');
		$list = scandir(THEMES_DIR);
		$themes = array();
		$currentTheme = getSetting('theme');
		foreach($list as $__theme):
			if(!in_array($__theme, $ignore_list)){
				$TM = THEMES_DIR . $__theme;
				$TMF = THEMES_DIR . $__theme . '/style.css';
				if(is_dir($TM) && file_exists($TMF)){
					$meta = getMetaFromFile($TMF);				
					if(count($meta) > 0){
						array_push($themes, array(
							'token' => encode($__theme),
							'info' => $meta,
							'active' => $__theme == $currentTheme ? 'yes' : 'no',
							'screen' => BASEURL . 'themes/' . $__theme . '/screenshot.png'
						));
					}
				}	
			}			
		endforeach;

		if(count($themes) > 0){
			echo JSON(array(
				'kind' => 'zuz#themesListResponse',
				'list' => $themes
			)); exit;
		}
		echo JSON(array('empty' => true)); exit;
	break;
	case "___admin_themes_change":		
		if(user_can($session, 'themes.edit')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$theme = decode($POST->themeToken);
		if(file_exists(THEMES_DIR . $theme) && is_dir(THEMES_DIR . $theme)){
			setSetting('theme',$theme);
			echo JSON(array(
				'kind' => 'zuz#themeUpdateResponse',
				'message' => lang('msg_theme_updated')
			)); exit;
		}
		echo JSON(array('error' => true)); exit;
	break;
	case "___admin_settings":		
		if(user_can($session, 'settings.list')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		echo JSON(array(
			'kind' => 'zuz#cogListResponse',
			'cog' => array(
				'status' => getSetting('site_status'),
				'signin_to_listen' => getSetting('must_signin'),
				'title' => getSetting('site_title'),
				'tagline' => getSetting('site_slogan'),
				'formats' => getSetting('formats'),
				'quality' => getSetting('quality'),
				'lang' => array(
					'current' => getSetting('site_lang'),
					'available' => getAvailableLangs()
				),
				'ga' => getSetting('google_ga'),
				'download' => getSetting('allow_download')
			)
		)); exit;
	break;
	case "___admin_settings_save":
		if(user_can($session, 'settings.edit')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$isDown = $POST->isdown=='yes'?'offline':'live';
		$moderator = $POST->modr;
		if(strpos($moderator, 'dashboard')===false){
			$moderator = 'dashboard,'.$moderator;
		}
		setSetting('site_status', $isDown);
		setSetting('must_signin', $POST->privacy);
		setSetting('site_title', $POST->title);
		setSetting('site_slogan', $POST->tagline);
		setSetting('quality', $POST->quality);
		setSetting('site_lang', $POST->lang);
		setSetting('allow_download', $POST->download);
		setSetting('google_ga', $POST->ga);		
		setSetting('admin_allow_moderator', $moderator);
		echo JSON(array(
			'kind' => 'zuz#cogListResponse',					
			'message' => lang('cog_updated_ok')
		));
	break;
	case "___admin_apikeys":		
		if(user_can($session, 'apikeys.list')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$optn = DB::SELECT("SELECT ID FROM settings WHERE optn=? LIMIT 1", array("api_key"), "s");
		if($optn->result != "ok" || $optn->count == 0){	
			$__key = strtolower(randit(12));
			$apiKey = encode($__key.'@@'.time());
			DB::INSERT("INSERT INTO settings (optn,valu,status) VALUES (?,?,?)", array('apikey',$__key,'yes'), "sss");
			DB::INSERT("INSERT INTO settings (optn,valu,status) VALUES (?,?,?)", array('api_key',$apiKey,'yes'), "sss");
		}
		echo JSON(array(
			'kind' => 'zuz#apiKeyListResponse',
			'apikey' => getSetting('api_key')
		)); exit;
	break;
	case "___admin_apikeys_reset":
		if(user_can($session, 'apikeys.reset')===false){ echo JSON(array('error' => 'zuz#unauthorized')); exit; }
		$__key = strtolower(randit(12));
		$apikey = encode($__key.'@@'.time());
		DB::UPDATE("UPDATE settings SET valu=? WHERE optn='apikey' LIMIT 1", array($__key), "s");
		DB::UPDATE("UPDATE settings SET valu=? WHERE optn='api_key' LIMIT 1", array($apikey), "s");
		echo JSON(array(
			'kind' => 'zuz#apiKeyResetResponse',
			'key' => $apikey
		)); exit;
	break;	
	default:
		echo JSON(array(
			'error' => 'zuz#unknownRequest',
			'message' => 'Unknown Request `'.zuz_console_request()->action.'`'
		));		
endswitch;
?>