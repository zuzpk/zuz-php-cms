<?php
if(!isset($_COOKIE['__volume'])){ COOKIE('__volume', 1, 24*364); }
if(!isset($_COOKIE['__shuffle'])){ COOKIE('__shuffle', 0, 24*364); }
if(!isset($_COOKIE['__repeat'])){ COOKIE('__repeat', 1, 24*364); }
if(!isset($_COOKIE['__muted'])){ COOKIE('__muted', 0, 24*364); }
if(is_admin_page()){
	$session  = getUser();
	if($session->is !== true || $session->type == 'user'){
		header("location: " . BASEURL . "account?next=" . urlencode(CURRENT_URI)); exit;
	}
	$theme = getSetting('theme_admin');
	define('THEME', ADMINBASE . 'themes/' . $theme . "/");
	define('THEMEURL', BASEURL . '_admin/themes/' . $theme . "/");	
	if(!is_dir(THEME)){
		siteError(SITE_NAME . ': Error', 'Admin Theme <span class="fontb">`'.$theme.'`</span> Not Found'); exit;
	}
	getCurrentPage();
	$theme_page = getCurrentPage();	
	get_theme($theme_page == 'dashboard' ? 'home' : $theme_page);	
}else{
	if(getSetting('site_status')=='offline' && getCurrentPage()!='account'){
		$you = getUser();
		$txt = '<div style="text-align:left;" class="s16">'.lang('msg_site_offline', array(ADMIN_EMAIL));
		if($you->is===true){
			if($you->type=='admin'){
				$txt .= '<a href="' . BASEURL . 'admin/dashboard" class="s16 btn">'.lang('label_goto_dashboard').'</a>';
			}			
		}else{
			$txt .= '<a href="' . BASEURL . 'account" class="s16 btn">'.lang('signin').'</a>';
		}
		$txt .= '</div>';
		siteError(SITE_NAME . ': Error', $txt); exit;
	}else{
		$theme = getSetting('theme');
		define('THEME', THEMES_DIR . $theme . "/");
		define('THEMEURL', BASEURL . 'themes/' . $theme . "/");
		if(!is_dir(THEME)){
			siteError(SITE_NAME . ': Error', 'Theme <span class="fontb">`'.$theme.'`</span> Not Found'); exit;
		}		
		$ZUZ_THEME_PAGE = getSetting('must_signin') == 'yes' && getUser()->is !== true && getCurrentPage() != 'account' ? 'landing' : getCurrentPage();		
		get_theme($ZUZ_THEME_PAGE);
	}
}
?>