<?php header("Content-Type: application/json");

//Allowed REST API Methods
$allowed_methods = array(
	//Frontend
	'genres','tracks','albums','artists','playlists',
	//Admin Panel
	'admin_stats','admin_inbox','admin_users','admin_servers','admin_settings'
);

//GET REQUESTED METHOD
$method = zuz_restapi_request()->method;

//IF Key Params Exist
if(!isset($_GET['key'])){
	echo JSON(array(
		'error' => true,
		'reason' => 'dailyLimitExceededUnreg',
		'message' => 'Daily Limit for Unauthenticated Use Exceeded. Continued use requires signup.'
	)); exit;
}

if(!in_array($method, $allowed_methods)){
	echo JSON(array(
		'error' => true,
		'reason' => 'UnknownMethod',
		'message' => 'Unknown method `'.$method.'`.'
	)); exit;
}

//Verify KEY
@list($key, $tm) = explode("@@", decode($_GET['key']));
$__key = getSetting('apikey');
$okey = getSetting('api_key');
if($okey != $_GET['key'] || $__key != $key){
	echo JSON(array(
		'error' => true,
		'reason' => 'invalidKey',
		'message' => 'API Key you provided is either invalid or is expired.'
	)); exit;
}

function CheckParamStart($start){
	if($start < 0){
		echo JSON(array(
			'error' => true,
			'reason' => 'InvalidMaxResultParam',
			'message' => '`maxresults` should be greater than `0` and less than `50`'
		)); exit;
	}
}

function CheckParamLimit($limit){
	if($limit <= 0 || $limit > 50){
		echo JSON(array(
			'error' => true,
			'reason' => 'InvalidMaxResultParam',
			'message' => '`maxresults` should be greater than `0` and less than `50`'
		)); exit;
	}
}

$ostart = 1; $start = 0; $limit = (int) isset($_GET['maxresults']) ? $_GET['maxresults'] : 50;
if(isset($_GET['pageToken'])){
	$ostart = (int) $hash->decode($_GET['pageToken'])[0];
	$start = $limit * $ostart - $limit;
}
		
switch($method):
	case "genres":
		$list = DB::SELECT("SELECT * FROM genres WHERE status=? ORDER BY title ASC", array("yes"), "s");
		$total = 0;
		if($list->result=="ok" && $list->count > 0){
			$total = count($list->fetch);
			for($n = 0; $n < count($list->fetch); $n++):
				$data[] = array(
					'ID' => $hash->encode($list->fetch[$n]->ID),
					'label' => $list->fetch[$n]->title,
					'slug' => $list->fetch[$n]->slug,
					'trackCount' => number_format($list->fetch[$n]->tracks)
				);
			endfor;
			echo JSON(array(
				'kind' => 'genresList',
				'etag' => encode(time()),
				'count' => $total,
				'list' => $data
			)); exit;
		}else{
			echo JSON(array(
				'error' => true,
				'message' => 'Empty Result.'
			)); exit;
		}
	break;
	case "tracks":
		$allowed_charts = array('newest','featured','search','detail');
		if(!isset($_GET['chart'])){
			echo JSON(array(
				'error' => true,
				'reason' => 'noChartSpecified',
				'message' => '`chart` param is missing.'
			)); exit;
		}
		$chart = $_GET['chart'];
		CheckParamLimit($limit);
		if(!in_array($chart, $allowed_charts)){
			echo JSON(array(
				'error' => true,
				'reason' => 'UnknownChart',
				'message' => 'Unknown chart `'.$chart.'`.'
			)); exit;
		}
		switch($chart):
			case "newest":
				$total = DB::SELECT("SELECT COUNT(ID) as total FROM tracks WHERE status=?", array("yes"), "s")->row->total;
				$list = DB::SELECT("SELECT * FROM tracks WHERE status=? ORDER BY ID DESC LIMIT ?,?", array("yes",$start,$limit), "sii");
			break;
			case "featured":
				$total = DB::SELECT("SELECT COUNT(ID) as total FROM tracks WHERE status=? ORDER BY views DESC", array("yes"), "s")->row->total;
				$list = DB::SELECT("SELECT * FROM tracks WHERE status=? ORDER BY views DESC LIMIT ?,?", array("yes",$start,$limit), "sii");
			break;
			case "detail":
				if(!isset($_GET['ids'])){
					echo JSON(array(
						'error' => true,
						'reason' => 'noIds',
						'message' => 'You must specify at least one id'
					)); exit;
				}
				$ids = array(); $ds = explode(",", $_GET['ids']);
				foreach($ds as $id):
					$_ID = $hash->decode($id)[0];
					if(!in_array($_ID, $ids)){ array_push($ids, $_ID); }
				endforeach;
				$total = count($ids);
				$ids = implode(",", $ids);
				$list = DB::SELECT("SELECT * FROM tracks WHERE ID IN (".$ids.") AND status=?", array("yes"), "s");
			break;
			case "search":
				if(!isset($_GET['q']) || empty($_GET['q'])){
					echo JSON(array(
						'error' => true,
						'reason' => 'SearchParamMissing',
						'message' => 'Empty Search Query String'
					)); exit;
				}
				$Query = $_GET['q'];
				$keyword = str_replace(" ", "+", urldecode($Query));
				$q = "SELECT * FROM tracks WHERE status=? AND (";						
				$okeyword = $keyword = safeStr(str_replace("+"," ", $Query));
				$x = array_reverse(explode(" ", $keyword));	
				$keywords_set = array();
				foreach($x as $word):
					array_push($keywords_set, $word);		
				endforeach;
				$combinations = getCombinations($keywords_set);
				$c = 0;
				foreach($combinations as $newWord):
					if(!empty($newWord)){	
						if(substr($newWord, -1)==' '){ $newWord = substr($newWord, 0, -1); }
						if($c>0){	$q .= " OR "; }
						$newWord = safeStr($newWord);
						$q .= " title LIKE '%$newWord%' ";
						$c++;
					}		
				endforeach;			
				$q .= " ) ";
				$total = DB::SELECT($q, array("yes"), "s")->count;	
				$q .= " ORDER BY ";
				foreach($combinations as $newWord):
					if(!empty($newWord)){	
						if(substr($newWord, -1)==' '){ $newWord = substr($newWord, 0, -1); }
						$newWord = safeStr($newWord);
						$q .= "CASE WHEN instr(title, '$newWord') = 0 THEN 1 ELSE 0 END,";
					}
				endforeach;			
				$q .= "instr(title, '$keyword') DESC";			
				$q .= " LIMIT ?, ?";					
				$list = DB::SELECT($q, array("yes",$start,$limit), "sii");
			break;
		endswitch;
		if($list->count > 0){
			for($n = 0; $n < count($list->fetch); $n++):
				$data[] = toTrackArray($list->fetch[$n]);
			endfor;						
			$JSON['kind'] = 'zuz#trackListResponse';
			$JSON['etag'] = encode(time());
			$JSON['totalResults'] = $total;
			$JSON['maxResults'] = $limit;
			if($ostart>1){
				$JSON['prevToken'] = $hash->encode($ostart-1);
			}
			if(($ostart + 1) <= ceil($total / $limit)){
				$JSON['nextToken'] = $hash->encode($ostart+1);
			}			
			$JSON['chart'] = $chart;
			if($chart=='search'){
				$JSON['query'] = $_GET['q'];
			}
			$JSON['list'] = $data;
			echo JSON($JSON);
		}else{
			echo JSON(array(
				'error' => true,
				'reason' => 'empty',
				'message' => 'Empty results.'
			)); exit;
		}
	break;
	case "albums":
		$total = DB::SELECT("SELECT COUNT(ID) as total FROM albums WHERE status=?", array("yes"), "s")->row->total;
		$list = DB::SELECT("SELECT * FROM albums WHERE status=? ORDER BY ID DESC LIMIT ?,?", array("yes",$start,$limit), "sii");	
		if($list->count > 0){
			for($n = 0; $n < count($list->fetch); $n++):
				$data[] = toAlbumArray($list->fetch[$n]);
			endfor;						
			$JSON['kind'] = 'zuz#albumListResponse';
			$JSON['etag'] = encode(time());
			$JSON['totalResults'] = $total;
			$JSON['maxResults'] = $limit;
			if($ostart>1){
				$JSON['prevToken'] = $hash->encode($ostart-1);
			}
			if(($ostart + 1) <= ceil($total / $limit)){
				$JSON['nextToken'] = $hash->encode($ostart+1);
			}						
			$JSON['list'] = $data;
			echo JSON($JSON);
		}else{
			echo JSON(array(
				'error' => true,
				'reason' => 'empty',
				'message' => 'Empty results.'
			)); exit;
		}
	break;
	case "artists":
		$total = DB::SELECT("SELECT COUNT(ID) as total FROM artists WHERE status=?", array("yes"), "s")->row->total;
		$list = DB::SELECT("SELECT * FROM artists WHERE status=? ORDER BY ID DESC LIMIT ?,?", array("yes",$start,$limit), "sii");	
		if($list->count > 0){
			for($n = 0; $n < count($list->fetch); $n++):
				$data[] = toArtistArray($list->fetch[$n]);
			endfor;						
			$JSON['kind'] = 'zuz#artistListResponse';
			$JSON['etag'] = encode(time());
			$JSON['totalResults'] = $total;
			$JSON['maxResults'] = $limit;
			if($ostart>1){
				$JSON['prevToken'] = $hash->encode($ostart-1);
			}
			if(($ostart + 1) <= ceil($total / $limit)){
				$JSON['nextToken'] = $hash->encode($ostart+1);
			}						
			$JSON['list'] = $data;
			echo JSON($JSON);
		}else{
			echo JSON(array(
				'error' => true,
				'reason' => 'empty',
				'message' => 'Empty results.'
			)); exit;
		}
	break;
	case "playlists":
		$total = DB::SELECT("SELECT COUNT(ID) as total FROM playlists WHERE status=?", array("yes"), "s")->row->total;
		$list = DB::SELECT("SELECT * FROM playlists WHERE status=? ORDER BY ID DESC LIMIT ?,?", array("yes",$start,$limit), "sii");	
		if($list->count > 0){
			for($n = 0; $n < count($list->fetch); $n++):
				$data[] = toPlaylistArray($list->fetch[$n]);
			endfor;						
			$JSON['kind'] = 'zuz#PlaylistsResponse';
			$JSON['etag'] = encode(time());
			$JSON['totalResults'] = $total;
			$JSON['maxResults'] = $limit;
			if($ostart>1){
				$JSON['prevToken'] = $hash->encode($ostart-1);
			}
			if(($ostart + 1) <= ceil($total / $limit)){
				$JSON['nextToken'] = $hash->encode($ostart+1);
			}						
			$JSON['list'] = $data;
			echo JSON($JSON);
		}else{
			echo JSON(array(
				'error' => true,
				'reason' => 'empty',
				'message' => 'Empty results.'
			)); exit;
		}
	break;
	case "admin_stats":
		echo JSON(array(
			'kind' => 'statsList',			
			'etag' => encode(time()),
			'list' => array(
				'usersCount' => DB::SELECT("SELECT COUNT(ID) as total FROM users WHERE status!=? AND status!=?", array("banned", "deleted"), "ss")->row->total,
				'albumsCount' => DB::SELECT("SELECT COUNT(ID) as total FROM albums WHERE status=?", array("yes"), "s")->row->total,
				'tracksCount' => DB::SELECT("SELECT COUNT(ID) as total FROM tracks WHERE status=?", array("yes"), "s")->row->total,
				'loopsCount' => DB::SELECT("SELECT SUM(loops) as total FROM history WHERE tid!=?", array("0"), "i")->row->total,
				'playlistsCount' => DB::SELECT("SELECT COUNT(ID) as total FROM playlists WHERE privacy=? AND status=?", array("public","yes"), "ss")->row->total,
			)
		)); exit;
	break;
	case "admin_inbox":		
		CheckParamLimit($limit);	
		$total = DB::SELECT("SELECT COUNT(ID) as total FROM inbox WHERE status!=?", array("deleted"), "s")->row->total;
		$list = DB::SELECT("SELECT * FROM inbox WHERE status!=? ORDER BY ID DESC LIMIT ?,?", array("deleted",$start,$limit), "sii");	
		$data = array();
		for($n = 0; $n < count($list->fetch); $n++):
			$data[] = array(
				'ID' => $hash->encode($list->fetch[$n]->ID),
				'type' => $list->fetch[$n]->type,
				'from' => array(
					'user' => $list->fetch[$n]->name,
					'email' => $list->fetch[$n]->email
				),
				'subject' => $list->fetch[$n]->subject,
				'message' => $list->fetch[$n]->message,
				'timestamp' => date("d M Y H:ia", $list->fetch[$n]->added)
			);
		endfor;		
		$JSON['kind'] = 'inboxList';
		$JSON['etag'] = encode(time());
		if($ostart>1){
			$JSON['prevToken'] = $hash->encode($ostart-1);
		}
		if(($ostart + 1) <= ceil($total / $limit)){
			$JSON['nextToken'] = $hash->encode($ostart+1);
		}
		$JSON['list'] = $data;
		echo JSON($JSON); exit;
	break;
	case "admin_users":		
		CheckParamLimit($limit);	
		$total = DB::SELECT("SELECT COUNT(ID) as total FROM users WHERE status=?", array("active"), "s")->row->total;
		$list = DB::SELECT("SELECT * FROM users WHERE status=? ORDER BY ID DESC LIMIT ?,?", array("active",$start,$limit), "sii");	
		$data = array();
		for($n = 0; $n < count($list->fetch); $n++):
			$data[] = toUserArray($list->fetch[$n], true);
		endfor;		
		$JSON['kind'] = 'usersList';
		$JSON['etag'] = encode(time());
		if($ostart>1){
			$JSON['prevToken'] = $hash->encode($ostart-1);
		}
		if(($ostart + 1) <= ceil($total / $limit)){
			$JSON['nextToken'] = $hash->encode($ostart+1);
		}
		$JSON['list'] = $data;
		echo JSON($JSON); exit;
	break;
	case "admin_servers":		
		CheckParamLimit($limit);	
		$total = DB::SELECT("SELECT COUNT(ID) as total FROM servers WHERE status!=?", array("no"), "s")->row->total;
		$list = DB::SELECT("SELECT * FROM servers WHERE status=? ORDER BY ID DESC LIMIT ?,?", array("no",$start,$limit), "sii");	
		$data = array();
		for($n = 0; $n < count($list->fetch); $n++):
			$data[] = toServerArray($list->fetch[$n]);
		endfor;		
		$JSON['kind'] = 'serverList';
		$JSON['etag'] = encode(time());
		if($ostart>1){
			$JSON['prevToken'] = $hash->encode($ostart-1);
		}
		if(($ostart + 1) <= ceil($total / $limit)){
			$JSON['nextToken'] = $hash->encode($ostart+1);
		}
		$JSON['list'] = $data;
		echo JSON($JSON); exit;
	break;
	case "admin_settings":		
		echo JSON(array(
			'kind' => 'zuz#cogListResponse',
			'etag' => encode(time()),
			'cog' => array(
				'status' => getSetting('site_status'),
				'signin_to_listen' => getSetting('must_signin'),
				'site_title' => getSetting('site_title'),
				'site_tagline' => getSetting('site_slogan'),
				'formats' => getSetting('formats'),
				'quality' => getSetting('quality'),
				'language' => array(
					'current' => getSetting('site_lang'),
					'available' => getAvailableLangs()
				),
				'google_analytics_id' => getSetting('google_ga'),
				'can_download' => getSetting('allow_download')
			)
		)); exit;
	break;
endswitch;

?>