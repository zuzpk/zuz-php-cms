<?php
function isCurlAvailable(){ return function_exists('curl_version'); }

function ___CURL($url, $header = true, $timeout = 3600){
	if(isCurlAvailable()===true){
		$ch = curl_init($url);		
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		if($header==true) curl_setopt($ch, CURLOPT_HEADER, TRUE);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
		curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
		return curl_exec($ch);
	}else{
		return @file_get_contents($url);
	}
}

function isEmail($email){
	return !filter_var($email, FILTER_VALIDATE_EMAIL) === false ? true : false;
}
	
function JSON($array, $decode = false){
	if($decode==true){
		return json_decode(json_encode($array));
	}else{
		return json_encode($array, 128);
	}
}

function randit($digits){
	srand ((double) microtime() * 10000000);
	$input = array ("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","A", "B", "C", "D", "E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z");
	$random_generator="";
	for($i=1;$i<$digits+1;$i++){ 
		if(rand(1,2) == 1){
			$rand_index = array_rand($input);
			$random_generator .=$input[$rand_index];
		}else{
			$random_generator .=rand(1,10);
		}
	}
	return $random_generator;
}

function addEndingSlash($uri){
	$last = substr($uri, strlen($uri)-1, 1);
	if($last!='/'){ $uri .= '/'; }
	return $uri;
}

function ssl_redirect(){
	$BASE = parse_url(BASEURL);	
	$BASE_SCHEME = $BASE['scheme'];
	$BASE_HOST = $BASE['host'];
	if($BASE_SCHEME=='https' && $_SERVER['REQUEST_SCHEME']=='http'){
		$redirect = 'https://' . $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		header("location: " . $redirect); exit;
	}else if($BASE_SCHEME=='http' && $_SERVER['REQUEST_SCHEME']=='https'){
		$redirect = 'http://' . $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		header("location: " . $redirect); exit;
	}else if($BASE_HOST!=$_SERVER['HTTP_HOST']){
		$redirect = $BASE_SCHEME . '://' . $BASE_HOST . $_SERVER['REQUEST_URI'];
		header("location: " . $redirect); exit;
	}
}

function timeAgo($time_ago, $number_only = false){
	$time_ago = is_numeric($time_ago) ? $time_ago : strtotime($time_ago);
	$cur_time   = time();
	$time_elapsed   = $cur_time - $time_ago;
	$seconds    = $time_elapsed ;
	$minutes    = round($time_elapsed / 60 );
	$hours      = round($time_elapsed / 3600);
	$days       = round($time_elapsed / 86400 );
	$weeks      = round($time_elapsed / 604800);
	$months     = round($time_elapsed / 2600640 );
	$years      = round($time_elapsed / 31207680 );
	
	if($number_only==true){
		if($seconds <= 60){
			return $this->json(array('time' => $seconds, 'lbl' => $seconds < 10 ? 'sec' : 'secs'), true);
		}
		if($minutes <= 60){
			return $this->json(array('time' => $minutes, 'lbl' => $minutes < 10 ? 'mint' : 'mints'), true);
		}
		return 'in a sec';
	}
		
	// Seconds
	if($seconds <= 60){
		return "just now";
	}
	
	//Minutes
	else if($minutes <=60){
		if($minutes==1){
			return "one minute ago";
		}
		else{
			return "$minutes minutes ago";
		}
	}
	
	//Hours
	else if($hours <=24){
		if($hours==1){
			return "an hour ago";
		}else{
			return "$hours hrs ago";
		}
	}
	
	//Days
	else if($days <= 7){
		if($days==1){
			return "yesterday";
		}else{
			return "$days days ago";
		}
	}
	
	//Weeks
	else if($weeks <= 4.3){
		if($weeks==1){
			return "a week ago";
		}else{
			return "$weeks weeks ago";
		}
	}
	
	//Months
	else if($months <=12){
		if($months==1){
			return "a month ago";
		}else{
			return "$months months ago";
		}
	}
	
	//Years
	else{
		if($years==1){
			return "one year ago";
		}else{
			return "$years years ago";
		}
	}
}

function myip(){
	if (!empty($_SERVER['HTTP_CLIENT_IP']))
	{    $ip=$_SERVER['HTTP_CLIENT_IP'];    }
	elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
	{    $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];    }
	else
	{    $ip=$_SERVER['REMOTE_ADDR'];    }
	return $ip;
}
	
function Geo($MIP = 'none'){		
	$ip = $MIP != 'none' ? $MIP : myip();				
	return ___CURL('https://api.zuz.host/geo/'.$ip, false);		
}

function COOKIE($name, $value, $time, $USE_URI = false){
	$time = $time > 0 ? time() + ($time * 3600) : time() - 86400 * 7;
	setcookie($name, $value, $time, '/', $USE_URI === true ? COOKIE_URI : COOKIE_URL);	
}
	
function safe_b64encode($string) {
    $data = base64_encode($string);
    $data = str_replace(array('+','/','='),array('-','_',''),$data);
	return $data;
}
	
function safe_b64decode($string){
	$data = str_replace(array('-','_'),array('+','/'),$string);
	$mod4 = strlen($data) % 4;
	if ($mod4) {
		$data .= substr('====', $mod4);
	}
	return base64_decode($data);
}

function encode($value, $key = "none"){ 
	if(!$value){return false;}
	$text = $value;
	$ENCRYPT_KEY = $key == "none" ? ENCRYPTION_KEY : $key;
	if(function_exists('mcrypt_encrypt')){
		$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
		$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
		$crypttext = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($ENCRYPT_KEY), $text, MCRYPT_MODE_ECB, $iv);
		return trim(safe_b64encode($crypttext)); 
	}else if(function_exists('openssl_encrypt')){
		$iv = substr(md5($ENCRYPTION_KEY), 0, 16);
		$output = openssl_encrypt($value, "AES-256-CBC", $ENCRYPTION_KEY, 0, $iv);
        return trim(safe_b64encode($output));
	}else{
		return trim(safe_b64encode($value));
	}
}
	 
function decode($value, $key = "none"){
	if(!$value){return false;}
	$ENCRYPT_KEY = $key == "none" ? ENCRYPTION_KEY : $key;
	if(function_exists('mcrypt_encrypt')){
		$crypttext = safe_b64decode($value); 
		$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
		$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
		$decrypttext = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, md5($ENCRYPT_KEY), $crypttext, MCRYPT_MODE_ECB, $iv);
		return trim($decrypttext);
	}else if(function_exists('openssl_encrypt')){
		$iv = substr(md5($ENCRYPTION_KEY), 0, 16);
		return openssl_decrypt(safe_b64decode($value), "AES-256-CBC", $ENCRYPTION_KEY, 0, $iv);
	}else{
		return safe_b64decode($value);
	}
}
function isMobile(){ global $device; return $device->isMobile(); }
function isTablet(){ global $device; return $device->isTablet(); }
function lang($key, $arr = array()){
	global $language; 
	$str = $language[$key];
	if(count($arr) > 0){
		for($n = 0; $n < count($arr); $n++):
			$str = str_replace('%'.$n, $arr[$n], $str);
		endfor;
	}
	return $str;
	
}

function slug($string){
	$string = str_replace("&", "and", $string);
	$slug = preg_replace('/[^A-Za-z0-9-]+/', '-', $string);
	$slug=  strtolower($slug);
	$dash = true;
	while(substr($slug, -1) == '-'):
		$slug = rtrim($slug, '-');
	endwhile;	
	$slug = empty($slug) ? url_slug($string, array('lowercase' => true)) : $slug;
	$slug = preg_replace('/-+/', '-', $slug);
	return $slug;
}

function url_slug($str, $options = array()) {
	$str = mb_convert_encoding((string)$str, 'UTF-8', mb_list_encodings());
	$defaults = array(
		'delimiter' => '-',
		'limit' => null,
		'lowercase' => true,
		'replacements' => array(),
		'transliterate' => false,
	);
	$options = array_merge($defaults, $options);
	$char_map = array(
		// Latin
		'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A', 'Ä' => 'A', 'Å' => 'A', 'Æ' => 'AE', 'Ç' => 'C', 
		'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E', 'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I', 
		'Ð' => 'D', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ö' => 'O', 'O' => 'O', 
		'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'U' => 'U', 'Ý' => 'Y', 'Þ' => 'TH', 
		'ß' => 'ss', 
		'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a', 'æ' => 'ae', 'ç' => 'c', 
		'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i', 'î' => 'i', 'ï' => 'i', 
		'ð' => 'd', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o', 'ö' => 'o', 'o' => 'o', 
		'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ü' => 'u', 'u' => 'u', 'ý' => 'y', 'þ' => 'th', 
		'ÿ' => 'y',
		// Latin symbols
		'©' => '(c)',
		// Greek
		'?' => 'A', '?' => 'B', 'G' => 'G', '?' => 'D', '?' => 'E', '?' => 'Z', '?' => 'H', 'T' => '8',
		'?' => 'I', '?' => 'K', '?' => 'L', '?' => 'M', '?' => 'N', '?' => '3', '?' => 'O', '?' => 'P',
		'?' => 'R', 'S' => 'S', '?' => 'T', '?' => 'Y', 'F' => 'F', '?' => 'X', '?' => 'PS', 'O' => 'W',
		'?' => 'A', '?' => 'E', '?' => 'I', '?' => 'O', '?' => 'Y', '?' => 'H', '?' => 'W', '?' => 'I',
		'?' => 'Y',
		'a' => 'a', 'ß' => 'b', '?' => 'g', 'd' => 'd', 'e' => 'e', '?' => 'z', '?' => 'h', '?' => '8',
		'?' => 'i', '?' => 'k', '?' => 'l', 'µ' => 'm', '?' => 'n', '?' => '3', '?' => 'o', 'p' => 'p',
		'?' => 'r', 's' => 's', 't' => 't', '?' => 'y', 'f' => 'f', '?' => 'x', '?' => 'ps', '?' => 'w',
		'?' => 'a', '?' => 'e', '?' => 'i', '?' => 'o', '?' => 'y', '?' => 'h', '?' => 'w', '?' => 's',
		'?' => 'i', '?' => 'y', '?' => 'y', '?' => 'i',
		// Turkish
		'S' => 'S', 'I' => 'I', 'Ç' => 'C', 'Ü' => 'U', 'Ö' => 'O', 'G' => 'G',
		's' => 's', 'i' => 'i', 'ç' => 'c', 'ü' => 'u', 'ö' => 'o', 'g' => 'g', 
		// Russian
		'?' => 'A', '?' => 'B', '?' => 'V', '?' => 'G', '?' => 'D', '?' => 'E', '?' => 'Yo', '?' => 'Zh',
		'?' => 'Z', '?' => 'I', '?' => 'J', '?' => 'K', '?' => 'L', '?' => 'M', '?' => 'N', '?' => 'O',
		'?' => 'P', '?' => 'R', '?' => 'S', '?' => 'T', '?' => 'U', '?' => 'F', '?' => 'H', '?' => 'C',
		'?' => 'Ch', '?' => 'Sh', '?' => 'Sh', '?' => '', '?' => 'Y', '?' => '', '?' => 'E', '?' => 'Yu',
		'?' => 'Ya',
		'?' => 'a', '?' => 'b', '?' => 'v', '?' => 'g', '?' => 'd', '?' => 'e', '?' => 'yo', '?' => 'zh',
		'?' => 'z', '?' => 'i', '?' => 'j', '?' => 'k', '?' => 'l', '?' => 'm', '?' => 'n', '?' => 'o',
		'?' => 'p', '?' => 'r', '?' => 's', '?' => 't', '?' => 'u', '?' => 'f', '?' => 'h', '?' => 'c',
		'?' => 'ch', '?' => 'sh', '?' => 'sh', '?' => '', '?' => 'y', '?' => '', '?' => 'e', '?' => 'yu',
		'?' => 'ya',
		// Ukrainian
		'?' => 'Ye', '?' => 'I', '?' => 'Yi', '?' => 'G',
		'?' => 'ye', '?' => 'i', '?' => 'yi', '?' => 'g',
		// Czech
		'C' => 'C', 'D' => 'D', 'E' => 'E', 'N' => 'N', 'R' => 'R', 'Š' => 'S', 'T' => 'T', 'U' => 'U', 
		'Ž' => 'Z', 
		'c' => 'c', 'd' => 'd', 'e' => 'e', 'n' => 'n', 'r' => 'r', 'š' => 's', 't' => 't', 'u' => 'u',
		'ž' => 'z', 
		// Polish
		'A' => 'A', 'C' => 'C', 'E' => 'e', 'L' => 'L', 'N' => 'N', 'Ó' => 'o', 'S' => 'S', 'Z' => 'Z', 
		'Z' => 'Z', 
		'a' => 'a', 'c' => 'c', 'e' => 'e', 'l' => 'l', 'n' => 'n', 'ó' => 'o', 's' => 's', 'z' => 'z',
		'z' => 'z',
		// Latvian
		'A' => 'A', 'C' => 'C', 'E' => 'E', 'G' => 'G', 'I' => 'i', 'K' => 'k', 'L' => 'L', 'N' => 'N', 
		'Š' => 'S', 'U' => 'u', 'Ž' => 'Z',
		'a' => 'a', 'c' => 'c', 'e' => 'e', 'g' => 'g', 'i' => 'i', 'k' => 'k', 'l' => 'l', 'n' => 'n',
		'š' => 's', 'u' => 'u', 'ž' => 'z'
	);
	$str = preg_replace(array_keys($options['replacements']), $options['replacements'], $str);
	if ($options['transliterate']) {
		$str = str_replace(array_keys($char_map), $char_map, $str);
	}
	$str = preg_replace('/[^\p{L}\p{Nd}]+/u', $options['delimiter'], $str);
	$str = preg_replace('/(' . preg_quote($options['delimiter'], '/') . '){2,}/', '$1', $str);
	$str = mb_substr($str, 0, ($options['limit'] ? $options['limit'] : mb_strlen($str, 'UTF-8')), 'UTF-8');
	$str = trim($str, $options['delimiter']);
	return $options['lowercase'] ? mb_strtolower($str, 'UTF-8') : $str;
}

function getCombinations($array){	
	$length = count($array);
	$combocount=pow(2,$length);
	for ($i = 0;$i<=$combocount;$i++){
		$binary=decextbin($i,$length);
		$combination='';
		for($j=0;$j<$length;$j++)
		{
			if($binary[$j]=="1")
				$combination.=$array[$j].' ';
		}
		$combinationsarray[]=$combination;			
	}
	return array_reverse($combinationsarray);
}
	
function decextbin($decimalnumber,$bit){
	$binarynumber = '';
	$maxval = 1;
	$sumval = 1;
	for($i=1;$i< $bit;$i++){
		$maxval = $maxval * 2;
		$sumval = $sumval + $maxval;
	} 
	if ($sumval < $decimalnumber) return 'ERROR - Not enough bits to display this figure in binary.';
	for($bitvalue=$maxval;$bitvalue>=1;$bitvalue=$bitvalue/2){
		if (($decimalnumber/$bitvalue) >= 1) $thisbit = 1; else $thisbit = 0;
		if ($thisbit == 1) $decimalnumber = $decimalnumber - $bitvalue;
		$binarynumber .= $thisbit;
	}
	return $binarynumber;
}
	
function safeStr($txt){
	return $txt;
}

function cleanStr($txt){
	return stripslashes(stripslashes($txt));
}

function toHMS($seconds) {
	$t = round($seconds);
	if(($t/3600) >= 1){
		return sprintf('%02d:%02d:%02d', ($t/3600),($t/60%60), $t%60);
	}else{
		return sprintf('%02d:%02d', ($t/60%60), $t%60);
	}
}

function formatSize($size, $precision = 2){
	$base = log($size, 1024);
	$suffixes = array('', 'Kb', 'MB', 'GB', 'TB','PB','EB');   
	return round(pow(1024, $base - floor($base)), $precision) .' '. $suffixes[floor($base)];
}
	
function getMetaFromFile($file, $type = 'theme', $obj = false){
	if($type==='theme'){
		$Headers = array(
			'Name'        => 'Theme Name',
			'ThemeURI'    => 'Theme URI',
			'Author'      => 'Author',
			'AuthorURI'   => 'Author URI',
			'Version'     => 'Version'
		);
	}else if($type==='plugin'){
		$Headers = array(
			'Name'        => 'Plugin Name',
			'PluginURI'    => 'Plugin URI',
			'Author'      => 'Author',
			'AuthorURI'   => 'Author URI',
			'Version'     => 'Version',
			'Description' => 'Description'
		);
	}else if($type==='lang'){
		$Headers = array(
			'Name'        => 'LangName',
			'Code'    => 'LangCode'			
		);
	}
	$fp = fopen($file, 'r');
    $file_data = fread( $fp, 8192 );
    fclose($fp);	
    $file_data = str_replace( "\r", "\n", $file_data);		    
	$list = array();
	foreach($Headers as $field => $regex):
		if(preg_match( '/^[ \t\/*#@]*' . preg_quote( $regex, '/' ) . ':(.*)$/mi', $file_data, $match) && $match[1]){
			$list[$field] = trim(preg_replace("/\s*(?:\*\/|\?>).*/", '', $match[1]));
		}
	endforeach;
	return $obj === true ? JSON($list, true) : $list;
}

function getSetting($field, $json = false, $toArr = false){
	$value = DB::SELECT("SELECT valu FROM settings WHERE optn=? LIMIT 1", array($field), "s")->row->valu;
	return $json === true ? json_decode($value, $toArr) : $value;
}

function setSetting($field, $value, $json = false){
	$value = $json == true ? json_encode($value) : $value;
	$is = DB::SELECT("SELECT valu FROM settings WHERE optn=? LIMIT 1", array($field), "s");
	if($is->count > 0){
		DB::UPDATE("UPDATE settings SET valu=? WHERE optn=?", array($value,$field), "ss");
	}else{
		DB::INSERT("INSERT INTO settings (optn,valu,status) VALUES(?,?,?)", array($field,$value,"yes"), "sss");
	}
}

function getActivePlugins(){
	$list = getSetting('plugins');
	return $list == 'none' ? false : JSON(@json_decode($list), true);
}

function get_theme($mod){
	$mod = $mod == 'home' ? 'index' : $mod;
	include(THEME . "header.php");
	include(THEME . $mod . ".php");
	include(THEME . "footer.php");
}

function zuz_que_javascript($id, $uri, $tags = 'defer', $type = 'text/javascript'){
	global $ZUZ_JAVASCRIPT_LIST;
	if(in_array($id, $ZUZ_JAVASCRIPT_LIST)===false){
		$ZUZ_JAVASCRIPT_LIST[$id] = array('tags' => $tags, 'link' => $uri, 'type' => $type);
	}	
}

function load_javascript_que(){
	global $ZUZ_JAVASCRIPT_LIST;
	if(count($ZUZ_JAVASCRIPT_LIST) <= 0) return;
	foreach($ZUZ_JAVASCRIPT_LIST as $id => $js):
		echo "<script type=\"".$js['type']."\" id=\"".$id."\" src=\"".$js['link']."\" ".$js['tags']."></script>\n";
	endforeach;
}

function zuz_que_css($id, $base, $dir, $files){
	global $ZUZ_CSS_LIST;	
	if(in_array($id, $ZUZ_CSS_LIST)===false){
		$ZUZ_CSS_LIST[$id] = array(
			'base' => $base,
			'dir' => $dir,
			'files' => $files
		);
	}	
}

function load_css_que($PRINT=FALSE){
	global $ZUZ_CSS_LIST;	
	if(count($ZUZ_CSS_LIST) <= 0) return;
	$buffer = '<style>';
	foreach($ZUZ_CSS_LIST as $id => $css):
		if(isMobile()){
			$fi = $css['dir'] . $css['files']['mobile'];
			$fr = $css['base'] . $css['files']['mobile'];				
		}else if(isTablet()){
			$fi = $css['dir'] . $css['files']['tablet'];
			$fr = $css['base'] . $css['files']['tablet'];
		}else{
			$fi = $css['dir'] . $css['files']['desktop'];
			$fr = $css['base'] . $css['files']['desktop'];
		}
		if($PRINT===TRUE){				
			$buffer .= fixVars(@file_get_contents($fi));			
		}else{
			echo "<link rel=\"stylesheet\" href=\"".$fr."\" media=\"screen\" />\n";
		}		
	endforeach;
	if($PRINT===TRUE){
		$buffer .= '</style>';
		$buffer = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $buffer);
		$buffer = str_replace(': ', ':', $buffer);
		$buffer = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $buffer);
		echo $buffer;
	}
}

function getMail($subject, $message){
	$_mail = '<div style="margin:0 auto;width:520px;font-family:segoe ui regular, sans-serif, arial, tahoma;font-size:16px;position:relative;">
		<div style="border: 1px #d6d6d6 solid;border-radius: 3px;padding: 40px;color:#333;">
			<a href="'.BASEURL.'?f=mail" style="text-decoration:none;display:block;margin-bottom:50px;"><img src="'.BASEURL.'ui/logo-mail.png" style="display:block;margin:0 auto;height:50px;outline:none;"></a>
			'.$message.'							
		</div>
		<div style="padding:10px 0px;position:relative;color:#999;font-size:12px;width:100%;box-sizing:border-box;">
			'.MAIL_FOOTER.' &mdash; &copy; '.date("Y").' '.SITE_NAME.'
		</div>				
	</div>';
	return $_mail;
}

function SendMail($from, $to, $subject, $message, $debug = false){		
	require_once(ZUZINC . 'thirdparty/phpmailer/PHPMailerAutoload.php');
	$from_name = SITE_NAME;
	$mail = new PHPMailer;
	$mail->IsSMTP();
	if($debug==true){
		$mail->SMTPDebug = 2;
		$mail->Debugoutput = 'html';
	}
	$mail->Host = MAIL_HOST;
	$mail->Port = MAIL_PORT;
	$mail->SMTPAuth = true;
	$mail->Username = $from['user'];
	$mail->Password = $from['pass'];
	$mail->SMTPDebug = false;
	$mail->SMTPSecure = 'tls';
	$mail->SMTPOptions = array(
		'ssl' => array(
			'verify_peer' => false,
			'verify_peer_name' => false,
			'allow_self_signed' => true
		)
	);
	$mail->From = $from['user'];
	$mail->FromName = $from['name'];
	$mail->AddAddress($to['mail'], $to['name']);
	$mail->IsHTML(true);
	$mail->Subject = $subject;
	$mail->Body = $message;
	$mail->Send();
}

function pagination($total, $limit, $start, $currentpage, $linkfirst, $prevlink, $prev, $next, $nextlink, $linklast, $link_i, $pagetitle = ''){
	$return = ''; if($start==0){ $start = 1; }
	$totalpages = ceil($total/$limit);
	if(!($currentpage<=1)){					
		$return .= '<li class="nd"><a href="'.$linkfirst.'" title="'.$pagetitle.'" class="ibl noul btn fontb size14 anim" >'.lang('page_first').'</a></li>';
	}else{
		$return .= '<li class="nd"><div class="ibl noul btn no-select fontb size14">'.lang('page_first').'</div></li>';	
	}			
	if(!($currentpage<=1)){					
		$return .= '<li><a href="'.$prevlink.'" title="'.$pagetitle.' - '.lang('page').' '.$prev.'" class="withpstate ibl noul btn fontb size14 anim">'.lang('page_previous').'</a></li>';
	}else{
		$return .= '<li><div class="ibl noul btn size14 fontb">'.lang('page_previous').'</div></li>';
	}	
	$range = 3;
	if($currentpage<$range){
		$begin = 1;	
	}else{
		$begin = $currentpage-2;
	}	
	if(($begin+$range)<=$totalpages){
		$end = $begin+$range;	
	}else{
		$begin = $totalpages-$range;
		$end = $totalpages;
	}
	if($begin<=0){		$begin = 1;	}			
	for($i=$begin;$i<=$end;$i++){										
		if($i!=$currentpage){							
			$return .= '<li class="nd"><a href="'.$link_i.$i.'" title="'.$pagetitle.' - '.lang('page').' '.$i.'" class="withpstate ibl noul btn fontb size14 anim">'.$i.'</a></li>';
		}else{							
			$return .= '<li class="nd ndi"><div class="ibl noul on btn btni size14 fontb">'.$i.'</div></li>';
		}															
	}
	if(!($start >= $total-$limit)){
		$return .= '<li><a href="'.$nextlink.'" title="'.$pagetitle.' - '.lang('page').' '.$next.'" class="withpstate ibl noul btn fontb size14 anim">'.lang('page_next').'</a></li>';
	}else{
		$return .= '<li><div class="ibl noul btn size14 fontb">'.$lang['page_next'].'</div></li>';
	}		
	if($currentpage!=$totalpages){
		$return .= '<li class="nd"><a href="'.$linklast.'" title="'.$pagetitle.' - '.lang('page').' '.$totalpages.'" class="withpstate ibl noul btn size14 fontb anim">'.lang('page_last').'</a></li>';
	}else{
		$return .= '<li class="nd"><div class="ibl noul btn size14 fontb">'.lang('page_last').'</div></li>';	
	}			
	return $return;
}

function getAvailableLangs(){
	$list = scandir(LANG_DIR);
	$ignore = array('.','..','index.php');
	$arr = array();
	for($n = 0; $n < count($list); $n++):
		if(!in_array($list[$n], $ignore)){ $arr[] = getMetaFromFile(LANG_DIR . $list[$n], 'lang');  }
	endfor;
	return $arr;
}

function getDP($gid, $fbid){
	if($gid!=0){
		$json = @json_decode(str_replace("$", "", ___CURL("http://picasaweb.google.com/data/entry/api/user/".$gid."?alt=json", false)))->entry;
		return JSON(array(
			'name' => $json->gphotonickname->t,
			'dp' => $json->gphotothumbnail->t
		), true);
	}
}

function signup($uid, $email, $fname, $lname, $offline, $mod = 'google', $utype = 'user'){
	global $hash; global $browser;
	$_isa = array('admin','moderator');
	$utoken = randit(12);		
	$ucode = randit(8);
	$accesstoken = strtolower(randit(20));
	$expiry = time() + (86400 * 7);
	$browserInfo = $browser->getBrowser().'@@'.$browser->getVersion().'@@'.$browser->getPlatform();
	$time = time();					
	$geo = @json_decode(Geo()); $location = is_object($geo) ? $geo->IP.'@@'.$geo->city.'@@'.$geo->country->name : 'none@@none@@none';		
	$chk = DB::SELECT("SELECT ID,utype,email,fname,lname FROM users WHERE email=? LIMIT 1", array($email), "s");
	$ruri = BASEURL;	
	if($chk->result=="ok" && $chk->count > 0){
		$_UID = (int) $chk->row->ID;		
		$update = DB::UPDATE("UPDATE users SET token=?,last_login=?,last_login_location=? WHERE ID=? LIMIT 1", 
		array($accesstoken,time(),$location,$_UID), "sssi");		
		$cookie = encode($_UID.'@@'.$hash->encode($_UID).'@@'.$expiry.'@@'.$browserInfo);
		$uinfo = $browserInfo.'@@'.$location;					
		DB::INSERT("INSERT INTO users_sess (uid,token,expiry,uinfo) VALUES (?,?,?,?)",array($_UID,$cookie,$expiry,$uinfo), "isss");
		COOKIE(USER_COOKIE, $cookie, 24*7, true);		
		return JSON(array(
			'kind' => 'zuz#signinResponse',
			'etag' => encode(time()),
			'uri' => $ruri,
			'message' => lang('redirecting')
		)); exit;
	}else{		
		$password = randit(8);
		$pass = encode($password);		
		$nDP = "no-dp.png";
		if($mod=="google"){
			$idField = "googleid";
			$xdp = parse_url(getDP($uid, 0)->dp);
			$dp = $xdp['scheme'].'://'.$xdp['host'];
			$dp .= str_replace("/s64-c/", "/s500-c/", $xdp['path']);
			$nDP = $uid.'.jpg';
			@file_put_contents(BASEPATH . "assets/dps/".$nDP, @file_get_contents($dp));
		}else{
			$idField = "fbid";
			//save dp from facebook
		}
		$new = DB::INSERT("INSERT INTO users (token,ucode,utype,locked,".$idField.",googletoken,email,password,fname,lname,dp,join_date,join_location,last_login,last_login_location,status)
		VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", array($utoken,$ucode,$utype,'no',$uid,'__none__',$email,$pass,$fname,$lname,$nDP,time(),$location,time(),$location,'active'),
		"sssissssssssssss");
		if($new->result!="ok"){
			return JSON(array(
				'message' => lang('error_unable_to_process_request')
			), false); exit;
		}
		
		$_UID = $new->ID;		
		$cookie = encode($_UID.'@@'.$hash->encode($_UID).'@@'.$expiry.'@@'.$browserInfo);
		$uinfo = $browserInfo.'@@'.$location;					
		DB::INSERT("INSERT INTO users_sess (token,expiry,uinfo) VALUES (?,?,?)",array($cookie,$expiry,$uinfo), "sss");
		COOKIE(USER_COOKIE, $cookie, 24*7);
		$serviceName = $mod == 'google' ? 'Google' : 'Facebook';
		$_mail = getMail(
			lang('mail_signup_subject_with_name', array(SITE_NAME, $fname)),			
			lang('mail_signup_msg', array($fname, SITE_NAME, SITE_NAME, ADMIN_EMAIL, SITE_NAME))
		);
		SendMail(
			array('user' => MAIL_FROM, 'pass' => MAIL_PASSWORD, 'name' => SITE_NAME),
			array('mail' => $email, 'name' => $fname.' '.$lname),
			lang('mail_signup_subject', array(SITE_NAME)),
			$_mail
		);
		return JSON(array(
			'kind' => 'zuz#signinResponse',
			'etag' => encode(time()),
			'uri' => $ruri,
			'message' => lang('redirecting')
		));	
		exit;
	}		
}

function getUser(){
	if(isset($_COOKIE[USER_COOKIE])){
		global $browser; global $hash;
		$cToken = $_COOKIE[USER_COOKIE];
		$expiryNow = time();
		$inDB = DB::SELECT("SELECT expiry FROM users_sess WHERE token=? AND expiry>? LIMIT 1", array($cToken, time()), "ss");
		if($inDB->count == 0){
			return JSON(array('is' => false, 'reason' => 'Invalid token'), true); exit;
		}
		@list($UID, $hashUID, $expiry, $browserName, $browserVersion, $browserOS) = explode("@@", decode($cToken));
		if(empty($UID) || empty($hashUID)){
			return JSON(array('is' => false, 'reason' => 'Empty User ID'), true); exit;
		}
		if($browserName!=$browser->getBrowser() || $browser->getVersion()!=$browserVersion || $browser->getPlatform()!=$browserOS){
			return JSON(array('is' => false, 'reason' => 'Browser mismatched'), true); exit;
		}		
		if(!is_numeric($UID) || $UID <= 0){ return JSON(array('result' => 'fail'), true); exit; }
		$user = DB::SELECT("SELECT * FROM users WHERE ID=? AND status!=? AND status!=? LIMIT 1",
		array($UID, 'banned', 'deleted'), "iss");
		if($user->count==0){ return JSON(array('is' => false, 'reason' => 'User not exists'), true); exit; }
		$dp = BASEURL . 'dp/' . encode($user->row->dp . '@@' . $user->row->googleid . '@@' . $user->row->fbid) . '/100x100/picture.jpg';							
		$time = time();
		DB::UPDATE("UPDATE users SET last_login=? WHERE ID=? LIMIT 1", array(time(),$UID), "si");
		return JSON(array(
			'is' => true,
			'ID' => $UID,
			'UID' => $hash->encode($UID),
			'name' => array(
				'first' => $user->row->fname, 
				'last' => $user->row->lname, 
				'full' => $user->row->fname.' '.$user->row->lname
			),
			'email' => $user->row->email,
			'me' => $user->row,
			'type' => $user->row->utype,
			'dp' => $dp
		), true);
		exit;
	}
	return JSON(array('is' => false), true);
}

function user_can($sess, $accesstype = 'all'){
	if($sess->is==false || $sess->type=='user') return false;
	if($sess->type=='admin') return true;
	if($accesstype=='all') return true;
	$ex = explode(",", getSetting('admin_allow_moderator'));
	return in_array($accesstype, $ex) ? true : false;
}

function getAccessToken($type, $expiry){
	$token = encode($expiry);
	$save = DB::INSERT("INSERT INTO accesstokens (type,token) VALUES (?,?)", array($type, $token), "ss");
	return encode($type . '@@@' . $save->ID . '@@@' . $token);
}

function verifyAccessToken($token){
	@list($type, $ID, $token) = explode("@@@", decode($token));
	$get = DB::SELECT("SELECT ID FROM accesstokens WHERE ID=? AND type=? AND status=? LIMIT 1", array($ID, $type, 'pending'), "iss"); 
	if($get->count > 0){
		DB::UPDATE("UPDATE accesstokens SET status=? WHERE ID=? LIMIT 1", array('used',$ID), "si");
		return (decode($token) - time()) > 0 ? true : false;		
	}
	return false;
}

function streamLink($item, $format = 128){
	if(strpos($item->formats, '@@@') !== false){
		@list($format, $quality) = explode("@@@", $item->formats);
		@list($quality) = explode(",", $quality);
		return encode($item->ID.'@@'.$item->server.'@@'.$item->filename.'@@'.$quality.'@@'.stripslashes($item->title).'@@'.$format.'@@'.time());
	}else{
		@list($format) = explode(",", $item->formats);
		return encode($item->ID.'@@'.$item->server.'@@'.$item->filename.'@@'.$format.'@@'.stripslashes($item->title).'@@'.time());
	}
}
	
?>