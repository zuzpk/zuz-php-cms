<?php
function siteError($title, $message){
	echo '<!DOCTYPE html><html xmlns="http://www.w3.org/1999/xhtml">'
		. '<head>'
			. '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />'
			. '<meta name="viewport" content="width=device-width">'
			. '<title>'.$title.'</title>'
			. '<style type="text/css">'
				. '@font-face{font-family: "font_n";src: url("' . BASEURL . 'ui/fonts/normal.woff") format("woff");}'
				. '@font-face{font-family: "font_b";src: url("' . BASEURL . 'ui/fonts/bold.woff") format("woff");}'
				. '.fontb{font-family:font_b;}'
				. 'p{margin: 5px 0px;padding:0px;}'
				. '.s16{font-size:16px;}'
				. 'body{margin: 0px;padding: 0px;background: #f1f1f1;font-family: font_n, segoe ui, arial;}'
				. '.error{background: #fff;padding:40px;width: 25vw;margin: 0 auto;margin-top: 50px;text-align: center;font-size: 18px;border-radius: 3px;box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.16);}'
				. '.logo{display: block;margin: 0 auto;margin-bottom: 30px;height: 80px;}'
				. 'h2{margin: 0px;padding:0px;font-size: 18px;}'
				. '.btn{text-decoration: none;color: #fff;background: rgb(77, 175, 36);line-height: 1;padding: 8px 15px;display: table;margin-top: 20px;border: 1px #3e901c solid;border-radius: 2px;box-shadow: 0px 1px 1px rgba(0, 0, 0, 0.31);cursor:pointer;}'
				. '.btn:hover{background:rgb(90, 187, 49);border: 1px #489e24 solid;box-shadow:0px 1px 1px rgba(0, 0, 0, 0.18);}'
			. '</style>'
		. '</head>'
		. '<body id="error-page">'
			. '<div class="error"><img src="' . BASEURL . 'ui/zuz-logo.png" class="logo">' . $message . '</div>'
		. '</body>'
	. '</html>';
}

function getTitle(){
	if(is_home_page()){
		return SITE_NAME .' &ndash; ' . SITE_SLOGAN;
	}else if(is_genre_page()){
		return lang('genres') .' &ndash; ' . SITE_NAME;
	}
}

function getMeta(){
	echo '<meta name="robots" content="all" />' . "\n"
	. '<meta name="revisit-after" content="1 days" />' . "\n"
	. '<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">' . "\n"
	. '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">' . "\n";
}

function fixVars($txt){
	$txt = str_replace("{baseurl}", BASEURL, $txt);
	return $txt;
}

function getNavigation($signin = false, $utype = 'user'){
	global $ZUZ_NAV;
	$sess = getUser();
	$list = array();
	if(getSetting('site_status')==='offline' || (getSetting('must_signin') == 'yes' && getUser()->is===false)){
		for($n = 0; $n < count($ZUZ_NAV); $n++):
			if($ZUZ_NAV[$n]['link']=='account'){
				array_push($list, array(
					'label' => $ZUZ_NAV[$n]['label'],
					'icon' => $ZUZ_NAV[$n]['icon'],
					'link' => $ZUZ_NAV[$n]['link']
				));
				break;
			}
		endfor;
	}else{
		for($n = 0; $n < count($ZUZ_NAV); $n++):		
			if(
				$ZUZ_NAV[$n]['type'] == 'public' ||
				($ZUZ_NAV[$n]['type'] == 'guest' && $sess->is === false) ||
				($sess->is === true && strpos($ZUZ_NAV[$n]['type'], $sess->type) !== false)
			){
				array_push($list, array(
					'label' => $ZUZ_NAV[$n]['label'],
					'icon' => $ZUZ_NAV[$n]['icon'],
					'link' => $ZUZ_NAV[$n]['link']
				));
			}
		endfor;	
	}
	return JSON($list);
}

function getAdminNavigation($type = 'admin'){
	global $ZUZ_NAV_ADMIN; $list = array(); $allow = 'all';
	if($type=='moderator'){
		$allow = explode(",", getSetting('admin_allow_moderator'));
	}	
	for($n = 0; $n < count($ZUZ_NAV_ADMIN); $n++):		
		$itm = array(
				'label' => $ZUZ_NAV_ADMIN[$n]['label'],
				'icon' => $ZUZ_NAV_ADMIN[$n]['icon'],
				'link' => $ZUZ_NAV_ADMIN[$n]['link']
			);			
		if($type == 'admin' || !is_array($allow) || $ZUZ_NAV_ADMIN[$n]['permission'] == 'all' || (is_array($allow) && in_array($ZUZ_NAV_ADMIN[$n]['permission'], $allow))){
			array_push($list, $itm);
		}
	endfor;	
	return JSON($list);
}

function getHomeTabs(){
	global $ZUZ_NAV_HOME;
	return JSON($ZUZ_NAV_HOME);	
}

function loadCSS($array){
	$buffer = '<style>';
	if(isMobile()){
		$list = $array['mobile'];
	}else if(isTablet()){
		$list = $array['tablet'];
	}else{
		$list = $array['desktop'];
	}	
	for($n = 0; $n < count($list); $n++):
		if(file_exists(THEME . $list[$n])){
			$buffer .= fixVars(@file_get_contents(THEME . $list[$n]));
		}
	endfor;
	if(isset($array['remote']) && count($array['remote']) > 0){
		for($n = 0; $n < count($array['remote']); $n++):
			$buffer .= fixVars(@file_get_contents($array['remote'][$n]));
		endfor;
	}
	$buffer .= '</style>';
	$buffer = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $buffer);
	$buffer = str_replace(': ', ':', $buffer);
	$buffer = str_replace(array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $buffer);
	echo $buffer;
}

function plugin_url($__FILE__){
	$path = str_replace(basename($__FILE__), "", $__FILE__);
	return str_replace(BASEPATH, BASEURL, $path);
}

function posterUrl($type, $img, $mod = 'none', $x = 0, $y = 0){
	$xy = $x <= 0 || $y <= 0 ? "" : $x.'x'.$y.'/';
	switch($type):
		case "album":
			$uri = BASEURL . 'photo/album/'.encode(str_replace("thumb_", "", $img)).'/'.$xy.'default.jpg';
		break;
		case "track":
			$uri = BASEURL . 'photo/track/'.encode(str_replace("thumb_", "", $img) . '@@' . $mod).'/'.$xy.'default.jpg';
		break;
	endswitch;
	return $uri;
}

function trackUrl($item){
	$pattern = getSetting('url_rewrite');
	return BASEURL . str_replace('%slug%', $item->slug, $pattern);
}

function getGenres(){
	$list = DB::SELECT("SELECT * FROM genres WHERE status=? ORDER BY title ASC", array("yes"), "s");
	$data = array();
	if($list->count > 0){
		for($n = 0; $n < count($list->fetch); $n++):
			$data[] = toGenreArray($list->fetch[$n], false);
		endfor;			
	}
	return JSON($data);
}

function getGenreById($ID){	
	$ID = (int) $ID;	
	$item = DB::SELECT("SELECT * FROM genres WHERE ID=? AND status=? LIMIT 1", array($ID, "yes"), "is");
	return $item->count > 0 ? toGenreArray($item->row, false) : array();
}

function getAlbums(){
	$list = DB::SELECT("SELECT * FROM albums WHERE status=? ORDER BY title ASC", array("yes"), "s");
	$data = array();
	if($list->count > 0){
		for($n = 0; $n < count($list->fetch); $n++):
			$data[] = toAlbumArray($list->fetch[$n]);
		endfor;			
	}
	return JSON($data);
}

function getAlbumById($ID){
	if($ID<=0) return array();
	$album = DB::SELECT("SELECT * FROM albums WHERE ID=?", array($ID), "i");
	return $album->count > 0 ? toAlbumArray($album->row) : array();		
}

function getRandomTrackByGenre($ID){
	$track = DB::SELECT("SELECT * FROM tracks WHERE genre=? ORDER BY ID DESC LIMIT 1", array($ID), "i");
	if($track->count > 0){
		return toTrackArray($track->row);	
	}else{
		return array();
	}	
}

function toGenreArray($item, $addTrack = true){
	global $hash;	
	return array(
		'ID' => isset($item->ID) ? $hash->encode($item->ID) : 0,
		'title' => cleanStr($item->title),
		'slug' => $item->slug,
		'tracks' => $addTrack === true ? $item->tracks : array(),
		'track' => isset($item->ID) && $addTrack === true ? getRandomTrackByGenre($item->ID) : array(),
		'url' => BASEURL . 'genres/' . $item->slug
	);	
}

function toArtistArray($item, $tracks = false, $albums = false){
	global $hash;
	$o = array(
		'ID' => $hash->encode($item->ID),
		'name' => cleanStr($item->title),
		'slug' => $item->slug,
		'photo' => array(
			'orignal' => BASEURL . 'adp/' . encode($item->dp) . '/0x0/picture.jpg',
			'raw' => BASEURL . 'adp/' . encode($item->dp) . '/{w}x{h}/picture.jpg',
			'cropped' => BASEURL . 'adp/' . encode($item->dp) . '/200x200/picture.jpg'
		),
		'url' => BASEURL . 'artist/' . $item->slug
	);
	if($albums===true){
		$list = DB::SELECT("SELECT * FROM albums WHERE artistid=? AND status=? ORDER BY RAND() LIMIT ?", array($item->ID, 'yes', 10), "isi");
		if($list->count > 0){			
			$albums = array();
			for($i = 0; $i < count($list->fetch); $i++):
				$albums[] = toAlbumArray($list->fetch[$i]);
			endfor;			
			$o['albums'] = $albums;
		}
	}
	if($tracks===true){
		$list = DB::SELECT("SELECT * FROM tracks WHERE artist=? AND status=? ORDER BY views DESC LIMIT ?", array($item->ID, 'yes', 10), "isi");
		if($list->count > 0){			
			$tracks = array();
			for($i = 0; $i < count($list->fetch); $i++):
				$tracks[] = toTrackArray($list->fetch[$i]);
			endfor;			
			$o['tracks'] = $tracks;
		}
	}	
	return $o;
}

function toServerArray($item){
	global $hash;
	return array(
		'ID' => $hash->encode($item->ID),
		'locked' => $item->locked,
		'status' => $item->status,
		'title' => cleanStr($item->title),
		'address' => $item->address,
		'disk' => array(
			'total' => $item->tspace <= 0 ? '0 Bytes' : formatSize($item->tspace),
			'used' => $item->bspace <= 0 ? '0 Byte' : formatSize($item->bspace),
			'percent' => $item->bspace <= 0 ? '0' : round(($item->bspace / $item->tspace) * 100, 3),
			'raw' => round($item->tspace / (1024 * 1024 * 1024))
		),
		'link' => strpos($item->address, 'oyecdn.us') !== false ? 'https://zuz.host/marketplace/diskspace?sid='.$hash->encode($item->ID).'&dt='.$item->tspace.'&du='.$item->bspace.'&ur='.base64_encode(BASEURL) : '',
		'time' => date('d M Y', $item->added)
	);
}

function getArtists(){
	$list = DB::SELECT("SELECT * FROM artists WHERE status=? ORDER BY title ASC", array("yes"), "s");
	$data = array();
	if($list->count > 0){
		for($n = 0; $n < count($list->fetch); $n++):
			$data[] = toArtistArray($list->fetch[$n]);
		endfor;			
	}
	return JSON($data);
}

function getArtistById($ID){
	if($ID<=0){ return array('empty' => true); }
	$artist = DB::SELECT("SELECT * FROM artists WHERE ID=?", array($ID), "i")->row;
	return toArtistArray($artist);
}

function toAlbumArray($item, $include_tracks = false){
	global $hash;
	$duration = 0; $tracks = array();
	if($include_tracks===true){
		$list = DB::SELECT("SELECT * FROM tracks WHERE albumid=? AND status=? ORDER BY title ASC", array($item->ID,'yes'), "is");
		if($list->count > 0){			
			for($n = 0; $n < count($list->fetch); $n++):
				$duration += $list->fetch[$n]->duration;
				$tracks[] = toTrackArray($list->fetch[$n]);
			endfor;
		}
	}
	$genreid = (int) $item->genreid;
	$arr = array(
		'ID' => $hash->encode($item->ID),
		'title' => cleanStr($item->title),
		'slug' => $item->slug,
		'artist' => getArtistById($item->artistid),
		'genre' => $genreid == 0 ? 'none' : getGenreById($item->genreid),
		'year' => $item->year == 'none' ? '0000' : $item->year,
		'tracksCount' => $item->tracks,		
		'duration' => toHMS($duration),
		'poster' => posterUrl('album', $item->photo),
		'url' => BASEURL . 'album/' . $item->slug		
	);	
	if($include_tracks === true){
		$arr['tracks'] = $tracks;
	}
	return $arr;
}

function toTrackArray($item){
	global $hash;
	return array(
		'ID' => $hash->encode($item->ID),		
		'title' => cleanStr($item->title),
		'slug' => $item->slug,
		'tags' => cleanStr($item->tags),
		'poster' => posterUrl('track', $item->poster, $item->type),
		'duration' => toHMS($item->duration),
		'artist' => is_numeric($item->artist) && $item->artist > 0 ? getArtistById($item->artist) : cleanStr($item->artist),
		'genre' => getGenreById($item->genre),
		'formats' => cleanStr($item->formats),
		'views'	=> number_format($item->views),
		'modified' => date("d M Y", $item->added),
		'url' => trackUrl($item),
		'stream' => streamLink($item),
		'album' => getAlbumById($item->albumid)
	);	
}

function toPlaylistArray($item, $isAdmin = false){
	global $hash;
	$PID = $item->ID;
	$ids = $item->tracks;
	$tracks = array();
	$_TRACK = '';
	$_LENGTH = 0;	
	if($ids!="0"){		
		$_ids = explode(",", $ids);
		$ids = array(); foreach($_ids as $id): if(!empty($id)){array_push($ids, $id);} endforeach;		
		if(count($ids)>0){
			$trackList = DB::SELECT("SELECT * FROM tracks WHERE ID IN (".implode(",",$ids).") AND status=?", array('yes'), "s");	
			if($trackList->count > 0){
				for($i = 0; $i < count($trackList->fetch); $i++):
					$tracks[] = toTrackArray($trackList->fetch[$i]);
					$_LENGTH += $trackList->fetch[$i]->duration;
				endfor;
				$_TRACK = $tracks[count($tracks)-1]['poster'];
			}
		}
	}
	$_n = array(
		'ID' => $hash->encode($PID),
		'url' => $isAdmin === true ? BASEURL . 'admin/playlists?id=' . $hash->encode($PID) : BASEURL . 'playlists/' . $hash->encode($PID),
		'name' => cleanStr($item->label),						
		'poster' => $_TRACK,
		'trackCount' => count($tracks),
		'duration' => toHMS($_LENGTH),
		'owner' => getUserById($item->uid, $isAdmin),
		'privacy' => $item->privacy=='public'?'open':'closed',
		'tracks' => $tracks
	);
	if($isAdmin===true){ $_n['type'] = $item->type; }
	return $_n;
}

function getUserById($ID, $isAdmin = false){
	$user = DB::SELECT("SELECT * FROM users WHERE ID=? LIMIT 1", array($ID), "i")->row;
	return toUserArray($user, $isAdmin);
}

function toUserArray($item, $isAdmin = false){
	global $hash;
	if($isAdmin===false){
		return array(
			'ID' => $hash->encode($item->ID),
			'name' => array(
				'first' => $item->fname,
				'last' => $item->lname,
				'full' => $item->fname . ' ' . $item->lname
			),
			'dp' => BASEURL . 'dp/' . encode($item->dp . '@@' . $item->googleid . '@@' . $item->fbid) . '/100x100/picture.jpg'
		);
	}
	@list($JOIN_IP, $JOIN_CITY, $JOIN_COUNTRY) = explode("@@", $item->join_location);
	@list($SIGNIN_IP, $SIGNIN_CITY, $SIGNIN_COUNTRY) = explode("@@", $item->last_login_location);
	return array(
		'ID' => $hash->encode($item->ID),
		'status' => $item->status,
		'type' => $item->utype,
		'locked' => $item->locked,
		'email' => $item->email,
		'name' => array(
			'first' => $item->fname,
			'last' => $item->lname,
			'full' => $item->fname . ' ' . $item->lname
		),
		'dp' => BASEURL . 'dp/' . encode($item->dp . '@@' . $item->googleid . '@@' . $item->fbid) . '/100x100/picture.jpg',
		'joined' => array(
			'time' => array(
				"stamp" => date("d M Y", $item->join_date),
				"ago" => timeAgo($item->join_date)
			),
			'location' => array(
				'ip' => $JOIN_IP,
				'city' => $JOIN_CITY,
				'country' => $JOIN_COUNTRY
			)
		),
		'signin' => array(
			'time' => array(
				"stamp" => date("d M Y", $item->last_login),
				"ago" => timeAgo($item->last_login)
			),
			'location' => array(
				'ip' => $SIGNIN_IP,
				'city' => $SIGNIN_CITY,
				'country' => $SIGNIN_COUNTRY
			)
		)
	);
}

function getSigninMethods($return = false){
	$list = '[';
	ob_start();
	zuzHook('signin_method', '');	
	$list .= ob_get_clean();	
	$list .= ']';
	if($return===true)
		return $list;
	else
		echo $list;
}

function getUploadMethods($return = false){
	$list = '[';
	ob_start();
	zuzHook('upload_method', '');	
	$list .= ob_get_clean();	
	$list .= ']';
	if($return===true)
		return $list;
	else
		echo $list;
}

function getQueJavascript(){
	$js = '<script>';
	ob_start();
	zuzHook('zuz_que_js', '');		
	$js .= ob_get_clean();
	$js .= '</script>';
	echo $js;
}

function CheckInstallerFile($return = true){
	if($return == true){
		return file_exists(BASEPATH . '__installer.php');
	}
	if(file_exists(BASEPATH . '__installer.php'))
		echo '<div class="installer_exist">Please remove `<b>__installer.php</b>` from ROOT Directory.</div><style>.installer_exist{z-index: 2147483638;position: fixed;bottom: 50px;background: #d05050;color: #fff;line-height: 1;padding: 10px 15px;transform: translateX(-50%);left: 50%;border-radius: 3px;font-weight: normal;font-size: 14px;}</style>';
}

function CheckVersion(){
	$get = @json_decode(___CURL('https://zuz.host/do/zuzmusicversion?ov=' . ZUZ_VERSION . '&bu=' . BASEURL . '&ae=' . ADMIN_EMAIL, false));
	if(ZUZ_VERSION < $get->version){
		$msg = lang('version_update_message', array($get->version, $get->release_date, ZUZ_VERSION));
		echo '<div class="__green_msg">'.$msg.'</div><style>.__green_msg{z-index: 2147483638;position: fixed;bottom: 50px;background: #2bb374;color: #fff;line-height: 1;padding: 10px 15px;transform: translateX(-50%);left: 50%;border-radius: 3px;font-weight: normal;font-size: 14px;}.__green_msg a{color: #ffffff;text-decoration:underline;}</style>';	
	}		
}

function Sitemap(){
	header("Content-Type: text/plain; charset=utf-8");
	echo BASEURL . "\n";
	echo BASEURL . "genres\n";
	echo BASEURL . "albums\n";
	echo BASEURL . "artists\n";
	echo BASEURL . "playlists\n";
	echo BASEURL . "search\n";
	echo BASEURL . "explore\n";	
	echo BASEURL . "contact\n";
	//albums
	$list = DB::SELECT("SELECT slug FROM albums WHERE status=? ORDER BY title ASC", array("yes"), "s");
	if($list->result=="ok" && $list->count > 0){
		for($n = 0; $n < count($list->fetch); $n++):					
			echo BASEURL . 'album/'.$list->fetch[$n]->slug."\n";
		endfor;		
	}
	//genres
	$list = DB::SELECT("SELECT slug FROM genres WHERE status=? ORDER BY title ASC", array("yes"), "s");
	if($list->result=="ok" && $list->count > 0){
		for($n = 0; $n < count($list->fetch); $n++):					
			echo BASEURL . 'genres/'.$list->fetch[$n]->slug."\n";
		endfor;		
	}		
	//tracks
	$list = DB::SELECT("SELECT slug FROM tracks WHERE status=? ORDER BY ID DESC", array("yes"), "s");
	if($list->result=="ok" && $list->count > 0){
		for($n = 0; $n < count($list->fetch); $n++):
			echo BASEURL . 'track/'.$list->fetch[$n]->slug."\n";
		endfor;		
	}
}

function GetMyLibrary($UID){
	global $hash;
	$list = DB::SELECT("SELECT * FROM playlists WHERE uid=? AND status=? ORDER BY label ASC", array($UID, "yes"), "is");
	$lists = array();
	if($list->count>0){
		for($n = 0; $n < count($list->fetch); $n++):
			$lists[] = array(
				'ID' => $hash->encode($list->fetch[$n]->ID),
				'name' => $list->fetch[$n]->label,
				'trackCount' => $list->fetch[$n]->tracks=='0'||$list->fetch[$n]->tracks==0?0:count(explode(",",$list->fetch[$n]->tracks))
			);
		endfor;
	}
	return JSON($lists);
}
?>