<?php
class DB{
	
	static $DBA;
	
	public static function Database(){
		if(defined(ZUZ_DEBUG) && ZUZ_DEBUG===FALSE){
			mysqli_report(MYSQLI_REPORT_STRICT);
		}
		if(!isset(self::$DBA)){
			self::$DBA = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
			if(self::$DBA->connect_error){
				die("Error in establishing Database Connection..."); exit;	
			}
			self::SET_CHARSET("utf8");
		}
	}
	
	public static function SET_CHARSET($set){
		self::$DBA->set_charset($set);
	}
	
	public static function SELECT($query, $values, $types){
		self::Database();
		self::SET_CHARSET('utf8');		
		$q = self::$DBA->prepare($query);		
		$q->bind_param($types, ...$values);
		$q->execute();
		$_COUNT = -1; $_ROW = ''; $_FETCH = array(); 		
		try{
			$result = $q->get_result();		
			if($result->num_rows>0){
				$n = 0;
				while($fo = $result->fetch_array()):
					if($n==0){ $_ROW = $fo; }
					$_FETCH[] = $fo;
					$n++;
				endwhile;
				$_COUNT = $result->num_rows;				
			}
		}catch(Exception $e){
			$meta = $q->result_metadata();
			$fields = $results = array();
			while ($field = $meta->fetch_field()) { 
				$var = $field->name; 
				$$var = null; 
				$fields[$var] = &$$var; 
			}
			call_user_func_array(array($q,'bind_result'),$fields);			
			$q->store_result();
			if($q->num_rows > 0){
				$i = 0;
				while ($q->fetch()) {
					$_FETCH[$i] = array();
					foreach($fields as $k => $v):
						$_FETCH[$i][$k] = $v;
					endforeach;
					$i++;
				}				
				$_COUNT = $q->num_rows;	
				$_ROW = $fields;
			}
		}
		
		if($_COUNT > 0){
			return JSON(array(
				'result' => 'ok',
				'count' => $_COUNT,
				'row' => $_ROW,
				'fetch' => $_FETCH			
			), true);
		}else{
			return JSON(array(
				'result' => 'no',
				'count' => 0
			), true);	
		}
		
	}
	
	public static function INSERT($query, $values, $types){
		self::Database();
		self::SET_CHARSET('utf8');
		$q = self::$DBA->prepare($query);		
		$_bnd = $q->bind_param($types, ...$values);		
		if(!$q){
			return JSON(array(
				'result' => 'failed'
			), true);
		}
		if($q->execute()){
			return JSON(array(
				'result' => 'ok',
				'ID' => $q->insert_id
			), true);
		}else{
			return JSON(array(
				'result' => 'failed',
				'error' => self::$DBA->errno
			), true);
		}
	}
	
	public static function UPDATE($query, $value, $types){
		self::Database();
		self::SET_CHARSET('utf8');
		$q = self::$DBA->prepare($query);
		$q->bind_param($types, ...$value);
		if($q->execute()){
			return JSON(array('result' => 'ok'), true);
		}else{
			return JSON(array('result' => 'failed', 'error' => $q->errno), true);
		}
	}
	
}
?>