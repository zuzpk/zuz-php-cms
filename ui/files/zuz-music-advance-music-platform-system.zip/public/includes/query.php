<?php
function getRequestUri(){	
	$uri = str_replace(BASEURL, "", CURRENT_URI);
	if(strpos($uri, "?") !== false){ @list($uri) = explode("?", $uri); }
	return '/' . $uri;
}

$REQUEST_URI = getRequestUri();

function getPaginationPosition(){
	global $REQUEST_URI; global $hash;
	$p = explode("/", parse_url($REQUEST_URI)['path']);
	$p = $p[count($p)-1];
	preg_match('/^p[0-9]+/', $p, $matches);
	$START = 1;
	if(count($matches)>0){
		$START = str_replace("p", "", $matches[0]);
	}
	return JSON(array('is' => true, 'page' => $START, 'token' => $hash->encode($START)), true); exit;
}

function zuz_console_request(){
	global $REQUEST_URI;
	$x = explode("/", $REQUEST_URI);
	if($x[1] == 'zuzconsole'){
		return JSON(array('is' => true, 'action' => $x[2]), true);
	}else{
		return JSON(array('is' => false), true);
	}
}

function zuz_sitemap_request(){
	global $REQUEST_URI;
	if(strpos($REQUEST_URI, "/sitemap.xml") !== false){
		return JSON(array('is' => true), true);
	}
	return JSON(array('is' => false), true);
}

function zuz_restapi_request(){
	global $REQUEST_URI;
	if(preg_match('/rest\/[\sa-zA-Z0-9-]+/', $REQUEST_URI)){
		@list($x, $y, $mod) = explode("/", $REQUEST_URI);
		return JSON(array('is' => true, 'method' => $mod), true);	
	}
	return JSON(array('is' => false), true);
}

function zuz_image_request(){
	global $REQUEST_URI;
	$x = explode("/", $REQUEST_URI);
	if($x[1] == 'photo'){
		return JSON(array('is' => true, 'type' => $x[2], 'token' => $x[3]), true);
	}else if($x[1] == 'dp'){
		return JSON(array('is' => true, 'type' => 'userdp', 'token' => $x[2], 'res' => $x[3]), true);
	}else if($x[1] == 'adp'){
		return JSON(array('is' => true, 'type' => 'artistdp', 'token' => $x[2], 'res' => $x[3]), true);
	}else{
		return JSON(array('is' => false), true);
	}
}

function is_signout_page(){
	global $REQUEST_URI;
	return $REQUEST_URI == "/signout" ? true : false;
}


function is_home_page(){
	global $REQUEST_URI;
	return $REQUEST_URI == "/" ? true : false;
}

function is_search_page(){
	global $REQUEST_URI;
	return $REQUEST_URI == "/search" ? true : false;
}

function is_genre_page(){
	global $REQUEST_URI;	
	if(preg_match('/genres\/[\sa-zA-Z0-9-]+/', $REQUEST_URI)){		
		$start = 1;
		if(preg_match('/genres\/[\sa-zA-Z0-9-]+\/p[0-9]+/', $REQUEST_URI)){
			@list($x, $xx, $slug, $p) = explode("/", $REQUEST_URI);
			$start = str_replace("p", "", $p);
		}else{
			@list($x, $xx, $slug) = explode("/", $REQUEST_URI);
		}
		return JSON(array('is' => true, 'mod' => 'list', 'slug' => $slug, 'page' => $start), true); exit;
	}else if(preg_match('/\/genres/', $REQUEST_URI)){
		return JSON(array('is' => true, 'mod' => 'root'), true); exit;
	}
	return JSON(array('is' => false), true); exit;
}

function is_album_page(){
	global $REQUEST_URI; $START = 1; $AID = 0;
	if(	preg_match('/\/albums/', $REQUEST_URI) || 
		preg_match('/\/album\/[A-Za-z0-9-]+/', $REQUEST_URI) ||
		preg_match('/\/albums\/p[0-9]+/', $REQUEST_URI)
	){
		if(preg_match('/\/album\/[A-Za-z0-9-]+/', $REQUEST_URI)){
			$AID = str_replace("/album/", "", $REQUEST_URI);
		}else if(preg_match('/albums\/p[0-9]+/', $REQUEST_URI)){
			$x = explode("/", $REQUEST_URI);
			$P = $x[count($x)-1];
			$START = (int) str_replace("p", "", $P);		
		}
		return JSON(array('is' => true, 'aid' => $AID, 'start' => $START), true); exit;
	}	
	return JSON(array('is' => false), true);
}

function is_playlist_page(){
	global $REQUEST_URI; $START = 1;
	if(preg_match('/\/playlists/', $REQUEST_URI) || preg_match('/playlists\/p[0-9]+/', $REQUEST_URI)){
		if(preg_match('/playlists\/p[0-9]+/', $REQUEST_URI)){
			$x = explode("/", $REQUEST_URI);
			$P = $x[count($x)-1];
			$START = (int) str_replace("p", "", $P);		
		}
		return JSON(array('is' => true, 'start' => $START), true); exit;
	}	
	return JSON(array('is' => false), true);
}

function is_explore_page(){
	global $REQUEST_URI; $START = 1; $SUB = '';
	if(preg_match('/\/explore/', $REQUEST_URI)){
		if(preg_match('/explore\/p[0-9]+/', $REQUEST_URI)){
			$x = explode("/", $REQUEST_URI);
			$P = $x[count($x)-1];
			$START = (int) str_replace("p", "", $P);					
		}else if(preg_match('/explore\/[A-Za-z0-9-]+/', $REQUEST_URI)){
			if(preg_match('/explore\/[A-Za-z0-9-]+\/p[0-9]+/', $REQUEST_URI)){
				$x = explode("/", $REQUEST_URI);
				$P = $x[count($x)-1];
				$START = (int) str_replace("p", "", $P);		
			}
			$x = explode("/", $REQUEST_URI);
			$P = $x[count($x)-1];
			$SUB = $x[count($x)-2];
			$START = (int) str_replace("p", "", $P);					
		}		
		return JSON(array('is' => true, 'sub' => $SUB, 'start' => $START), true); exit;
	}	
	return JSON(array('is' => false), true);
}

function is_tracks_page(){
	global $REQUEST_URI; $START = 1; $SUB = '';
	if(preg_match('/\/tracks/', $REQUEST_URI) || preg_match('/\/track/', $REQUEST_URI)){
		if(preg_match('/track\/[A-Za-z0-9]+/', $REQUEST_URI)){
			$x = explode("/", $REQUEST_URI);			
			$SUB = $x[count($x)-1];
		}else{
			if(preg_match('/tracks\/p[0-9]+/', $REQUEST_URI)){
				$x = explode("/", $REQUEST_URI);
				$P = $x[count($x)-1];
				$START = (int) str_replace("p", "", $P);					
			}else if(preg_match('/tracks\/[A-Za-z0-9-]+/', $REQUEST_URI)){
				if(preg_match('/tracks\/[A-Za-z0-9-]+\/p[0-9]+/', $REQUEST_URI)){
					$x = explode("/", $REQUEST_URI);
					$P = $x[count($x)-1];
					$START = (int) str_replace("p", "", $P);		
				}
				$x = explode("/", $REQUEST_URI);
				$P = $x[count($x)-1];
				$SUB = $x[count($x)-2];
				$START = (int) str_replace("p", "", $P);					
			}		
		}
		return JSON(array('is' => true, 'sub' => $SUB, 'start' => $START), true); exit;
		
	}	
	return JSON(array('is' => false), true);
}

function is_artists_page(){
	global $REQUEST_URI; $START = 1;
	if(preg_match('/\/artists/', $REQUEST_URI) || preg_match('/artists\/p[0-9]+/', $REQUEST_URI)){
		if(preg_match('/artists\/p[0-9]+/', $REQUEST_URI)){
			$x = explode("/", $REQUEST_URI);
			$P = $x[count($x)-1];
			$START = (int) str_replace("p", "", $P);		
		}
		return JSON(array('is' => true, 'start' => $START), true); exit;
	}	
	return JSON(array('is' => false), true);
}

function is_account_page(){
	global $REQUEST_URI;
	return $REQUEST_URI == "/account" ? true : false;
}

function is_contact_page(){
	global $REQUEST_URI;
	return $REQUEST_URI == "/contact" ? true : false;
}

function is_library_page(){
	global $REQUEST_URI; $START = 1;
	if(preg_match('/\/library/', $REQUEST_URI) || preg_match('/library\/p[0-9]+/', $REQUEST_URI)){
		if(preg_match('/library\/p[0-9]+/', $REQUEST_URI)){
			$x = explode("/", $REQUEST_URI);
			$P = $x[count($x)-1];
			$START = (int) str_replace("p", "", $P);		
		}
		return JSON(array('is' => true, 'start' => $START), true); exit;
	}	
	return JSON(array('is' => false), true);
}


//ADMIN

function is_admin_page(){
	global $REQUEST_URI;
	return strpos($REQUEST_URI, "/admin/")!==false ? true : false;
}

function is_admin_dashboard(){
	global $REQUEST_URI;
	return strpos($REQUEST_URI, "/admin/dashboard")!==false ? true : false;
}

function is_admin_inbox(){
	global $REQUEST_URI;
	return strpos($REQUEST_URI, "/admin/inbox")!==false ? true : false;
}

function is_admin_users(){
	global $REQUEST_URI;
	return strpos($REQUEST_URI, "/admin/users")!==false ? true : false;
}

function is_admin_albums(){
	global $REQUEST_URI;
	return strpos($REQUEST_URI, "/admin/albums")!==false ? true : false;
}

function is_admin_artists(){
	global $REQUEST_URI;
	return strpos($REQUEST_URI, "/admin/artists")!==false ? true : false;
}

function is_admin_tracks(){
	global $REQUEST_URI;
	return strpos($REQUEST_URI, "/admin/tracks")!==false ? true : false;
}

function is_admin_upload(){
	global $REQUEST_URI;
	return strpos($REQUEST_URI, "/admin/upload")!==false ? true : false;
}

function is_admin_playlists(){
	global $REQUEST_URI;
	return strpos($REQUEST_URI, "/admin/playlists")!==false ? true : false;
}

function is_admin_genres(){
	global $REQUEST_URI;
	return strpos($REQUEST_URI, "/admin/genres")!==false ? true : false;
}

function is_admin_servers(){
	global $REQUEST_URI;
	return strpos($REQUEST_URI, "/admin/servers")!==false ? true : false;
}

function is_admin_plugins(){
	global $REQUEST_URI;
	return strpos($REQUEST_URI, "/admin/plugins")!==false ? true : false;
}

function is_admin_themes(){
	global $REQUEST_URI;
	return strpos($REQUEST_URI, "/admin/themes")!==false ? true : false;
}

function is_admin_settings(){
	global $REQUEST_URI;
	return strpos($REQUEST_URI, "/admin/settings")!==false ? true : false;
}

function is_admin_api(){
	global $REQUEST_URI;
	return strpos($REQUEST_URI, "/admin/apikeys")!==false ? true : false;
}

//ADMIN

function getCurrentPage(){
	if(is_home_page()){
		return 'home';
	}else if(is_genre_page()->is===true){
		return 'genres';
	}else if(is_album_page()->is===true){
		return 'albums';
	}else if(is_artists_page()->is===true){
		return 'artists';
	}else if(is_playlist_page()->is===true){
		return 'playlists';
	}else if(is_explore_page()->is===true){
		return 'explore';
	}else if(is_library_page()->is===true){
		return 'library';
	}else if(is_tracks_page()->is===true){
		return 'tracks';
	}else if(is_search_page()){
		return 'search';
	}else if(is_account_page()){
		return 'account';
	}else if(is_contact_page()){
		return 'contact';
	}
	
	else if(is_admin_page()){
		if(is_admin_dashboard()){
			return 'dashboard';
		}else if(is_admin_inbox()){
			return 'inbox';
		}else if(is_admin_users()){
			return 'users';
		}else if(is_admin_artists()){
			return 'artists';
		}else if(is_admin_albums()){
			return 'albums';
		}else if(is_admin_tracks()){
			return 'tracks';
		}else if(is_admin_upload()){
			return 'upload';
		}else if(is_admin_playlists()){
			return 'playlists';
		}else if(is_admin_genres()){
			return 'genres';
		}else if(is_admin_servers()){
			return 'servers';
		}else if(is_admin_plugins()){
			return 'plugins';
		}else if(is_admin_themes()){
			return 'themes';
		}else if(is_admin_settings()){
			return 'settings';
		}else if(is_admin_api()){
			return 'apikeys';
		}else{
			return '404';
		}
	}
	
	
}

?>