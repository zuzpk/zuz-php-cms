<?php 
ini_set("display_errors", "0");
/*Cache Start*/
$lastModified = filemtime(__FILE__);
$etagFile = md5_file(__FILE__);
$ifModifiedSince=(isset($_SERVER['HTTP_IF_MODIFIED_SINCE']) ? $_SERVER['HTTP_IF_MODIFIED_SINCE'] : false);
$etagHeader=(isset($_SERVER['HTTP_IF_NONE_MATCH']) ? trim($_SERVER['HTTP_IF_NONE_MATCH']) : false);
header("Last-Modified: ".gmdate("D, d M Y H:i:s", $lastModified)." GMT");
header("Etag: $etagFile");
header('Cache-Control: public');
if(@strtotime($_SERVER['HTTP_IF_MODIFIED_SINCE'])==$lastModified || $etagHeader == $etagFile){
    header("HTTP/1.1 304 Not Modified"); exit;
}
/*Cache End*/
$image = zuz_image_request();
$file = $image->type==='youtube' ? $image->token : decode($image->token);
switch($image->type):
	case "track":
		@list($fileid, $source) = explode("@@", $file);
		$xte = pathinfo($fileid);
		if(!isset($xte['extension'])){ $fileid .= '.jpg'; }
		$local = ASSETS . 'posters/' . $fileid;		
		$thumb = ASSETS . 'posters/thumb_'.$fileid;
		if(!file_exists($thumb)){
			if(file_exists($local)){
				include_once(ZUZINC . 'thirdparty/wideimage/WideImage.php');
				@list($width, $height) = @getimagesize($local);
				$rthumb = ASSETS . 'posters/tmp_'.$fileid;
				try{				
					$crop = WideImage::load($local)->crop('center', 'center', $height, $height);
				}catch(Exception $e){
					$thumb = BASEPATH . 'ui/no-image-dark.png';	
				}
				if(!isset($crop)){
					$thumb = BASEPATH . 'ui/no-image-dark.png';	
				}else{
					$crop->saveToFile($rthumb);
				}
				if(file_exists($rthumb)){
					try{
						WideImage::load($rthumb)->resize(300, 300)->saveToFile($thumb);
					}catch(Exception $e){
						$thumb = BASEPATH . 'ui/no-image-dark.png';	
					}
				}else{
					$thumb = BASEPATH . 'ui/no-image-dark.png';	
				}
			}else{
				$thumb = BASEPATH . 'ui/no-image-dark.png';
			}
		}
		/*if(!file_exists($thumb)){
			try{
				$local = ASSETS . 'posters/' . $fileid;
				/*if(!file_exists($local) && $source=='youtube'){
					$resolutions = array('maxresdefault', 'hqdefault', 'mqdefault');     
					$imgUrl = "http://i.ytimg.com/vi/".$YTID."/hqdefault.jpg";
					foreach($resolutions as $res):
						$YTID = str_replace(".jpg", "", $fileid);
						$imgUrl = "http://i.ytimg.com/vi/".$YTID."/".$res.".jpg";
						if(@getimagesize(($imgUrl))){ break; }
					endforeach;
					$img = @file_get_contents($imgUrl);
					@file_put_contents($local, $img);
				}
				include_once(ZUZINC . 'thirdparty/wideimage/WideImage.php');
				@list($width, $height) = @getimagesize($local);
				$rthumb = ASSETS . 'posters/tmp_'.$fileid;
				$crop = WideImage::load($local)->crop('center', 'center', $height, $height);
				$crop->saveToFile($rthumb);
				WideImage::load($rthumb)->resize(300, 300)->saveToFile($thumb);
				unlink($rthumb);
				
			}catch(Exception $e){
				$thumb = BASEPATH . 'ui/no-image.png';
			}
		}*/
		header("Content-type: image/jpeg");
		echo @readfile($thumb);
	break;
	case "album":
		$local = ASSETS . 'covers/' . $file;
		if($file!='no-cover.png'){
			$local = ASSETS . 'covers/thumb_' . $file;
			if(!file_exists($local)){
				$rthumb = ASSETS . 'covers/' . $file;
				@list($width, $height) = @getimagesize($local);
				include_once(ZUZINC . 'thirdparty/wideimage/WideImage.php');
				WideImage::load($rthumb)->resize(250, 250)->saveToFile($local);			
			}
		}
		header("Content-type: image/jpeg");
		echo @readfile($local);
	break;
	case "userdp":
		@list($w, $h) = explode("x", $image->res);		
		@list($ofile, $googleid, $fbid) = explode("@@", $file);		
		$oimage = ASSETS . 'dps/' . $ofile;
		$image = ASSETS . 'dps/' . $image->res . '_' . $ofile;
		$ext = strtolower(pathinfo($ofile, PATHINFO_EXTENSION));
		$ctype = $ext=="jpg" || $ext == "jpeg" ? 'image/jpeg' : 'image/png';
		if(!file_exists($image)){
			if(@filesize($oimage)==0){
				$image = ASSETS . 'dps/no-dp.png';
			}else{
				try{
					require(ZUZINC . "thirdparty/resize/vendor/autoload.php");
					$img = new \claviska\SimpleImage();
					$img->fromFile($oimage)->resize($w, $h)->toFile($image, $ctype);
				}catch(Exception $e){				
					$image = $oimage;
				}
			}
		}		
		header("Content-Type: $ctype");
		echo @readfile($image);
	break;
	case "artistdp":
		@list($w, $h) = explode("x", $image->res);		
		@list($ofile, $googleid, $fbid) = explode("@@", $file);		
		$oimage = ASSETS . 'artists/' . $ofile;
		$image = ASSETS . 'artists/' . $image->res . '_' . $ofile;
		$ext = strtolower(pathinfo($ofile, PATHINFO_EXTENSION));
		$ctype = $ext=="jpg" || $ext == "jpeg" ? 'image/jpeg' : 'image/png';
		if(!file_exists($image)){
			if(@filesize($oimage)==0){
				$image = ASSETS . 'dps/no-dp.png';
			}else{
				if($w == 0 && $h == 0){
					$image = $oimage;
				}else{
					try{
						require(ZUZINC . "thirdparty/resize/vendor/autoload.php");
						$img = new \claviska\SimpleImage();
						$img->fromFile($oimage)->resize($w, $h)->toFile($image, $ctype);
					}catch(Exception $e){				
						$image = $oimage;
					}
				}
			}
		}		
		header("Content-Type: $ctype");
		echo @readfile($image);
	break;
	case "youtube":
		$imgUrl = "http://i.ytimg.com/vi/".$file."/mqdefault.jpg";
		header("Content-Type: image/jpeg");
		echo @readfile($imgUrl);
	break;
endswitch;
?>