<?php
$ZUZ_LISTENERS = array();

function zuzHook(){	
	global $ZUZ_LISTENERS;	
	$num_args = func_num_args();
	$args = func_get_args();	
	if($num_args < 2){
		trigger_error(lang('error_plugin_insufficient_arguments'), E_USER_ERROR);
	}else{
		$hook_name = array_shift($args);
		if(!isset($ZUZ_LISTENERS[$hook_name]))
        return;
		foreach($ZUZ_LISTENERS[$hook_name] as $func) {
			$args = $func($args); 
		}
		return $args;
	}	
}

function hook_action($hook, $callback_function){	
	global $ZUZ_LISTENERS;
	$ZUZ_LISTENERS[$hook][] = $callback_function;
}

function hook_css($hook, $callback_function){	
	global $ZUZ_LISTENERS;
	$ZUZ_LISTENERS['zuz_css_' . $hook][] = $callback_function;
}

function hook_activation($hook, $callback_function){	
	global $ZUZ_LISTENERS;
	$ZUZ_LISTENERS[$hook][] = $callback_function;
}

$active_list = getActivePlugins();
foreach($active_list as $plugin):
	include_once(PLUGINS_DIR . $plugin);
endforeach;

/*$ignore_list = array('.','..','index.php');
$plist = scandir(PLUGINS_DIR);
foreach($plist as $plugin):
	if(is_dir($plugin)){
		if(file_exists(PLUGINS_DIR . $plugin . '/' . $plugin . '.php')){
			
		}
	}else{
		if(!in_array($plugin, $ignore_list)){
			
		}		
	}
endforeach;*/
?>