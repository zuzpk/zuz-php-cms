<?php 
$SIZE_GB = 1024 * 1024 * 1024;

//Main Nav
$ZUZ_NAV = array(
	
	//home
	array(
		'label' => lang('home'),
		'icon' => 'icon-home',
		'link' => '',
		'type' => 'public'
	),
	
	//search
	array(
		'label' => lang('search'),
		'icon' => 'icon-search',
		'link' => 'search',
		'type' => 'public'
	),
	
	//explore
	array(
		'label' => lang('explore'),
		'icon' => 'icon-compass',
		'link' => 'explore',
		'type' => 'public'
	),
	
	//library
	array(
		'label' => lang('library'),
		'icon' => 'icon-music',
		'link' => 'library',
		'type' => 'user,admin,moderator'
	),
	
	//signin
	array(
		'label' => lang('signin'),
		'icon' => 'icon-user',
		'link' => 'account',
		'type' => 'guest'
	),
	
	//signout
	array(
		'label' => lang('signout'),
		'icon' => 'icon-power',
		'link' => 'signout',
		'type' => 'user,admin,moderator'
	),
	
	//contact
	array(
		'label' => lang('contact'),
		'icon' => 'icon-at-sign',
		'link' => 'contact',
		'type' => 'public'
	),
	
	/*//alerts
	array(
		'label' => lang('alerts'),
		'icon' => 'icon-bell',
		'link' => 'alerts',
		'type' => 'user,admin,moderator'
	),*/
	
	//admin panel
	array(
		'label' => lang('admin_panel'),
		'icon' => 'icon-slack',
		'link' => 'admin/dashboard',
		'type' => 'admin,moderator'
	),
	
	//upload track
	array(
		'label' => lang('upload_track'),
		'icon' => 'icon-plus-circle',
		'link' => 'admin/upload',
		'type' => 'admin,moderator'
	)
	
);


//Hometabs
$ZUZ_NAV_HOME = array(	
	array(
		'label' => lang('home'),
		'link' => 'home',
		'on' => true
	),
	array(
		'label' => lang('genres'),
		'link' => 'genres',
		'on' => false
	),
	array(
		'label' => lang('albums'),
		'link' => 'albums',
		'on' => false
	),
	array(
		'label' => lang('artists'),
		'link' => 'artists',
		'on' => false
	),
	array(
		'label' => lang('playlists'),
		'link' => 'playlists',
		'on' => false
	)
);

//ADMIN Nav
$ZUZ_NAV_ADMIN = array(	
	array(
		'label' => lang('dashboard'),
		'icon' => 'icon-anchor',
		'link' => 'admin/dashboard',
		'permission' => 'all'
	),
	array(
		'label' => lang('inbox'),
		'icon' => 'icon-at-sign',
		'link' => 'admin/inbox',
		'permission' => 'inbox.list'
	),
	array(
		'label' => lang('users'),
		'icon' => 'icon-user',
		'link' => 'admin/users',
		'permission' => 'users.list'
	),
	array(
		'label' => lang('albums'),
		'icon' => 'icon-layers',
		'link' => 'admin/albums',
		'permission' => 'albums.list'
	),
	array(
		'label' => lang('artists'),
		'icon' => 'icon-headphones',
		'link' => 'admin/artists',
		'permission' => 'artists.list'
	),
	array(
		'label' => lang('tracks'),
		'icon' => 'icon-music',
		'link' => 'admin/tracks',
		'permission' => 'tracks.list'
	),
	array(
		'label' => lang('playlists'),
		'icon' => 'icon-list',
		'link' => 'admin/playlists',
		'permission' => 'playlist.list'
	),
	array(
		'label' => lang('admin_genres'),
		'icon' => 'icon-wind',
		'link' => 'admin/genres',
		'permission' => 'genre.list'
	),
	array(
		'label' => lang('servers'),
		'icon' => 'icon-server',
		'link' => 'admin/servers',
		'permission' => 'servers.list'
	),
	array(
		'label' => lang('plugins'),
		'icon' => 'icon-cpu',
		'link' => 'admin/plugins',
		'permission' => 'plugins.list'
	),
	array(
		'label' => lang('themes'),
		'icon' => 'icon-feather',
		'link' => 'admin/themes',
		'permission' => 'themes.list'
	),
	array(
		'label' => lang('settings'),
		'icon' => 'icon-settings',
		'link' => 'admin/settings',
		'permission' => 'settings.list'
	),	
	array(
		'label' => lang('api_keys'),
		'icon' => 'icon-terminal',
		'link' => 'admin/apikeys',
		'permission' => 'apikeys.list'
	),
	array(
		'label' => lang('signout'),
		'icon' => 'icon-power',
		'link' => 'signout',
		'permission' => 'all'
	),
	array(
		'label' => lang('back_to_site'),
		'icon' => 'icon-arrow-left-circle',
		'link' => '',
		'permission' => 'all'
	)	
);

$ZUZ_JAVASCRIPT_LIST = array();
$ZUZ_CSS_LIST = array();
?>